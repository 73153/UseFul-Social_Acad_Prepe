//
//  MessageVC.m
//  AcademicPulse
//
//  Created by dhara on 11/7/15.
//  Copyright © 2015 com.zaptech. All rights reserved.
//

#import "MessageVC.h"
#import "RESideMenu.h"
#import "UIViewController+NavigationBar.h"
#import "logoView.h"
#import "MessageCell.h"
#import "MesaageDetailVC.h"
#import "ConstantList.h"
#import "TabVIew.h"
#import "Globals.h"
@interface MessageVC ()<SearchDelegate>
{
    logoView *log;
    TabVIew *tab;
}
@end

@implementation MessageVC
@synthesize tblMessage;

#pragma mark - VC lifecycle


- (void)viewDidLoad {
    [super viewDidLoad];
    [self setMenuIconForSideBar:@"menu"];
    [self setUpContentData];
}

-(void)viewDidAppear:(BOOL)animated{
    UINib * mainView = [UINib nibWithNibName:@"logoView" bundle:nil];
    log =(logoView *)[mainView instantiateWithOwner:self options:nil][0];
    if(IS_IPHONE_6_PLUS)
    {
        log.frame=CGRectMake(0, 5, self.view.frame.size.width, log.frame.size.height+20);
    }else
        log.frame=CGRectMake(0, 5, self.view.frame.size.width, log.frame.size.height);
    [self.view addSubview:log];
}

-(void)viewWillDisappear:(BOOL)animated
{
    self.navigationItem.title=@"";
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
}

-(void)viewWillAppear:(BOOL)animated
{
    self.navigationItem.title=@"MESSAGES";
}

#pragma mark - Custom Methods

-(void)setUpContentData
{
    if (IS_IPHONE_6_PLUS) {
        _topHeight.constant=135;
    }
    [self.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:@"header"] forBarMetrics:UIBarMetricsDefault];
    
    self.navigationItem.title = @"MESSAGES";
    self.navigationController.navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName: [UIColor whiteColor],NSFontAttributeName: [UIFont fontWithName:@"Helvetica" size:15.0f]};
    UINib * mainViewTab = [UINib nibWithNibName:@"TabView" bundle:nil];
    tab =(TabVIew *)[mainViewTab instantiateWithOwner:self options:nil][0];
    if(IS_IPHONE_6_PLUS)
    {
        tab.frame=CGRectMake(0,self.view.frame.size.height-114, self.view.frame.size.width, tab.frame.size.height+10);
        [self.view addSubview:tab];
    }else
    {
        tab.frame=CGRectMake(0,self.view.frame.size.height-104, self.view.frame.size.width, tab.frame.size.height);
        
        [self.view addSubview:tab];
    }
}
#pragma mark - tableView Delegate

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 5;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    @try
    {
        static NSString *CellIdentifier = @"MessageTVC";
        MessageCell *cell = (MessageCell *)[tblMessage dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"MessageCell" owner:self options:nil];
            cell = [nib objectAtIndex:0];
            cell.selectionStyle= UITableViewCellSelectionStyleNone;
            cell.backgroundColor=[UIColor clearColor];
        }
        return cell;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
}


- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

- (void) tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UIStoryboard *storybord = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    
    MesaageDetailVC *objMesaageDetailVC=(MesaageDetailVC *)[storybord  instantiateViewControllerWithIdentifier:@"MesaageDetailVC"];
    
    
    [self.navigationController pushViewController:objMesaageDetailVC animated:YES];
    
}

#pragma mark - Search Delegate
-(void)didSelectSearchedString:(NSString *)selectedString tableView:(id)tableView{
    [tableView toggleHidden:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */
@end
