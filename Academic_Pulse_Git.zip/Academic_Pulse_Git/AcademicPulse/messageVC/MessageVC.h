//
//  MessageVC.h
//  AcademicPulse
//
//  Created by dhara on 11/7/15.
//  Copyright © 2015 com.zaptech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MessageVC : UIViewController<UITableViewDataSource,UITableViewDelegate>
@property (strong, nonatomic) IBOutlet UITableView *tblMessage;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *topHeight;

@end
