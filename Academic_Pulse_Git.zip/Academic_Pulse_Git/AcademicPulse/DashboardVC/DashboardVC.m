//
//  DashboardVC.m
//  AcademicPulse
//
//  Created by vivek on 11/6/15.
//  Copyright © 2015 com.zaptech. All rights reserved.
//

#import "DashboardVC.h"
#import "RESideMenu.h"
#import "UIViewController+NavigationBar.h"
#import "logInVC.h"
#import "AppDelegate.h"
#import "logoView.h"
#import "ConstantList.h"
#import "Globals.h"

@interface DashboardVC ()<SearchDelegate>{
     logoView *log;
}
@end

@implementation DashboardVC

#pragma mark - VC lifecycle

- (void)viewDidLoad {
    [super viewDidLoad];
  
    [self setMenuIconForSideBar:@"menu"];
    [self setUpContentData];
    [self getCourseDetails];

    }

#pragma mark - Custom Methods

-(void)setUpContentData
{
    UINib * mainView = [UINib nibWithNibName:@"logoView" bundle:nil];
    log =(logoView *)[mainView instantiateWithOwner:self options:nil][0];
    if(IS_IPHONE_6_PLUS)
    {
        log.frame=CGRectMake(0, 5, self.view.frame.size.width, log.frame.size.height+80);
    }else
        log.frame=CGRectMake(0, 5, self.view.frame.size.width, log.frame.size.height+60);
    [self.view addSubview:log];
    if(IS_IPHONE_6_PLUS)
    {
        _topScrollPosYConstraint.constant=105;
    }
    
    self.navigationItem.title = @"DASHBOARD";
    self.navigationController.navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName: [UIColor whiteColor],NSFontAttributeName: [UIFont fontWithName:@"Helvetica" size:15.0f]};
    [self.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:@"header"] forBarMetrics:UIBarMetricsDefault];

}

-(void)getCourseDetails
{
    @try
    {
        Globals *objGlob = [Globals sharedManager];
        [objGlob.objAssinmentModel callCourseListService:^(NSString *sta, int status) {
            if([sta isEqualToString:@"Course Details"]){
                
            }
            else{
                
            }
        }];
    } @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
  
}

#pragma mark - Search Delegate
-(void)didSelectSearchedString:(NSString *)selectedString tableView:(id)tableView{
    [tableView toggleHidden:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
@end
