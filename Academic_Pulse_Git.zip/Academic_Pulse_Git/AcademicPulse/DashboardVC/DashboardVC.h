//
//  DashboardVC.h
//  AcademicPulse
//
//  Created by vivek on 11/6/15.
//  Copyright © 2015 com.zaptech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DashboardVC : UIViewController
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topScrollPosYConstraint;

@end
