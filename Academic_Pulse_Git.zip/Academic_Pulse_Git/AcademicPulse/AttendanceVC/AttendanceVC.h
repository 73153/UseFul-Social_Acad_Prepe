//
//  AttendanceVC.h
//  AcademicPulse
//
//  Created by dhara on 11/9/15.
//  Copyright © 2015 com.zaptech. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CKCalendarView.h"
#import "PopUpTableViewController.h"

@interface AttendanceVC : UIViewController<UITableViewDelegate,UITableViewDataSource>
@property (strong, nonatomic) IBOutlet UITableView *tblAttendance;
@property (strong, nonatomic) IBOutlet CKCalendarView *calendar;
@property (strong, nonatomic) IBOutlet UIScrollView *scrollView;
@property (strong, nonatomic) NSMutableDictionary *eventsDictionary;
@property (nonatomic, strong) PopUpTableViewController *objPopUpTableController;

@end
