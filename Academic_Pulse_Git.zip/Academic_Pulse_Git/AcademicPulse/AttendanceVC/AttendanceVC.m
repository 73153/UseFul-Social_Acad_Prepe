//
//  AttendanceVC.m
//  AcademicPulse
//
//  Created by dhara on 11/9/15.
//  Copyright © 2015 com.zaptech. All rights reserved.
//

#import "AttendanceVC.h"
#import "RESideMenu.h"
#import "UIViewController+NavigationBar.h"
#import "logoView.h"
#import "AssignmentCell.h"
#import <CoreGraphics/CoreGraphics.h>
#import "ConstantList.h"
#import "TabVIew.h"
#import "Globals.h"
#import "MBProgressHUD.h"

@interface AttendanceVC ()<CKCalendarDelegate,SearchDelegate>
{
    logoView *log;
    TabVIew *tab;
    NSMutableArray *aryDate;
}
@property(nonatomic, strong) UILabel *dateLabel;
@property(nonatomic, strong) NSDateFormatter *dateFormatter;
@property(nonatomic, strong) NSDate *minimumDate;
@property(nonatomic, strong) NSMutableArray *attendanceDetail;
@property(nonatomic, strong) NSMutableArray *attendanceDates;
@end

@implementation AttendanceVC
@synthesize calendar,scrollView,attendanceDates,attendanceDetail;

#pragma mark - VC lifecycle

- (void)viewDidLoad {
    [super viewDidLoad];
    attendanceDates = [[NSMutableArray alloc] init];
    attendanceDetail= [[NSMutableArray alloc] init];
    [self setUpContentData];
    [self getCalendarEvents];
    [self setCKCalendar];
    [self loadPopUpTable];
    UITapGestureRecognizer * tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(handleTap:)];
    [self.view addGestureRecognizer:tap];
}

#pragma mark - Custom Methods

-(void)setUpContentData
{
    [scrollView bringSubviewToFront:log];
    self.navigationItem.title = @"ATTENDANCE";
    [self.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:@"header"] forBarMetrics:UIBarMetricsDefault];
    self.navigationController.navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName: [UIColor whiteColor],NSFontAttributeName: [UIFont fontWithName:@"Helvetica" size:15.0f]};
    UINib * mainView = [UINib nibWithNibName:@"logoView" bundle:nil];
    log =(logoView *)[mainView instantiateWithOwner:self options:nil][0];
    if(IS_IPHONE_6_PLUS)
    {
        log.frame=CGRectMake(0, 5, self.view.frame.size.width, log.frame.size.height+84);
    }else
        log.frame=CGRectMake(0, 5, self.view.frame.size.width, log.frame.size.height+64);
    [self.view addSubview:log];
    
    UINib * mainViewTab = [UINib nibWithNibName:@"TabView" bundle:nil];
    tab =(TabVIew *)[mainViewTab instantiateWithOwner:self options:nil][0];
    if(IS_IPHONE_6_PLUS)
    {
        tab.frame=CGRectMake(0,self.view.frame.size.height-114, self.view.frame.size.width, tab.frame.size.height+10);
        [self.view addSubview:tab];
        
    }else
    {
        tab.frame=CGRectMake(0,self.view.frame.size.height-104, self.view.frame.size.width, tab.frame.size.height);
        
        [self.view addSubview:tab];
        
    }
}

-(void) getCalendarEvents

{
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    Globals *objGlob = [Globals sharedManager];
    [objGlob.objAssinmentModel callAttendanceCalendarEventListService:^(NSString *sta, int status) {
        if([sta isEqualToString:@"Calendar Event"]){
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
            attendanceDetail = [objGlob.dictGlobalAttendanceCalendarEventList mutableCopy];
            [attendanceDetail enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                
                [self.dateFormatter setDateFormat:@"yyyy-MM-dd"];
                NSString *dateComplete = [[attendanceDetail objectAtIndex:idx] valueForKey:@"attendence_date"];
                NSString *newString = [dateComplete substringToIndex:10];
                
                NSDate *attendanceIndividualDate= [self.dateFormatter dateFromString:newString];
                [attendanceDates addObject:attendanceIndividualDate];
                
            }];
        }
        else{
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
            
        }
    }];
    
    
}

-(void)setCKCalendar
{
    //CKCalendarView *calendar ;//= [[CKCalendarView alloc] initWithStartDay:startMonday];
    self.calendar = calendar;
    
    calendar.calendarStartDay = startMonday;
    calendar.delegate = self;
    self.dateFormatter = [[NSDateFormatter alloc] init];
    [self.dateFormatter setDateFormat:@"dd/MM/yyyy"];
    [self.dateFormatter setDateFormat:@"MM-dd-yy"];
    
    
    self.minimumDate = [self.dateFormatter dateFromString:@"20-09-2012"];
    
    
    NSDate *date5= [self.dateFormatter dateFromString:@"11-12-2015"];
    
    
    [aryDate addObject:date5 ];
    calendar.onlyShowCurrentMonth = NO;
    calendar.adaptHeightToNumberOfWeeksInMonth = YES;
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(localeDidChange) name:NSCurrentLocaleDidChangeNotification object:nil];
}

#pragma mark - tableView Delegate

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    @try{
        static NSString *CellIdentifier = @"AssignmentCell";
        AssignmentCell *cell = (AssignmentCell *)[_tblAttendance dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"AssignmentCell" owner:self options:nil];
            cell = [nib objectAtIndex:0];
            cell.selectionStyle= UITableViewCellSelectionStyleNone;
            cell.backgroundColor=[UIColor clearColor];
        }
        return cell;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

#pragma mark - CKCalendar Methods

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
    } else {
        return YES;
    }
}

- (void)localeDidChange {
    [self.calendar setLocale:[NSLocale currentLocale]];
    
}

- (BOOL)dateIsDisabled:(NSDate *)date {
    for (NSDate *disabledDate in self.attendanceDates) {
        if ([disabledDate isEqualToDate:date]) {
            return YES;
        }
    }
    return NO;
}

#pragma mark - CKCalendarDelegate

- (void)calendar:(CKCalendarView *)calendar configureDateItem:(CKDateItem *)dateItem forDate:(NSDate *)date {
    dateItem.selectedBackgroundColor = [UIColor clearColor];
    
    // TODO: play with the coloring if we want to...
    if ([self dateIsDisabled:date]) {
        
        if ([date compare:[NSDate date]] == NSOrderedAscending) {
            dateItem.selectedBackgroundColor = [UIColor clearColor];
            dateItem.textColor = [UIColor greenColor];
            
        }
        else{
            dateItem.backgroundColor = [UIColor redColor];
            dateItem.textColor = [UIColor whiteColor];
        }
    }
}

- (void)calendar:(CKCalendarView *)calendar didSelectDate:(NSDate *)date {
    if ([date isEqualToDate:date])
    {
        
        if(date)
        {
            NSMutableArray *aryDateToDisplay = [[NSMutableArray alloc] init];
            [attendanceDates enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
                NSString *dateComplete = [[attendanceDetail objectAtIndex:idx] valueForKey:@"attendence_date"];
                NSString *firstDate = [dateComplete substringToIndex:10];
                
                NSDate *secondDate = [attendanceDates objectAtIndex:idx];
                NSString *secondDateCompare = [self.dateFormatter stringFromDate:secondDate];
                secondDateCompare = [secondDateCompare substringToIndex:10];
                if([firstDate isEqualToString:secondDateCompare]){
                    [aryDateToDisplay addObject:dateComplete];
                }
            }];
            
            if(aryDateToDisplay.count>0)
            {
                [self.objPopUpTableController toggleHidden:NO];
                [self.objPopUpTableController reloadDataWithSource:[aryDateToDisplay mutableCopy]];
            }
        }
        NSDate *currentDate = [NSDate date];
        NSLog(@"Event added------>>>>>>");
    }
    //NSLog(@"%@",(self.dateLabel.text = [self.dateFormatter stringFromDate:date]));
}

- (BOOL)calendar:(CKCalendarView *)calendar willChangeToMonth:(NSDate *)date {
    
    //    if ([date isEqualToDate:self.selectedDate]) {
    //        // deselection..
    //        if ([delegate respondsToSelector:@selector(calendar:willDeselectDate:)] && ![self.delegate calendar:self willDeselectDate:date]) {
    //
    //            return;
    //        }
    //        date = nil;
    //    } else if ([self.delegate respondsToSelector:@selector(calendar:willSelectDate:)] && ![self.delegate calendar:self willSelectDate:date]) {
    //        return;
    //    }
    if ([date laterDate:self.minimumDate] == date) {
        self.calendar.layer.borderWidth=0;
        self.calendar.backgroundColor = [UIColor clearColor];
        return YES;
    } else {
        self.calendar.backgroundColor = [UIColor clearColor];
        return NO;
    }
}

- (void)calendar:(CKCalendarView *)calendar didLayoutInRect:(CGRect)frame {
    NSLog(@"calendar layout: %@", NSStringFromCGRect(frame));
}

#pragma mark touchesBegan
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    [super touchesBegan:touches withEvent:event];
    [self.objPopUpTableController toggleHidden:YES];
    
}

- (void)handleTap:(UITapGestureRecognizer *)recognizer
{
    [self.objPopUpTableController toggleHidden:YES];

}

#pragma mark POPUP Delegate
#pragma mark - Delegate

-(void)loadPopUpTable{
    //    UIEdgeInsets buttonEdges = UIEdgeInsetsMake(0, 5, 0, -5);
    self.objPopUpTableController = [[PopUpTableViewController alloc] initWithStyle:UITableViewStylePlain];
    self.objPopUpTableController.dataSource =  nil;
    self.objPopUpTableController.tableView.frame = CGRectMake(self.view.frame.size.width/2-100,self.self.view.frame.size.height/2, 200,250);
    self.objPopUpTableController.delegate=self;
    self.objPopUpTableController.view.layer.zPosition = 100;
    
    //    self.objPopUpTableController.delegate = self;
    [self.view addSubview:self.objPopUpTableController.tableView];
    [self.objPopUpTableController toggleHidden:YES];
    
    self.objPopUpTableController.tableView.layer.borderWidth = 2;
    self.objPopUpTableController.tableView.layer.borderColor = [[UIColor blackColor] CGColor];
}



#pragma mark - Search Delegate

-(void)didSelectSearchedString:(NSString *)selectedString tableView:(id)tableView{
    [tableView toggleHidden:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
