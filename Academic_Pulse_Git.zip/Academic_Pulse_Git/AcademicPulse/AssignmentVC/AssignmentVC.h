//
//  AssignmentVC.h
//  AcademicPulse
//
//  Created by pradip.r on 11/7/15.
//  Copyright (c) 2015 com.zaptech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AssignmentVC : UIViewController<UITableViewDataSource,UITableViewDelegate>

@property (weak, nonatomic) IBOutlet UITableView *tblViewAssignment;

@property (strong, nonatomic) IBOutlet NSLayoutConstraint *topHeight;

@property( strong,nonatomic) NSDictionary *dictCourseDetail;
@end
