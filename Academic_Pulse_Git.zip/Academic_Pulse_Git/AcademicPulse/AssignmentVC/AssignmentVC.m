//
//  AssignmentVC.m
//  AcademicPulse
//
//  Created by pradip.r on 11/7/15.
//  Copyright (c) 2015 com.zaptech. All rights reserved.
//

#import "AssignmentVC.h"
#import "AssignmentCell.h"
#import "RESideMenu.h"
#import "UIViewController+NavigationBar.h"
#import "logoView.h"
#import "ConstantList.h"
#import "TabVIew.h"
#import "MBProgressHUD.h"
#import "APICall.h"
#import "Globals.h"
#import "UIView+Toast.h"

@interface AssignmentVC ()<SearchDelegate>
{
    logoView *log;
    TabVIew *tab;
    NSMutableArray *aryAssignmentDetails;
    Globals *objGlobal;
}

@end

@implementation AssignmentVC

@synthesize dictCourseDetail;


#pragma mark - VC lifecycle

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setUpContentData];
    [self getAssignmentList];
}

#pragma mark - Custom Methods

-(void)setUpContentData
{
    self.navigationItem.title = @"ASSIGNMENT";
    self.navigationController.navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName:[UIColor whiteColor],NSFontAttributeName: [UIFont fontWithName:@"Helvetica" size:15.0f]};
    UINib * mainView = [UINib nibWithNibName:@"logoView" bundle:nil];
    log =(logoView *)[mainView instantiateWithOwner:self options:nil][0];
    if(IS_IPHONE_6_PLUS)
    {
        log.frame=CGRectMake(0, 5, self.view.frame.size.width, log.frame.size.height+84);
        _topHeight.constant=120;
    }else
        log.frame=CGRectMake(0, 5, self.view.frame.size.width, log.frame.size.height+64);
    [self.view addSubview:log];
    
    UINib * mainViewTab = [UINib nibWithNibName:@"TabView" bundle:nil];
    tab =(TabVIew *)[mainViewTab instantiateWithOwner:self options:nil][0];
    if(IS_IPHONE_6_PLUS)
    {
        tab.frame=CGRectMake(0,self.view.frame.size.height-114, self.view.frame.size.width, tab.frame.size.height+10);
        [self.view addSubview:tab];
        
    }else
    {
        tab.frame=CGRectMake(0,self.view.frame.size.height-104, self.view.frame.size.width, tab.frame.size.height);
        
        [self.view addSubview:tab];
        
    }
}

-(void)getAssignmentList
{
    @try{
        objGlobal = [Globals sharedManager];
        aryAssignmentDetails=[[NSMutableArray alloc]init];
        NSMutableDictionary *params = [[NSMutableDictionary alloc] init];
        [params setObject:[dictCourseDetail valueForKey:@"courseid"] forKey:@"course_id"];
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        [APICall callPostWebService:ASSINGMENT_URL andDictionary:params completion:^(NSMutableDictionary *result, NSError *error, long code) {
            NSString *strStatus = [NSString stringWithFormat:@"%ld",(long)[[result valueForKey:@"status"] integerValue]];
            if([strStatus isEqualToString:@"1"]){
                [MBProgressHUD hideAllHUDsForView:
                 self.view animated:YES];
                aryAssignmentDetails=[result valueForKey:@"AssignmentList"];
                [_tblViewAssignment reloadData];
            }
            else{
                [MBProgressHUD hideAllHUDsForView:
                 self.view animated:YES];
                [self.view makeToast:[result valueForKey:@"msg"]];
            }
        }];
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
}

#pragma mark - tableView Delegate

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return aryAssignmentDetails.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    @try{
        static NSString *CellIdentifier = @"AssignmentCell";
        AssignmentCell *cell = (AssignmentCell *)[_tblViewAssignment dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"AssignmentCell" owner:self options:nil];
            cell = [nib objectAtIndex:0];
            cell.selectionStyle= UITableViewCellSelectionStyleNone;
            cell.backgroundColor=[UIColor clearColor];
            [cell.btnDueDate setTitle:[[aryAssignmentDetails objectAtIndex:indexPath.row] valueForKey:@"duedate"] forState:UIControlStateNormal];
            [cell.btnTotalPoints setTitle:[[aryAssignmentDetails objectAtIndex:indexPath.row] valueForKey:@"totalpoints"] forState:UIControlStateNormal];
        }
        return cell;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1;
}

-(UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, tableView.frame.size.width, 18)];
    /* Create custom view to display section header... */
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(10, 5, tableView.frame.size.width, 18)];
    [label setFont:[UIFont boldSystemFontOfSize:18]];
    NSString *string =@"Physical Training";
    /* Section header is in 0th index... */
    [label setText:string];
    [view addSubview:label];
    [view setBackgroundColor:[UIColor clearColor]]; //your background color...
    [_tblViewAssignment bringSubviewToFront:view];
    return view;
}

#pragma mark - Search Delegate

-(void)didSelectSearchedString:(NSString *)selectedString tableView:(id)tableView{
    [tableView toggleHidden:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



@end
