//
//  MessageTableViewCell.h
//  AcadamicPulse
//
//  Created by krutika on 11/9/15.
//  Copyright © 2015 com.zaptech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MessageTableViewCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *nmeLbl;
@property (strong, nonatomic) IBOutlet UILabel *dayLbl;
@property (strong, nonatomic) IBOutlet UILabel *timeLbl;
@property (strong, nonatomic) IBOutlet UITextView *detailTxtView;

@end
