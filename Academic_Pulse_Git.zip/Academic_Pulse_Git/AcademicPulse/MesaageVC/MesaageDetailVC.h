//
//  MesaageDetailVC.h
//  AcadamicPulse
//
//  Created by krutika on 11/9/15.
//  Copyright © 2015 com.zaptech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MesaageDetailVC : UIViewController<UITableViewDelegate,UITableViewDataSource>
@property (strong, nonatomic) IBOutlet UITableView *msgTabView;

@property (strong, nonatomic) IBOutlet NSLayoutConstraint *topHeight;
@end
