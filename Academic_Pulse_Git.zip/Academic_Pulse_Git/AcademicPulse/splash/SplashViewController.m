//
//  SplashViewController.m
//  AcademicPulse
//
//  Created by vivek on 11/19/15.
//  Copyright (c) 2015 com.zaptech. All rights reserved.
//

#import "SplashViewController.h"
#import "AppDelegate.h"
#import "logInVC.h"
#define DEGREES_TO_RADIANS(x) (M_PI * x / 180.0)
@interface SplashViewController ()
{
    NSTimer *timer;
}
@end

@implementation SplashViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

#pragma mark - VC lifeCycle

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationController.navigationBarHidden=YES;
    [self performSelector:@selector(gotoLogin) withObject:nil afterDelay:2.2];
    [self rotateTheIndicator];
    timer = [NSTimer scheduledTimerWithTimeInterval:1.0f target:self selector:@selector(rotateTheIndicator) userInfo:nil repeats:YES];
    // Do any additional setup after loading the view from its nib.
}


#pragma mark - Login Action

-(void) gotoLogin {
    [timer invalidate];
    [NSObject cancelPreviousPerformRequestsWithTarget:self];
    UIStoryboard *storybord = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    logInVC *second=(logInVC *)[storybord  instantiateViewControllerWithIdentifier:@"logInVC"];
    
    AppDelegate *appdel = (AppDelegate *)[[UIApplication sharedApplication]delegate];
    appdel.window.rootViewController = second;
}

#pragma mark - Indicator Animation

-(void)rotateTheIndicator
{
    [UIView animateWithDuration:1.4 animations:^{
        
        _loader.transform = CGAffineTransformMakeRotation(DEGREES_TO_RADIANS(180));
        
    }];
    
    [UIView animateWithDuration:1.4 animations:^{
        
        _loader.transform = CGAffineTransformMakeRotation(DEGREES_TO_RADIANS(360));
        
        
        
    }];
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
 #pragma mark - Navigation
 
 // In a storyboard-based application, you will often want to do a little preparation before navigation
 - (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
 // Get the new view controller using [segue destinationViewController].
 // Pass the selected object to the new view controller.
 }
 */

@end
