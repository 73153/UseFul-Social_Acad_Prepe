//
//  SplashViewController.h
//  AcademicPulse
//
//  Created by vivek on 11/19/15.
//  Copyright (c) 2015 com.zaptech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SplashViewController : UIViewController
@property (weak, nonatomic) IBOutlet UIImageView *loader;

@end
