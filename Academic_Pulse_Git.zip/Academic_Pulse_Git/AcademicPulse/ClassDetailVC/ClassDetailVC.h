//
//  Class1.h
//  AcadamicPulse
//
//  Created by krutika on 11/7/15.
//  Copyright © 2015 com.zaptech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ClassDetailVC : UIViewController<UITableViewDataSource,UITableViewDelegate>

@property (strong, nonatomic) IBOutlet UITableView *class1TabView;

- (IBAction)onBtnAssignMentClicked:(id)sender;
- (IBAction)onBtnAttendanceClicked:(id)sender;
@property (strong, nonatomic) IBOutlet UIScrollView *scrollView;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *topScrollConstraint;
@property (strong, nonatomic) NSDictionary *dictClassData;


@end
