//
//  ClassDetailVC.m
//  AcadamicPulse
//
//  Created by krutika on 11/7/15.
//  Copyright © 2015 com.zaptech. All rights reserved.
//

#import "ClassDetailVC.h"
#import "RESideMenu.h"
#import "UIViewController+NavigationBar.h"
#import "logInVC.h"
#import "AppDelegate.h"
#import "logoView.h"
#import "AttendanceVC.h"
#import "AssignmentVC.h"
#import "ConstantList.h"
#import "TabVIew.h"
#import "Globals.h"
@interface ClassDetailVC ()<SearchDelegate>{
    logoView *log;
    TabVIew *tab;
    NSMutableArray *arrList;
    Globals *objGLobal;
}

@end

@implementation ClassDetailVC

@synthesize scrollView,dictClassData;

#pragma mark - VC lifecycle


- (void)viewDidLoad
{
    [super viewDidLoad];
    [self setUpContentData];
    [self setUserDetail];
}

-(void)viewWillAppear:(BOOL)animated
{
    self.navigationItem.title=@"CLASS DETAIL";
}

-(void)viewWillDisappear:(BOOL)animated
{
    self.navigationItem.title=@"";
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
}

#pragma mark - Custom Methods

-(void)setUpContentData
{
    _topScrollConstraint.constant=115;
    
    [tab bringSubviewToFront:scrollView];
    scrollView.contentOffset = CGPointMake(0, 0);
    self.navigationItem.title = @"CLASS DETAIL";
    
    [self.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:@"header"] forBarMetrics:UIBarMetricsDefault];
    self.navigationController.navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName: [UIColor whiteColor],NSFontAttributeName: [UIFont fontWithName:@"Helvetica" size:15.0f]};
    
    UINib * mainViewTab = [UINib nibWithNibName:@"TabView" bundle:nil];
    tab =(TabVIew *)[mainViewTab instantiateWithOwner:self options:nil][0];
    if(IS_IPHONE_6_PLUS)
    {
        tab.frame=CGRectMake(0,self.view.frame.size.height-114, self.view.frame.size.width, tab.frame.size.height+10);
        [self.view addSubview:tab];
        
        
    }else
    {
        tab.frame=CGRectMake(0,self.view.frame.size.height-104, self.view.frame.size.width, tab.frame.size.height);
        
        [self.view addSubview:tab];
    }
    
    UINib * mainView = [UINib nibWithNibName:@"logoView" bundle:nil];
    log =(logoView *)[mainView instantiateWithOwner:self options:nil][0];
    if(IS_IPHONE_6_PLUS)
    {
        log.frame=CGRectMake(0, 5, self.view.frame.size.width, log.frame.size.height+84);
    }else
        log.frame=CGRectMake(0, 5, self.view.frame.size.width, log.frame.size.height+64);
    [self.view addSubview:log];
}

-(void)setUserDetail
{
    @try{
        objGLobal = [Globals sharedManager];
        NSArray *aryUserDetail = [objGLobal.dictGlobalLoginData mutableCopy];
        _class1TabView.scrollEnabled=NO;
        arrList = [[NSMutableArray alloc] init];
        [arrList addObject:[NSString stringWithFormat:@"Course: %@",[dictClassData valueForKey:@"course_name"]]];
        [arrList addObject:[NSString stringWithFormat:@"Date & Time: 8:00 am"]];
        [arrList addObject:[NSString stringWithFormat:@"Semester: %@",[dictClassData valueForKey:@"semister"]]];
        [arrList addObject:[NSString stringWithFormat:@"Year: %@",[dictClassData valueForKey:@"year"]]];
        [arrList addObject:[NSString stringWithFormat:@"Start: %@    |    End: %@",[dictClassData valueForKey:@"start_date"],[dictClassData valueForKey:@"end_date"]]];
        [arrList addObject:[NSString stringWithFormat:@"Number of classes: %@",[dictClassData valueForKey:@"noof_classes"]]];
        [arrList addObject:[NSString stringWithFormat:@"Location: Ahmedabad"]];
        [arrList addObject:[NSString stringWithFormat:@"Professor: Vivek"]];
        [arrList addObject:[NSString stringWithFormat:@"Email: %@",[[aryUserDetail objectAtIndex:0] valueForKey:@"stu_email"]]];
        
    } @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    
}
#pragma mark - tableView Delegate

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section;
{
    return arrList.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath;
{
    @try{
        static NSString *Cell = @"Cell";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:Cell];
        cell.textLabel.text=[arrList objectAtIndex:indexPath.row];
        cell.textLabel.textColor=[UIColor whiteColor];
        cell.textLabel.font=[UIFont systemFontOfSize:12 ];
        return cell;
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView;
{
    return 1;
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if((indexPath.row)%2==0)
    {
        cell.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"orange-bar"]];
    }
    else{
        cell.backgroundColor = [UIColor colorWithPatternImage:[UIImage imageNamed:@"blue-bar"]];
    }
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if((indexPath.row)%2==0)
    {
        return 25;
    }
    else{
        return 19;
    }
}

#pragma mark - Clickevent

- (IBAction)onBtnAssignMentClicked:(id)sender {
    @try
    {
        UIStoryboard *storybord = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        AssignmentVC *objAssignmentVC=(AssignmentVC *)[storybord  instantiateViewControllerWithIdentifier:@"AssignmentVC"];
        objAssignmentVC.dictCourseDetail = [[NSDictionary alloc] init];
        objAssignmentVC.dictCourseDetail = dictClassData;
        [self.navigationController pushViewController:objAssignmentVC animated:YES];
    } @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
}

- (IBAction)onBtnAttendanceClicked:(id)sender {
    @try
    {
        UIStoryboard *storybord = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        AttendanceVC *objAssignmentVC=(AttendanceVC *)[storybord  instantiateViewControllerWithIdentifier:@"AttendanceVC"];
        [self.navigationController pushViewController:objAssignmentVC animated:YES];
        
    } @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
}

#pragma mark - Search Delegate

-(void)didSelectSearchedString:(NSString *)selectedString tableView:(id)tableView{
    [tableView toggleHidden:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
