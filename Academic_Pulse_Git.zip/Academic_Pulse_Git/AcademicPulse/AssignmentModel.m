//
//  AssignmentModel.m
//  AcademicPulse
//
//  Created by vivek on 11/19/15.
//  Copyright © 2015 com.zaptech. All rights reserved.
//

#import "AssignmentModel.h"
#import "ConstantList.h"
#import "APICall.h"
#import "Globals.h"

@implementation AssignmentModel

-(void)checkinBtnPressed:(user_completion_block)completion{
    
    @try{
        Globals *objGlobal = [Globals sharedManager];
        
        NSString *url_String = [NSString stringWithFormat:@"%@", CHECKIN_URL];
        NSDictionary *parameters = @{@"latitude":objGlobal.latitude,@"longitude":objGlobal.logitude,@"course_id":@"6",@"student_id":@"6"};
        
        [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* result, NSError*error, long code){
            if(error)
            {
                if(completion)
                {
                    completion(@"There was some error, please try again later",-1);
                }
            }
            else{
                if(completion)
                {
                    if([[result valueForKey:@"status"]integerValue]==1)
                    {
                        completion(@"CheckIn Successfully",0);
                    }
                    else{
                        completion(@"Email ID or Password is invalid",-1);
                    }
                }
            }
        }];
        
    } @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    
}

-(void)callCourseListService:(user_completion_block)completion{
    
    @try
    {
        
        Globals *objGlobal = [Globals sharedManager];
        
        NSString *url_String = [NSString stringWithFormat:@"%@", COURSE_LIST_URL];
        NSDictionary *parameters = @{@"student_id":@"6"};
        
        [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* result, NSError*error, long code){
            if(error)
            {
                if(completion)
                {
                    completion(@"There was some error, please try again later",-1);
                }
            }
            else{
                if(completion)
                {
                    if([[result valueForKey:@"status"]integerValue]==1)
                    {
                        objGlobal.dictGlobalCourseDetails = [result valueForKey:@"CourseDetails"];
                        completion(@"Course Details",0);
                    }
                }
            }
        }];
    } @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    
}

-(void)callCalendarEventListService:(user_completion_block)completion{
    
    Globals *objGlobal = [Globals sharedManager];
    NSString *url_String = [NSString stringWithFormat:@"%@", EVENT_LISTINGS_URL];
    NSDictionary *parameters = @{@"student_id":@"6"};
    
    [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* result, NSError*error, long code){
        if(error)
        {
            if(completion)
            {
                completion(@"There was some error, please try again later",-1);
            }
        }
        else{
            if(completion)
            {
                if([[result valueForKey:@"status"]integerValue]==1)
                {
                    objGlobal.dictGlobalCalendarEventList = [result valueForKey:@"CheckIn"];
                    completion(@"Calendar Event",0);
                }
            }
        }
    }];
}


-(void)callAttendanceCalendarEventListService:(user_completion_block)completion{
    
    Globals *objGlobal = [Globals sharedManager];
    NSString *url_String = [NSString stringWithFormat:@"%@", ATTENDANCE_EVENT_LISTINGS_URL];
    NSDictionary *parameters = @{@"student_id":@"6",@"courseid":@"3"};
    
    [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* result, NSError*error, long code){
        if(error)
        {
            if(completion)
            {
                completion(@"There was some error, please try again later",-1);
            }
        }
        else{
            if(completion)
            {
                if([[result valueForKey:@"status"]integerValue]==1)
                {
                    objGlobal.dictGlobalAttendanceCalendarEventList= [result valueForKey:@"AttandenceDetails"];
                    completion(@"Calendar Event",0);
                }
            }
        }
    }];
}






@end
