//
//  AssignmentModel.h
//  AcademicPulse
//
//  Created by vivek on 11/19/15.
//  Copyright © 2015 com.zaptech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AssignmentModel : NSObject

typedef void(^user_completion_block)(NSString *, int status);
-(void)checkinBtnPressed:(user_completion_block)completion;
-(void)callCourseListService:(user_completion_block)completion;
-(void)callCalendarEventListService:(user_completion_block)completion;
-(void)callAttendanceCalendarEventListService:(user_completion_block)completion;


@end
