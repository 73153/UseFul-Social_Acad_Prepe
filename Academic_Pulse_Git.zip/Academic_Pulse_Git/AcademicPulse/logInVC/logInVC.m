//
//  logInVC.m
//  AcademicPulse
//
//  Created by dhara on 10/6/15.
//  Copyright (c) 2015 com.zaptech. All rights reserved.
//

#import "logInVC.h"
#import "RESideMenu.h"
#import "UIViewController+NavigationBar.h"
#import "DEMOLeftMenuViewController.h"
#import "AppDelegate.h"
#import "DashboardVC.h"
#import "AFNetworking.h"
#import "ConstantList.h"
#import "APICall.h"
#import "MBProgressHUD.h"
#import "ValidationViewController.h"
#import "UIView+Toast.h"
#import "Globals.h"
#import "FTLocationManager.h"

#define DEGREES_TO_RADIANS(d) (d * M_PI / 180)
@interface logInVC ()<RESideMenuDelegate,UITextFieldDelegate>
{
    Globals *objGlobals;
}
@end

@implementation logInVC
@synthesize txtEmail,txtPassword;

#pragma mark - VC lifecycle

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setUpContentData];
    [self getLocations];
    [self.navigationController.navigationBar setHidden:YES];
}

#pragma mark - Custom Methods

-(void)setUpContentData {
    
    UIImageView *imgSearch=[[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 64, 64)];
    [imgSearch setImage:[UIImage imageNamed:@"message-icon"]];
    [imgSearch setContentMode:UIViewContentModeCenter];
    self.txtEmail.leftView=imgSearch;
    self.txtEmail.leftViewMode=UITextFieldViewModeAlways;
    txtEmail.delegate=self;
    txtPassword.delegate=self;
    
    UIImageView *imgSearchPass=[[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 64, 64)];
    [imgSearchPass setImage:[UIImage imageNamed:@"password-icon"]];
    [imgSearchPass setContentMode:UIViewContentModeCenter];
    self.txtPassword.leftView=imgSearchPass;
    self.txtPassword.leftViewMode=UITextFieldViewModeAlways;
    
    UIColor *color = [UIColor whiteColor];
    txtEmail.attributedPlaceholder =
    [[NSAttributedString alloc]
     initWithString:@"E-mail Address"
     attributes:@{NSForegroundColorAttributeName:color}];
    
    txtPassword.attributedPlaceholder =
    [[NSAttributedString alloc]
     initWithString:@"Password"
     attributes:@{NSForegroundColorAttributeName:color}];
  
    txtEmail.text = @"stu@test.com";
    txtPassword.text = @")b7jn!";
}
-(void)getLocations {
    @try
    {
        objGlobals  = [Globals sharedManager];
        FTLocationManager *locationManager = [FTLocationManager sharedManager];
        [locationManager updateLocationWithCompletionHandler:^(CLLocation *location, NSError *error, BOOL locationServicesDisabled) {
            
            NSString *outputText;
            if (error)
            {
                if(locationServicesDisabled) {
                    outputText = [NSString stringWithFormat:@"Failed to retrieve location. Location Services are disabled for this app.\nError: %@", error];
                } else {
                    outputText = [NSString stringWithFormat:@"Failed to retrieve location with error: %@", error];
                }
            }
            else {
                outputText = [NSString stringWithFormat:@"Received CLLocation: %@", location];
            }
            CLLocationCoordinate2D coord;
            coord.longitude = location.coordinate.longitude;
            coord.latitude = location.coordinate.latitude;
            // or a one shot fill
            coord = [location coordinate];
            NSLog(@"%f", coord.longitude);
            NSLog(@"%f", coord.latitude);
            objGlobals.latitude.string = [NSString stringWithFormat:@"%f",coord.latitude];
            objGlobals.logitude.string = [NSString stringWithFormat:@"%f",coord.longitude];
        }];
    } @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
}

#pragma mark - CLLocationManagerDelegate

- (void)locationManager:(CLLocationManager *)manager didFailWithError:(NSError *)error{
    NSLog(@"didFaileWithError: %@", error);
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Error" message:@"Fail to get you location!" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil, nil];
    
    [alert show];
}

- (void) locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations{
    
    NSLog(@"didUpdateLocations: %@", locations);
    
    CLLocation *location = [locations lastObject];
    if (location != nil)
    {
        //        _longitude.text = [NSString stringWithFormat:@"%.8f", location.coordinate.longitude];
        //        _latitude.text = [NSString stringWithFormat:@"%.8f", location.coordinate.latitude];
    }
}

#pragma mark - textField Delegate

- (BOOL)textFieldShouldReturn:(UITextField *)textField{
    @try{
        if(textField==txtPassword){
            [textField endEditing:true];
            
            if(![ValidationViewController validateEmail:txtEmail.text]){
                [self.view makeToast:@"User Email is not valid." duration:3.0f position:CSToastPositionBottom];
                return NO;
            }
            else if (txtPassword.text.length<5)
            {
                [self.view makeToast:@"Password minimum of 5 character." duration:3.0f position:CSToastPositionBottom];
                return NO;
            }
            
            NSMutableDictionary *params = [[NSMutableDictionary alloc] init];
            
            if(TARGET_IPHONE_SIMULATOR)
                
                [params setObject:@"1613e179cfec20cd0e7f9e81d6270e1b6a2e86ba4586dc2b61d12c2116a2fcfb" forKey:@"devicetoken"];
            else{
                NSString *strDevicetoken = [[NSUserDefaults standardUserDefaults] valueForKey:@"devicetoken"];
                if(strDevicetoken.length>0)
                    [params setObject:strDevicetoken forKey:@"devicetoken"];
                else
                    [params setObject:@"1613e179cfec20cd0e7f9e81d6270e1b6a2e86ba4586dc2b61d12c2116a2fcfb" forKey:@"devicetoken"];
                
            }
            
            [params setObject:txtEmail.text forKey:@"email"];
            [params setObject:@"IOS" forKey:@"devicetype"];
            [params setObject:txtPassword.text forKey:@"password"];
            
            [MBProgressHUD showHUDAddedTo:self.view animated:YES];
            [APICall callPostWebService:LOGIN_URL andDictionary:params completion:^(NSMutableDictionary *result, NSError *error, long code) {
                
                NSString *strStatus = [NSString stringWithFormat:@"%@",[result valueForKey:@"status"]];
                //                NSString *strStatus = [NSString stringWithFormat:@"%ld",(long)[[result valueForKey:@"status"] integerValue]];
                if([strStatus isEqualToString:@"1"]){
                    [MBProgressHUD hideAllHUDsForView:
                     self.view animated:YES];
                    objGlobals.dictGlobalLoginData = [result valueForKey:@"Userdetails"];
                    NSLog(@"JSON: %@", result);
                    
                    UIStoryboard *storybord = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
                    
                    DashboardVC *second=(DashboardVC *)[storybord  instantiateViewControllerWithIdentifier:@"DashboardVC"];
                    
                    /* it holds our main slidingVC viewController */
                    UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:second];
                    
                    /* it holds LeftViewController */
                    DEMOLeftMenuViewController *leftMenuViewController = [[DEMOLeftMenuViewController alloc] init];
                    
                    /*it Manage Both ViewCOntroller [slidingVC & LeftViewController] */
                    
                    RESideMenu *sideMenuViewController = [[RESideMenu alloc] initWithContentViewController:navigationController leftMenuViewController:leftMenuViewController rightMenuViewController:nil];
                    
                    sideMenuViewController.view.backgroundColor=[UIColor colorWithRed:(216/255.0f) green:(89/255.0f) blue:(36/255.0f) alpha:1.0f];
                    sideMenuViewController.menuPreferredStatusBarStyle = 1; // UIStatusBarStyleLightContent
                    sideMenuViewController.delegate = self;
                    sideMenuViewController.contentViewShadowOpacity =0;
                    
                    /* REsideMenu become RootViewCOntroller and manage both VC */
                    
                    AppDelegate *appdel = (AppDelegate *)[[UIApplication sharedApplication]delegate];
                    appdel.window.rootViewController = sideMenuViewController;
                }
                else
                {
                    [MBProgressHUD hideAllHUDsForView:
                     self.view animated:YES];
                    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Login"message:[result valueForKey:@"msg"] delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil,nil];
                    [alert show];
                }
            }];
        }
        return true;
    } @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
}


#pragma mark - clickevent
- (IBAction)btnForgotPasswordClicked:(id)sender {
    @try
    {
        
        NSMutableDictionary *params = [[NSMutableDictionary alloc] init];
        [params setObject:txtEmail.text forKey:@"email"];
        
        if(![ValidationViewController validateEmail:txtEmail.text]){
            [self.view makeToast:@"User Email is not valid." duration:3.0f position:CSToastPositionBottom];
            return;
        }
        
        [MBProgressHUD showHUDAddedTo:self.view animated:YES];
        [APICall callPostWebService:FORGOT_PASSWORD_URL andDictionary:params completion:^(NSMutableDictionary *result, NSError *error, long code) {
            if([result valueForKey:@"status"]){
                [MBProgressHUD hideAllHUDsForView:
                 self.view animated:YES];
            }
            
            else
            {
                [MBProgressHUD hideAllHUDsForView:
                 self.view animated:YES];
            }
        }];
        
    } @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}
@end
