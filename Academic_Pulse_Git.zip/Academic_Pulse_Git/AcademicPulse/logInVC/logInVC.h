//
//  logInVC.h
//  AcademicPulse
//
//  Created by dhara on 10/6/15.
//  Copyright (c) 2015 com.zaptech. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <CoreLocation/CoreLocation.h>

@interface logInVC : UIViewController<CLLocationManagerDelegate>
{
}
@property (strong, nonatomic) IBOutlet UITextField *txtEmail;
@property (strong, nonatomic) IBOutlet UITextField *txtPassword;
- (IBAction)btnForgotPasswordClicked:(id)sender;

@end
