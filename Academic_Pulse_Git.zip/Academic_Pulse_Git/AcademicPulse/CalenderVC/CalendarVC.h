//
//  CalendarVC.h
//  Academic Pulse
//
//  Created by vivek on 10/1/15.
//  Copyright (c) 2015 vivek. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MAWeekView.h"
#import "MAWeekView.h" // MAWeekViewDataSource,MAWeekViewDelegate

@class MAEventKitDataSource;
@interface CalendarVC :  UIViewController<MAWeekViewDataSource,MAWeekViewDelegate> {
    MAEventKitDataSource *_eventKitDataSource;
    
    NSDate *WeekStartDate,*WeekEndDate;
    
    NSDictionary *eventData;
    
    MAWeekView *objWeekView;
}

@property(nonatomic,strong) NSMutableArray *eventDic;

@property (weak, nonatomic) IBOutlet MAWeekView *weekView;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *btmHeight;
@property (strong, nonatomic) IBOutlet NSLayoutConstraint *topHeight;

@end

