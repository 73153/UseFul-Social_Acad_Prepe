//
//  CalendarVC.m
//  Academic Pulse
//
//  Created by vivek on 10/1/15.
//  Copyright (c) 2015 vivek. All rights reserved.
//

#import "CalendarVC.h"
#import "MAWeekView.h"
#import "MAEvent.h"
#import "MAEventKitDataSource.h"
#import "RESideMenu.h"
#import "UIViewController+NavigationBar.h"
#import "logInVC.h"
#import "AppDelegate.h"
#import "logoView.h"
#import "ConstantList.h"
#import "TabVIew.h"
#import "MBProgressHUD.h"
#import "APICall.h"
#import "Globals.h"
#import "UIView+Toast.h"
#import "MADayView.h"

#define DATE_COMPONENTS (NSYearCalendarUnit| NSMonthCalendarUnit | NSDayCalendarUnit | NSWeekCalendarUnit |  NSHourCalendarUnit | NSMinuteCalendarUnit | NSSecondCalendarUnit | NSWeekdayCalendarUnit | NSWeekdayOrdinalCalendarUnit)
#define CURRENT_CALENDAR [NSCalendar currentCalendar]

@interface CalendarVC ()<SearchDelegate>
{
    logoView *log;
    TabVIew *tab;
    
}
@end

@implementation CalendarVC
@synthesize weekView;

#pragma mark - VC lifecycle

- (void)viewDidLoad {
    
    [super viewDidLoad];
    [self setMenuIconForSideBar:@"menu"];
    [self setUpContentData];
    [self getCalendarEvent];
}

-(void)viewDidAppear:(BOOL)animated{
    UINib * mainView = [UINib nibWithNibName:@"logoView" bundle:nil];
    log =(logoView *)[mainView instantiateWithOwner:self options:nil][0];
    if(IS_IPHONE_6_PLUS)
    {
        log.frame=CGRectMake(0, 5, self.view.frame.size.width, log.frame.size.height+20);
    }else
        log.frame=CGRectMake(0, 5, self.view.frame.size.width, log.frame.size.height);
    [self.view addSubview:log];
}

#pragma mark - Custom Methods

-(void)setUpContentData
{
    [self.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:@"header"] forBarMetrics:UIBarMetricsDefault];
    
    [self.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:@"header"] forBarMetrics:UIBarMetricsDefault];
    
    self.navigationItem.title = @"CALENDAR";
    self.navigationController.navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName: [UIColor whiteColor],NSFontAttributeName: [UIFont fontWithName:@"Helvetica" size:15.0f]};
    
    UINib * mainViewTab = [UINib nibWithNibName:@"TabView" bundle:nil];
    tab =(TabVIew *)[mainViewTab instantiateWithOwner:self options:nil][0];
    if(IS_IPHONE_6_PLUS)
    {
        tab.frame=CGRectMake(0,self.view.frame.size.height-114, self.view.frame.size.width, tab.frame.size.height+10);
        [self.view addSubview:tab];
        
        _topHeight.constant=130;
    }else
    {
        tab.frame=CGRectMake(0,self.view.frame.size.height-104, self.view.frame.size.width, tab.frame.size.height);
        
        [self.view addSubview:tab];
        
    }
    
    if (IS_IPHONE_5) {
        _btmHeight.constant=130;
        _topHeight.constant=115;
    }
    else if(IS_IPHONE_4)
    {
        _btmHeight.constant=110;
    }
}

-(void)getCalendarEvent
{
    weekView.dataSource = self;
    weekView.delegate=self;
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    Globals *objGlob = [Globals sharedManager];
    [objGlob.objAssinmentModel callCalendarEventListService:^(NSString *sta, int status) {
        if([sta isEqualToString:@"Calendar Event"]){
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
            
            _eventDic = [objGlob.dictGlobalCalendarEventList mutableCopy];
            [weekView reloadData];
        }
        else{
            [MBProgressHUD hideAllHUDsForView:self.view animated:YES];
            
        }
    }];
}

-(void)serviceCall
{
    WeekEndDate =[self addDays:7 toDate:WeekStartDate];
    [self getEvents:WeekStartDate:WeekEndDate];
}

#pragma mark Calendar delegate

- (void)weekView:(MAWeekView *)weekView eventDragged:(MAEvent *)event
{
    
}

- (BOOL)weekView:(MAWeekView *)weekView eventDraggingEnabled:(MAEvent *)event
{
    return false;
}

-(void)weekView:(MAWeekView *)WeekView weekDidChange:(NSDate *)week
{
    WeekStartDate=week;
    objWeekView=WeekView;
    [self serviceCall];
}

#ifdef USE_EVENTKIT_DATA_SOURCE

- (NSArray *)weekView:(MAWeekView *)WeekView eventsForDate:(NSDate *)startDate {
    counter--;
    if(WeekStartDate==nil)
    {
        WeekStartDate=startDate;
        objWeekView=WeekView;
    }
    
    NSDateFormatter* dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:DATE_FORMAT_Y_M_D_H_M_S];
    NSMutableArray *arr=MUTABLEARRAY;
    for (int i=0; i< _eventDic.count; i++) {
        
        //        NSDate *fromDate=[dateFormatter dateFromString: [[_eventDic objectAtIndex:i] valueForKey:@"start_date"]];
        //        NSDate *toDate=[dateFormatter dateFromString: [[_eventDic objectAtIndex:i] valueForKey:@"end_date"]];
        //         NSDate *CurrentDate=[dateFormatter dateFromString: [[_eventDic objectAtIndex:i] valueForKey:@"end_date"]];
        //
        //        NSTimeInterval fromTime = [fromDate timeIntervalSinceReferenceDate];
        //        NSTimeInterval toTime = [toDate timeIntervalSinceReferenceDate];
        //        NSTimeInterval currTime = [CurrentDate timeIntervalSinceReferenceDate];
        
        NSArray *aryEvent = [_eventDic mutableCopy];
        NSString *startdate=[[[[aryEvent objectAtIndex:i] valueForKey:@"event_datetime"] componentsSeparatedByString:STR_SPACE] objectAtIndex:0];
        NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
        NSDateComponents *components = [[NSDateComponents alloc] init];
        components.day =1;
        NSDate *newDate = [calendar dateByAddingComponents:components toDate:startDate options:0];
        NSString *CalendarStartDate=[NSString stringWithFormat:@"%@",newDate];
        CalendarStartDate=[[CalendarStartDate componentsSeparatedByString:STR_SPACE] objectAtIndex:0];
        if([CalendarStartDate isEqualToString:startdate]){
            NSLog(@"CalendarStartDate %@ and startdate = %@",CalendarStartDate,startdate);
            
            [arr addObject:[self event :i : startDate ]];
        }
    }
    return arr;
}
#else

static int counter = 7 * 5;
- (NSArray *)weekView:(MAWeekView *)WeekView eventsForDate:(NSDate *)startDate {
    counter--;
    if(WeekStartDate==nil)
    {
        WeekStartDate=startDate;
        objWeekView=WeekView;
    }
    
    NSDateFormatter* dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:DATE_FORMAT_Y_M_D_H_M_S];
    NSMutableArray *arr=MUTABLEARRAY;
    for (int i=0; i< _eventDic.count; i++) {
        
        //        NSDate *fromDate=[dateFormatter dateFromString: [[_eventDic objectAtIndex:i] valueForKey:@"start_date"]];
        //        NSDate *toDate=[dateFormatter dateFromString: [[_eventDic objectAtIndex:i] valueForKey:@"end_date"]];
        //         NSDate *CurrentDate=[dateFormatter dateFromString: [[_eventDic objectAtIndex:i] valueForKey:@"end_date"]];
        //
        //        NSTimeInterval fromTime = [fromDate timeIntervalSinceReferenceDate];
        //        NSTimeInterval toTime = [toDate timeIntervalSinceReferenceDate];
        //        NSTimeInterval currTime = [CurrentDate timeIntervalSinceReferenceDate];
        NSArray *aryEvent = [_eventDic mutableCopy];
        NSString *startdate=[[[[aryEvent objectAtIndex:i] valueForKey:@"event_datetime"] componentsSeparatedByString:STR_SPACE] objectAtIndex:0];
        
        NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
        NSDateComponents *components = [[NSDateComponents alloc] init];
        components.day =1;
        NSDate *newDate = [calendar dateByAddingComponents:components toDate:startDate options:0];
        NSString *CalendarStartDate=[NSString stringWithFormat:@"%@",newDate];
        CalendarStartDate=[[CalendarStartDate componentsSeparatedByString:STR_SPACE] objectAtIndex:0];
        if([CalendarStartDate isEqualToString:startdate]){
            
            NSLog(@"CalendarStartDate %@ and startdate = %@",CalendarStartDate,startdate);
            
            [arr addObject:[self event :i : startDate ]];
        }
    }
    return arr;
}

#endif

- (NSDate *)addDays:(NSInteger)days toDate:(NSDate *)originalDate {
    NSDateComponents *components= [[NSDateComponents alloc] init];
    [components setDay:days];
    NSCalendar *calendar = [NSCalendar currentCalendar];
    return [calendar dateByAddingComponents:components toDate:originalDate options:0];
}

- (MAEvent *)event {
    static int counter;
    
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
    
    [dict setObject:[NSString stringWithFormat:@"number %i", counter++] forKey:@"test"];
    
    MAEvent *event = [[MAEvent alloc] init];
    event.backgroundColor = [UIColor blackColor];
    event.textColor = [UIColor redColor];
    event.allDay = NO;
    event.userInfo = dict;
    return event;
}

- (MAEventKitDataSource *)eventKitDataSource {
    if (!_eventKitDataSource) {
        _eventKitDataSource = [[MAEventKitDataSource alloc] init];
    }
    return _eventKitDataSource;
}

- (MAEvent *)event : (int)index : (NSDate *)date {
    
    static int counter;
    NSDateFormatter* dateFormatter = [[NSDateFormatter alloc] init];
    
    [dateFormatter setDateFormat:dateFormatYearMonthDateHiphenWithTime];
    
    NSArray *aryEvent = [_eventDic mutableCopy];
    NSString *startdateStr=[[[[aryEvent objectAtIndex:index] valueForKey:@"event_datetime"] componentsSeparatedByString:STR_SPACE] objectAtIndex:0];
    NSDate *startdate=[dateFormatter dateFromString:startdateStr];
    
    NSMutableDictionary *dict = [[NSMutableDictionary alloc] init];
    [dict setObject:[NSString stringWithFormat:@"number %i", counter++] forKey:@"test"];
    MAEvent *event = [[MAEvent alloc] init];
    event.backgroundColor = [UIColor blackColor];
    event.textColor = [UIColor whiteColor];
    event.start=startdate;
    event.EventTag=index;
    
    //event.title=[[_eventDic objectAtIndex:index] valueForKey:@"name"];
    ////  Event Title
    // Uncoment if you want date on title of event
    /*
     NSString *strStartdate=[[_eventDic objectAtIndex:index] valueForKey:@"start_date"];
     
     NSDate *displaydate=[dateFormatter dateFromString:strStartdate];
     
     NSString *strEnddate=[[_eventDic objectAtIndex:index] valueForKey:@"end_date"];
     
     NSDate *displayEnddate=[dateFormatter dateFromString:strEnddate];
     
     [dateFormatter setDateFormat:TIME_FORMAT_h_m_A];
     */
    
    //event.title=[[[dateFormatter stringFromDate:displaydate] stringByAppendingString:[NSString stringWithFormat:@"-%@",[dateFormatter stringFromDate:displayEnddate]]] stringByAppendingString:[NSString stringWithFormat:@" Name:%@", [[_eventDic objectAtIndex:index]valueForKey:@"name"] ] ];
    
    event.title=[[aryEvent objectAtIndex:index] valueForKey:@"event_title"];
    event.allDay = NO;
    event.userInfo = [_eventDic objectAtIndex:index];
    
    //Event Time
    
    NSArray *startTimeComp = [[[[[aryEvent objectAtIndex:index] valueForKey:@"event_datetime"] componentsSeparatedByString:STR_SPACE] objectAtIndex:1] componentsSeparatedByString:@":"];
    
    
    NSDateComponents *components = [CURRENT_CALENDAR components:DATE_COMPONENTS fromDate:date];
    [components setHour:[[startTimeComp objectAtIndex:0] intValue]];
    [components setMinute:[[startTimeComp objectAtIndex:1] intValue]];
    [components setSecond:[[startTimeComp objectAtIndex:2] intValue]];
    event.start = [CURRENT_CALENDAR dateFromComponents:components];
    
    NSArray *endTimeComp = [[[[[aryEvent objectAtIndex:index] valueForKey:@"event_datetime"] componentsSeparatedByString:STR_SPACE] objectAtIndex:1] componentsSeparatedByString:@":"];
    
    [components setHour:[[endTimeComp objectAtIndex:0] intValue]+2];
    [components setMinute:[[endTimeComp objectAtIndex:1] intValue]+2];
    [components setSecond:[[endTimeComp objectAtIndex:1] intValue]+2];
    event.end = [CURRENT_CALENDAR dateFromComponents:components];
    
    event.backgroundColor = [UIColor blackColor];
    //  event.textColor=[UIColor colorWithRed:(0/255.0) green:(114/255.0) blue:(158/255.0) alpha:1];
    event.textColor=[UIColor whiteColor];
    return event;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Search Delegate
-(void)didSelectSearchedString:(NSString *)selectedString tableView:(id)tableView{
    [tableView toggleHidden:YES];
}

#pragma mark Webservice call event
-(void)getEvents: (NSDate*)startDate :(NSDate *)endDate{
    
    //    // Local server
    //    webservice =[WebServiceClass shareInstance];
    //    webservice.delegate=self;
    
    NSDateFormatter *formatter=[[NSDateFormatter alloc] init];
    formatter.dateFormat=DATE_FORMAT_Y_M_D;
    NSString *startdate=[formatter stringFromDate:startDate];
    startdate=[startdate stringByAppendingString:@" 00:00:00"];
    NSString *enddate=[formatter stringFromDate:endDate];
    enddate=[enddate stringByAppendingString:@" 24:00:00"];
    
    formatter=nil;
    
    //    if ([SingletonClass  CheckConnectivity]) {
    //        UserInformation *userInfo=[UserInformation shareInstance];
    //        [SingletonClass ShareInstance].isCalendarUpdate=FALSE;
    //        // NSString *strURL = [NSString stringWithFormat:@"{\"user_id\":\"%d\",\"team_id\":\"%d\",\"start_date\":\"%@\",\"last_date\":\"%@\"}",userInfo.userId,userInfo.userSelectedTeamid,startdate,enddate];
    //        NSString *strURL = [NSString stringWithFormat:@"{\"user_id\":\"%d\",\"type\":\"%d\",\"team_id\":\"%d\",\"start_date\":\"%@\",\"last_date\":\"%@\"}",userInfo.userId,userInfo.userType,userInfo.userSelectedTeamid,startdate,enddate];
    //
    //        [SingletonClass addActivityIndicator:self.view];
    //
    //        [webservice WebserviceCall:webServiceGetEvents :strURL :getWeekEventTag];
    //
    //
    //    }else{
    //
    //        [SingletonClass initWithTitle:EMPTYSTRING message:INTERNET_NOT_AVAILABLE delegate:nil btn1:@"Ok"];
    //
    //    }
}

/* Implementation for the MAWeekViewDelegate protocol */
- (void)weekView:(MAWeekView *)weekView eventTapped:(MAEvent *)event {
    
    NSArray *arrController=[self.navigationController viewControllers];
    BOOL Status=FALSE;
    for (id object in arrController)
    {
        //        if ([object isKindOfClass:[CalendarEventDetails class]])
        //        {
        //            Status=TRUE;
        //            CalendarEventDetails *eventDetails=(CalendarEventDetails*)(object);
        //            eventDetails.eventDetailsDic=[_eventDic objectAtIndex:event.EventTag];
        //            eventDetails.strMoveControllerName=@"WeekViewController";
        //            if (_objNotificationData) {
        //                eventDetails.objNotificationData=_objNotificationData;
        //            }
        //            [self.navigationController popToViewController:eventDetails animated:NO];
        //        }
    }
    if (Status==FALSE)
    {
        //        CalendarEventDetails *eventDetails=[[CalendarEventDetails alloc] init];
        //        eventDetails.eventDetailsDic=[_eventDic objectAtIndex:event.EventTag];
        //        eventDetails.strMoveControllerName=@"WeekViewController";
        //        if (_objNotificationData) {
        //            eventDetails.objNotificationData=_objNotificationData;
        //        }
        //        [self.navigationController pushViewController:eventDetails animated:NO];
    }
}

@end