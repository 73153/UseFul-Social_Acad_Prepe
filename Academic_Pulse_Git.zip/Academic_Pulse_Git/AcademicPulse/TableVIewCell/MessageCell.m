//
//  MessageCell.m
//  AcademicPulse
//
//  Created by dhara on 11/7/15.
//  Copyright © 2015 com.zaptech. All rights reserved.
//

#import "MessageCell.h"

@implementation MessageCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
