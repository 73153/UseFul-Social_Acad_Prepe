//
//  MessageCell.h
//  AcademicPulse
//
//  Created by dhara on 11/7/15.
//  Copyright © 2015 com.zaptech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MessageCell : UITableViewCell

@end
