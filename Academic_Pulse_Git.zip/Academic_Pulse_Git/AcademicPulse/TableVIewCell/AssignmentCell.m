//
//  AssignmentCell.m
//  AcademicPulse
//
//  Created by pradip.r on 11/7/15.
//  Copyright (c) 2015 com.zaptech. All rights reserved.
//

#import "AssignmentCell.h"

@implementation AssignmentCell

@synthesize btnCustID,btnDueDate,btnTotalPoints;
- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
