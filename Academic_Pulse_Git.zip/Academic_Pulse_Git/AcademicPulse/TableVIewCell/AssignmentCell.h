//
//  AssignmentCell.h
//  AcademicPulse
//
//  Created by pradip.r on 11/7/15.
//  Copyright (c) 2015 com.zaptech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AssignmentCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *lblTrainingName;
@property (strong, nonatomic) IBOutlet UIButton *btnCustID;
@property (strong, nonatomic) IBOutlet UIButton *btnDueDate;
@property (strong, nonatomic) IBOutlet UIButton *btnTotalPoints;

@end
