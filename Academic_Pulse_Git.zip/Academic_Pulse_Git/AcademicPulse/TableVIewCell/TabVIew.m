//
//  TabVIew.m
//  AcademicPulse
//
//  Created by dhara on 11/10/15.
//  Copyright © 2015 com.zaptech. All rights reserved.
//

#import "TabVIew.h"
#import "ConstantList.h"
#import "MessageVC.h"
#import "DashboardVC.h"
#import "CalendarVC.h"
#import "RESideMenu.h"
#import "UIViewController+NavigationBar.h"
#import "RESideMenu.h"
#import "UIViewController+NavigationBar.h"
@implementation TabVIew

+ (TabVIew*) TabVIew
{
    NSArray* array = [[NSBundle mainBundle] loadNibNamed:@"TabVIew" owner:nil options:nil];
    return [array objectAtIndex:0];
}

#pragma mark - Layout Method

- (void)setNeedsLayout{
    if( IS_IPHONE_6){
        [_startSpace setConstant:40];
        [_gap1 setConstant:60];
        [_gap2 setConstant:60];
        [_gap3 setConstant:60];
    }
    else if (IS_IPHONE_6_PLUS)
    {
        [_startSpace setConstant:50];
        [_gap1 setConstant:60];
        [_gap2 setConstant:60];
        [_gap3 setConstant:60];
    }
    else{
        [_startSpace setConstant:35];
        [_gap1 setConstant:45];
        [_gap2 setConstant:45];
        [_gap3 setConstant:45];
    }
}

/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect {
 // Drawing code
 }
 */

#pragma mark - Clickevent

- (IBAction)btnDashboardClicked:(id)sender {
    UIStoryboard *storybord = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    DashboardVC *second=(DashboardVC *)[storybord  instantiateViewControllerWithIdentifier:@"DashboardVC"];
    UIViewController *fVC = [self parentViewController];
    [fVC.sideMenuViewController setContentViewController:[[UINavigationController alloc] initWithRootViewController:second]
                                                animated:YES];
    [fVC.sideMenuViewController hideMenuViewController];
    
}

- (UIViewController *)parentViewController {
    UIResponder *responder = self;
    while ([responder isKindOfClass:[UIView class]])
        responder = [responder nextResponder];
    return (UIViewController *)responder;
}

- (IBAction)btnMessageClicked:(id)sender {
    UIStoryboard *storybord = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    MessageVC *second=(MessageVC *)[storybord  instantiateViewControllerWithIdentifier:@"MessageVC"];
    UIViewController *fVC = [self parentViewController];
    [fVC.sideMenuViewController setContentViewController:[[UINavigationController alloc] initWithRootViewController:second]
                                                animated:YES];
    [fVC.sideMenuViewController hideMenuViewController];
    
}

- (IBAction)btnCalendarClicked:(id)sender {
    UIStoryboard *storybord = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    CalendarVC *second=(CalendarVC *)[storybord  instantiateViewControllerWithIdentifier:@"CalendarVC"];
    UIViewController *fVC = [self parentViewController];
    [fVC.sideMenuViewController setContentViewController:[[UINavigationController alloc] initWithRootViewController:second]
                                                animated:YES];
    [fVC.sideMenuViewController hideMenuViewController];
}

- (IBAction)btnProfilebClicked:(id)sender {
    //    UIStoryboard *storybord = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    //
    //    Dashboard *second=(Dashboard *)[storybord  instantiateViewControllerWithIdentifier:@"Dashboard"];
    //    UIViewController *fVC = [self parentViewController];
    //    [fVC.sideMenuViewController setContentViewController:[[UINavigationController alloc] initWithRootViewController:second]
    //                                                animated:YES];
    //    [fVC.sideMenuViewController hideMenuViewController];
}
@end
