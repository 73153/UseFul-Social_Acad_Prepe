//
//  TabVIew.h
//  AcademicPulse
//
//  Created by dhara on 11/10/15.
//  Copyright © 2015 com.zaptech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TabVIew : UIView


@property (weak, nonatomic) IBOutlet NSLayoutConstraint *gap1;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *gap2;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *gap3;

- (IBAction)btnDashboardClicked:(id)sender;
- (IBAction)btnMessageClicked:(id)sender;
- (IBAction)btnCalendarClicked:(id)sender;
- (IBAction)btnProfilebClicked:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *btnDashBoard;


@property (weak, nonatomic) IBOutlet NSLayoutConstraint *startSpace;
@end
