//
//  logoView.m
//  AcademicPulse
//
//  Created by dhara on 11/7/15.
//  Copyright © 2015 com.zaptech. All rights reserved.
//

#import "logoView.h"
#import "AssignmentModel.h"
#import "Globals.h"
#import "UIView+Toast.h"
#import "PopUpTableViewController.h"
#import "ConstantList.h"
@implementation logoView

+ (logoView*) logoView
{
    NSArray* array = [[NSBundle mainBundle] loadNibNamed:@"logoView" owner:nil options:nil];
    return [array objectAtIndex:0];
}
/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect {
 // Drawing code
 }
 */

#pragma mark - Clickevent

- (IBAction)btnCheckInPressed:(id)sender {
    @try
    {
        Globals *objGlob = [Globals sharedManager];
        [objGlob.objAssinmentModel checkinBtnPressed:^(NSString *sta, int status) {
            if([sta isEqualToString:@"CheckIn Successfully"]){
                UIViewController *viewParent = [self parentViewController];
                PopUpTableViewController *objPopUpTableController = objGlob.objPopUpTableViewController;
                NSArray *aryCourseDetail = [objGlob.dictGlobalCourseDetails mutableCopy];
                NSMutableArray *aryCourseId = [[NSMutableArray alloc] init];
                for (int i=0; i<aryCourseDetail.count; i++) {
                    [aryCourseId addObject:[NSString stringWithFormat:@"%@",[[aryCourseDetail objectAtIndex:i] valueForKey:@"course_name"]]];
                }
                objPopUpTableController.dataSource = aryCourseId;
                if (IS_IPHONE_6_PLUS)
                    objPopUpTableController.tableView.frame = CGRectMake(viewParent.view.frame.size.width/2-80,viewParent.view.frame.size.height/2-80, 160,180);
                else
                    objPopUpTableController.tableView.frame = CGRectMake(viewParent.view.frame.size.width/2-58,viewParent.view.frame.size.height/2-60, 160,180);
                
                objPopUpTableController.delegate = viewParent;
                objPopUpTableController.view.layer.zPosition = 100;
                //    self.objPopUpTableController.delegate = self;
                [viewParent.view addSubview:objPopUpTableController.tableView];
                [objPopUpTableController toggleHidden:NO];
                objPopUpTableController.tableView.layer.borderWidth = 2;
                objPopUpTableController.tableView.layer.borderColor = [[UIColor blackColor] CGColor];
            }
            else{
                UIViewController *viewParent = [self parentViewController];
                [viewParent.view makeToast:@"CheckIn Failed"];
            }
        }];
        
    } @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
}

#pragma mark - parentViewController

- (UIViewController *)parentViewController {
    UIResponder *responder = self;
    while ([responder isKindOfClass:[UIView class]])
        responder = [responder nextResponder];
    return (UIViewController *)responder;
}
@end
