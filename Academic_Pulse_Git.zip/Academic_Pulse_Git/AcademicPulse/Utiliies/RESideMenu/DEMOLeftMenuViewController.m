//
//  DEMOMenuViewController.m
//  RESideMenuExample
//
//  Created by Roman Efimov on 10/10/13.
//  Copyright (c) 2013 Roman Efimov. All rights reserved.
//

#import "DEMOLeftMenuViewController.h"
#import "logInVC.h"
#import "AssignmentVC.h"
#import "MessageVC.h"
#import "AttendanceVC.h"
#import "ResultVC.h"
#import "CalendarVC.h"
#import "DashboardVC.h"
#import "ClassListVC.h"
#import "MessageVC.h"
#import "ConstantList.h"
//#import "DEMOSecondViewController.h"

@interface DEMOLeftMenuViewController ()
{
    NSArray *arrTitles;
    NSArray *arrImages;
    UIView *headerView;
}

@property (strong, readwrite, nonatomic) UITableView *tableView;

@end

@implementation DEMOLeftMenuViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
    arrTitles = @[@"Dashboard", @"Calendar", @"Classes", @"Message Center", @"Profile & Settings ", @"Bulletin Board",@"Result"];
    arrImages = @[@"dashboard-icon", @"calander-icon", @"classes-icon", @"message-icon-dashboard", @"profile-icon", @"bulletin-icon",@"result-icon"];
    self.tableView = ({
        UITableView *tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0 , self.view.frame.size.width,self.view.frame.size.height) style:UITableViewStylePlain];
        tableView.autoresizingMask = UIViewAutoresizingFlexibleTopMargin | UIViewAutoresizingFlexibleBottomMargin | UIViewAutoresizingFlexibleWidth;
        tableView.delegate = self;
        tableView.dataSource = self;
        tableView.opaque = NO;
        // tableView.backgroundColor = [UIColor colorWithRed:(216/255.0f) green:(89/255.0f) blue:(36/255.0f) alpha:1.0f];
        tableView.backgroundView = nil;
        tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        tableView.bounces = NO;
        tableView.backgroundView = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"sidebar"]];

       
        tableView;
    });
    
    if(IS_IPHONE_6_PLUS)
       {
          headerView = [[UIView alloc] initWithFrame:CGRectMake(10, 15, 272, 100)];
           
           UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(30, 25, 163, 66)];
           imageView.image = [UIImage imageNamed:@"logo-dashboard"];
           [headerView addSubview:imageView];


       }
    else
    {
       headerView = [[UIView alloc] initWithFrame:CGRectMake(10, 15, 272, 100)];
        
        UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(20, 25, 130, 56)];
        imageView.image = [UIImage imageNamed:@"logo-dashboard"];
        
        [headerView addSubview:imageView];

    }
    
    self.tableView.tableHeaderView = headerView;
    [self.view addSubview:self.tableView];
}

#pragma mark -
#pragma mark UITableView Delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    switch (indexPath.row) {
        case 0: {
            UIStoryboard *storybord = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            
            DashboardVC *objDashboardVC=(DashboardVC *)[storybord  instantiateViewControllerWithIdentifier:@"DashboardVC"];

            [self.sideMenuViewController setContentViewController:[[UINavigationController alloc] initWithRootViewController:objDashboardVC]
                                                         animated:YES];
            [self.sideMenuViewController hideMenuViewController];}
            break;
        case 1:{
            UIStoryboard *storybord = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            
            CalendarVC *objCalendarVC=(CalendarVC *)[storybord  instantiateViewControllerWithIdentifier:@"CalendarVC"];
            
            [self.sideMenuViewController setContentViewController:[[UINavigationController alloc] initWithRootViewController:objCalendarVC]
                                                         animated:YES];
            [self.sideMenuViewController hideMenuViewController];}
                break;

    
        case 2: {
            UIStoryboard *storybord = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            
            ClassListVC *objClassListVC=(ClassListVC *)[storybord  instantiateViewControllerWithIdentifier:@"ClassListVC"];
            
            [self.sideMenuViewController setContentViewController:[[UINavigationController alloc] initWithRootViewController:objClassListVC]
                                                         animated:YES];
            [self.sideMenuViewController hideMenuViewController];
        }
            break;

        case 3: {
            UIStoryboard *storybord = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            
            MessageVC *objMessageVC=(MessageVC *)[storybord  instantiateViewControllerWithIdentifier:@"MessageVC"];
            
            [self.sideMenuViewController setContentViewController:[[UINavigationController alloc] initWithRootViewController:objMessageVC]
                                                         animated:YES];
            [self.sideMenuViewController hideMenuViewController];}
            break;

            
        case 5: {
            UIStoryboard *storybord = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            
            MessageVC *objMessageVC=(MessageVC *)[storybord  instantiateViewControllerWithIdentifier:@"MessageVC"];
            
            [self.sideMenuViewController setContentViewController:[[UINavigationController alloc] initWithRootViewController:objMessageVC]
                                                         animated:YES];
            [self.sideMenuViewController hideMenuViewController];}
            break;
            

            
        case 6: {
            UIStoryboard *storybord = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
            
            ResultVC *objResultVC=(ResultVC *)[storybord  instantiateViewControllerWithIdentifier:@"ResultVC"];
            
            [self.sideMenuViewController setContentViewController:[[UINavigationController alloc] initWithRootViewController:objResultVC]
                                                         animated:YES];
            [self.sideMenuViewController hideMenuViewController];}
            break;
            

        default:
            break;
    }
}

#pragma mark -
#pragma mark UITableView Datasource

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 40;
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    
       return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)sectionIndex
{
    return arrTitles.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *cellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cellIdentifier];
    
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cellIdentifier];
        cell.backgroundColor = [UIColor clearColor];
        cell.textLabel.highlightedTextColor = [UIColor whiteColor];
        cell.selectedBackgroundView = [[UIView alloc] init];
    }
    cell.selectionStyle=UITableViewCellSelectionStyleNone;
    UIImage *img=[UIImage imageNamed:arrImages[indexPath.row]];
    
    UIImageView *imageView = [[UIImageView alloc] init];
    imageView.image = img;
    int yPos =(cell.frame.size.height -img.size.height)/2;
    [imageView setFrame:CGRectMake(15, yPos, img.size.width, img.size.height)];
    [cell.contentView addSubview:imageView];
    
    UILabel *lbl=[[UILabel alloc]initWithFrame:CGRectMake(imageView.frame.origin.x+imageView.frame.size.width+10, cell.textLabel.frame.origin.y+7, cell.frame.size.width-imageView.frame.size.width, 30)];
    lbl.text = arrTitles[indexPath.row];
    lbl.font=[UIFont systemFontOfSize:13.0];
    lbl.textColor=[UIColor whiteColor];
    lbl.backgroundColor=[UIColor clearColor];
    [cell.contentView addSubview:lbl];
    
    //CGRect frame = CGRectMake(imageView.frame.origin.x+img.size.width+10, cell.textLabel.frame.origin.y, cell.textLabel.frame.size.width, cell.textLabel.frame.size.height);
   // cell.textLabel.frame =  frame;
   // cell.textLabel.contentMode = UIViewContentModeScaleAspectFit;
    //cell.textLabel.frame=CGRectMake(imageView.frame.origin.x+img.size.width+10, cell.textLabel.frame.origin.y, cell.textLabel.frame.size.width, cell.textLabel.frame.size.height);

    
    if(indexPath.row>0)
    {
        if(IS_IPHONE_6)
        {
            UIView *whiteDivider = [[UIView alloc] initWithFrame:CGRectMake(7, 1, cell.bounds.size.width-155, 1)];
            whiteDivider.backgroundColor = [UIColor whiteColor];
            whiteDivider.alpha=0.5;
            [cell.contentView addSubview:whiteDivider];

        }
        else if(IS_IPHONE_6_PLUS)
        {
            UIView *whiteDivider = [[UIView alloc] initWithFrame:CGRectMake(7, 1, cell.bounds.size.width-140, 1)];
            whiteDivider.backgroundColor = [UIColor whiteColor];
            whiteDivider.alpha=0.5;
            [cell.contentView addSubview:whiteDivider];
            
 
        }
        else
        {
            UIView *whiteDivider = [[UIView alloc] initWithFrame:CGRectMake(7, 1, cell.bounds.size.width-180, 1)];
            whiteDivider.backgroundColor = [UIColor whiteColor];
            whiteDivider.alpha=0.5;
            [cell.contentView addSubview:whiteDivider];


        }
}
    
    
//    if (indexPath.row==arrTitles.count-1) {
//        UIView *whiteDivider = [[UIView alloc] initWithFrame:CGRectMake(7, cell.bounds.size.height-2, cell.bounds.size.width, 1)];
//        whiteDivider.backgroundColor = [UIColor whiteColor];
//        whiteDivider.alpha=0.5;
//        [cell.contentView addSubview:whiteDivider];
//        
//    }
    
    //    UIView *whiteDivider = [[UIView alloc] initWithFrame:CGRectMake(0, 5, cell.bounds.size.width, 1)];
    //    whiteDivider.backgroundColor = [UIColor whiteColor];
    //    [cell.contentView addSubview:whiteDivider];
    
    return cell;
}

//- (UIView *)tableView : (UITableView *)tableView viewForHeaderInSection : (NSInteger) section {
//    UIImageView *imgView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 20, 20)];
//    imgView.image = [UIImage imageNamed:@"sponsor"];
//
//    return imgView;
//}
@end
