#import <UIKit/UIKit.h>

#define IS_IPHONE_4 ( fabs( ( double )[ [ UIScreen mainScreen ] bounds ].size.height - ( double )480 ) < DBL_EPSILON )

#define IS_IPHONE_5 ( fabs( ( double )[ [ UIScreen mainScreen ] bounds ].size.height - ( double )568 ) < DBL_EPSILON )

#define IS_IPHONE_6 ( fabs( ( double )[ [ UIScreen mainScreen ] bounds ].size.height - ( double )667 ) < DBL_EPSILON )

#define IS_IPHONE_6_PLUS ( fabs( ( double )[ [ UIScreen mainScreen ] bounds ].size.height - ( double )736 ) < DBL_EPSILON )

#define DEVICE_FRAME [[ UIScreen mainScreen ] bounds ]
#define OS_VER [[[UIDevice currentDevice] systemVersion] floatValue]
#define IS_IPAD (UI_USER_INTERFACE_IDIOM() == UIUserInterfaceIdiomPad ? YES : NO)
#define DEVICE_ID [[[UIDevice currentDevice]identifierForVendor]UUIDString]

#define RGB(r,g,b)    [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:1]
#define RGBA(r,g,b,a) [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:a]
#define RECT(x,y,w,h)  CGRectMake(x, y, w, h)
#define POINT(x,y)     CGPointMake(x, y)
#define SIZE(w,h)      CGSizeMake(w, h)
#define RANGE(loc,len) NSMakeRange(loc, len)

#define NAV_COLOR       RGB(3,143,113)
#define TEXT_COLOR      RGB(52,65,71)
#define BORDER_COLOR    RGB(122,145,158)

#define UDSetObject(value, key) [[NSUserDefaults standardUserDefaults] setObject:value forKey:(key)];[[NSUserDefaults standardUserDefaults] synchronize]

#define UDGetObject(key) [[NSUserDefaults standardUserDefaults] objectForKey:(key)]

#define KEYBORAD_HEIGHT_IPHONE 216

#define KEY @"AIzaSyCpO8jrthyJoNtG-6TMoXS06doerXEon1g"
//#define KEY    @"AIzaSyCE_Ze-dmq-hpDPWnDPF0qEabE3XQQU-pQ"
//1283
#define THUMB_IMAGE_SIZE 100

//live
#define SERVER_URL             @"http://216.55.169.45/~academicpulse/master/webservices/"

#define LOGIN_URL SERVER_URL@"login"
#define FORGOT_PASSWORD_URL SERVER_URL@"forgotpassword"
#define COURSE_LIST_URL SERVER_URL@"getcourse"
#define CHECKIN_URL SERVER_URL@"checkin"
#define EVENT_LISTINGS_URL SERVER_URL@"eventcalander"
#define ASSINGMENT_URL SERVER_URL@"getassignment"
#define CHANGE_PASSWORD_URL SERVER_URL@"changepassword"
#define ATTENDANCE_EVENT_LISTINGS_URL SERVER_URL@"getattendance"


#define SERVER_DATE_FORMAT    @"yyyy-MM-dd HH:mm:ss"

#define DATE_FORMAT_Y_M_D_H_M_S         @"yyyy-MM-dd HH:mm:ss"
#define STR_SPACE @" "

#define dateFormatYearMonthDateHiphenWithTime @"yyyy-MM-dd HH:mm:ss +0000"
#define DATE_FORMAT_Y_M_D              @"yyyy-MM-dd"
#define MUTABLEARRAY [[NSMutableArray alloc] init];


#define GOOGLE_API @"https://maps.googleapis.com/maps/api/place/nearbysearch/json?"
#define PLACEDETAIL_API @"https://maps.googleapis.com/maps/api/place/details/json?"

#define RADIUS 5000

#define NEARBY_LOCATIONS(latitude,longitude)[NSString stringWithFormat:@"%@key=%@&location=%f,%f&radius=%d&keyword=%@",GOOGLE_API,KEY,latitude,longitude,RADIUS,KEYWORD]

#define PLACES_DETAILS(placeId)[NSString stringWithFormat:@"%@key=%@&placeid=%@",PLACEDETAIL_API,KEY,placeId]

#define REGEX_EMAIL @"[A-Z0-9a-z._%+-]{3,}+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"

typedef enum {
    HTTPRequestTypeGeneral,
    HTTPRequestTypeUpdate,
    HTTPRequestTypeImageList,
    HTTPRequestTypeVideoList,
    HTTPRequestTypePlaceList,
    HTTPRequestTypePlaceDetail,
    HTTPRequestTypeLogin,
    HTTPRequestTypeDoctorLogin,
    HTTPRequestTypeChangePassword,
    HTTPRequestTypeActiveConcernDetail,
    HTTPRequestTypeDoctorConcernList,
    HTTPRequestTypeStaffList,
    HTTPRequestTypeDoctorInfo,
} HTTPRequestType;

typedef enum {
    jServerError = 0,
    jSuccess,
    jInvalidResponse,
    jNetworkError,
    jFailResponse,
}ErrorCode;
