//
//  StoreObjectsMVC.h
//  AcademicPulse
//
//  Created by vivek on 11/18/15.
//  Copyright © 2015 com.zaptech. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AssignmentModel.h"
#import "PopUpTableViewController.h"
@interface Globals : NSObject
{
}

+ (id)sharedManager;

@property NSMutableDictionary *dictGlobalLoginData;
@property NSMutableDictionary *dictGlobalCourseDetails;
@property NSMutableDictionary *dictGlobalAssignmentDetails;
@property NSMutableDictionary *dictGlobalCalendarEventList;
@property NSMutableDictionary *dictGlobalAttendanceCalendarEventList;


@property NSMutableString *className;

@property NSMutableString *latitude;
@property NSMutableString *logitude;
@property  AssignmentModel *objAssinmentModel;
@property PopUpTableViewController *objPopUpTableViewController;
@end
