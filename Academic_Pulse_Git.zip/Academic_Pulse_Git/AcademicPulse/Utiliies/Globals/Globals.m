//
//  Globals.m
//  AcademicPulse
//
//  Created by vivek on 11/18/15.
//  Copyright © 2015 com.zaptech. All rights reserved.
//

#import "Globals.h"

@interface Globals ()

@end

@implementation Globals

@synthesize latitude,logitude,objAssinmentModel,objPopUpTableViewController,dictGlobalCalendarEventList,dictGlobalAttendanceCalendarEventList;
+ (id)sharedManager {
    static Globals *sharedMyManager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedMyManager = [[self alloc] init];
    });
    return sharedMyManager;
}

- (id)init {
    if (self = [super init]) {
        self.objPopUpTableViewController = [[PopUpTableViewController alloc] initWithStyle:UITableViewStylePlain];
        self.className = [[NSMutableString alloc] init];
        self.objAssinmentModel = [[AssignmentModel alloc] init];
        self.latitude = [[NSMutableString alloc] init];
        self.logitude = [[NSMutableString alloc] init];
        self.dictGlobalLoginData = [[NSMutableDictionary alloc] init];
        self.dictGlobalCourseDetails = [[NSMutableDictionary alloc] init];
        self.dictGlobalAssignmentDetails = [[NSMutableDictionary alloc] init];
        self.dictGlobalCalendarEventList = [[NSMutableDictionary alloc] init];
        self.dictGlobalAttendanceCalendarEventList= [[NSMutableDictionary alloc] init];
    }
    return self;
}

@end
