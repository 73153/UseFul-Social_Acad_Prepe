//
//  LoginModel.h
//  AcademicPulse
//
//  Created by vivek on 11/18/15.
//  Copyright © 2015 com.zaptech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LoginModel : NSObject

@property NSMutableString *studentId,*firstname,*lastname,*courseName,*time,*year,*startDate,*endDate,*numClasses,*totalCredits,*location;
typedef void(^user_completion_block)(NSString *, int status);

@end
