//
//  LoginModel.m
//  AcademicPulse
//
//  Created by vivek on 11/18/15.
//  Copyright © 2015 com.zaptech. All rights reserved.
//

#import "LoginModel.h"
#import "APICall.h"
#import "MBProgressHUD.h"
#import "ConstantList.h"

@interface LoginModel ()

@end

@implementation LoginModel
@synthesize studentId,firstname,lastname,courseName,time,year,startDate,endDate,numClasses,totalCredits,location;
-(instancetype)init
{
    self = [super init];
    if(self) {
        studentId=[[NSMutableString alloc]init];
        firstname=[[NSMutableString alloc]init];
        lastname=[[NSMutableString alloc]init];
        courseName=[[NSMutableString alloc]init];
        time=[[NSMutableString alloc]init];
        year=[[NSMutableString alloc]init];
        startDate=[[NSMutableString alloc]init];
        endDate=[[NSMutableString alloc]init];
        numClasses=[[NSMutableString alloc]init];
        totalCredits=[[NSMutableString alloc]init];
        location=[[NSMutableString alloc]init];
    }
    return self;
}


-(void)loginUser:(user_completion_block)completion{
    NSString *url_String = [NSString stringWithFormat:@"%@", LOGIN_URL];
    NSDictionary *parameters = @{@"sEmail":self.username,@"sPassword":self.password,@"sDeviceToken":self.deviceToken};
    [APICall callPostWebService:url_String andDictionary:parameters completion:^(NSDictionary* user, NSError*error, long code){
        if(error)
        {
            if(completion)
            {
                completion(@"There was some error, please try again later",-1);
            }
        }
        else{
            if(completion)
            {
                if([[user valueForKey:@"status"]integerValue]==1)
                {
                    completion(@"Login success",0);
                    self.firstname=[[user objectForKey:@"userdetails"] valueForKey:@"sFirstName"];
                    self.lastname=[[user  objectForKey:@"userdetails"] valueForKey:@"sLastName"];
                    self.userid=[[[user  objectForKey:@"userdetails"] valueForKey:@"nUserId"] intValue];
                    self.rdate=[[user  objectForKey:@"userdetails"] valueForKey:@"dDate"];
                    self.fbid=[[user  objectForKey:@"userdetails"] valueForKey:@"sFBID"];
                    self.imgPath=[[user  objectForKey:@"userdetails"] valueForKey:@"sImage"];
                }
                else{
                    completion(@"Email ID or Password is invalid",-1);
                }
            }
        }
    }];
}



@end
