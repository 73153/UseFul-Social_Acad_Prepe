//
//  ResultVC.h
//  AcademicPulse
//
//  Created by dhara on 11/9/15.
//  Copyright © 2015 com.zaptech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ResultVC : UIViewController<UITableViewDataSource,UITableViewDelegate>
@property (strong, nonatomic) IBOutlet UITableView *tblResultVC;

@end
