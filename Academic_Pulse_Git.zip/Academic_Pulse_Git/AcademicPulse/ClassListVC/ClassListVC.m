//
//  ClassListVC.m
//  POS
//
//  Created by Amit Parmar on 14/02/14.
//  Copyright (c) 2014 N-Tech. All rights reserved.
//

#import "ClassListVC.h"
#import "RESideMenu.h"
#import "UIViewController+NavigationBar.h"
#import "logInVC.h"
#import "AppDelegate.h"
#import "logoView.h"
#import "ClassDetailVC.h"
#import "ConstantList.h"
#import "TabVIew.h"
#import "MBProgressHUD.h"
#import "APICall.h"
#import "Globals.h"
#import "UIView+Toast.h"

@interface ClassListVC ()<SearchDelegate>{
}
@end

@implementation ClassListVC
{
    logoView *log;
    TabVIew *tab;
    Globals *objGlobals;
    NSMutableDictionary *dictCourseDetail;
}
@synthesize scrollView;
@synthesize tableCount;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
    }
    return self;
}

#pragma mark - VC lifecycle

- (void)viewDidLoad{
    [super viewDidLoad];
    [self setMenuIconForSideBar:@"menu"];
    [self setUpContentData];
    [self getCourseList];
}


-(void)viewDidAppear:(BOOL)animated{
        UINib * mainView = [UINib nibWithNibName:@"logoView" bundle:nil];
    log =(logoView *)[mainView instantiateWithOwner:self options:nil][0];
    if(IS_IPHONE_6_PLUS)
    {
        log.frame=CGRectMake(0, 5, self.view.frame.size.width, log.frame.size.height+20);
    }else
        log.frame=CGRectMake(0, 5, self.view.frame.size.width, log.frame.size.height);
    [self.view addSubview:log];
}

-(void)viewWillAppear:(BOOL)animated
{
    self.navigationItem.title=@"ClassListVC";
}

-(void)viewWillDisappear:(BOOL)animated
{
    self.navigationItem.title=@"";
    self.navigationController.navigationBar.tintColor = [UIColor whiteColor];
}

#pragma mark - Custom Methods

-(void)setUpContentData
{
    [self.navigationController.navigationBar setBackgroundImage:[UIImage imageNamed:@"header"] forBarMetrics:UIBarMetricsDefault];
    self.navigationItem.title = @"ClassListVC";
    self.navigationController.navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName: [UIColor whiteColor],NSFontAttributeName: [UIFont fontWithName:@"Helvetica" size:15.0f]};
}

-(void)getCourseList
{
    @try{
        objGlobals = [Globals sharedManager];
        dictCourseDetail =[[NSMutableDictionary alloc] init];
        NSMutableDictionary *params = [[NSMutableDictionary alloc] init];
        //CHANGE THIS IS DYNAMIC
        
        //        [params setObject:[[arr objectAtIndex:0] valueForKey:@"student_id"] forKey:@"student_id"];
        
        [params setObject:@"6" forKey:@"student_id"];
        if(objGlobals.dictGlobalCourseDetails.count==0)
        {
            [MBProgressHUD showHUDAddedTo:self.view animated:YES];
            [APICall callPostWebService:COURSE_LIST_URL andDictionary:params completion:^(NSMutableDictionary *result, NSError *error, long code) {
                if(![self isNotNull:result]){
                    NSString *strStatus = [NSString stringWithFormat:@"%ld",(long)[[result valueForKey:@"status"] integerValue]];
                    if([strStatus isEqualToString:@"1"]){
                        [MBProgressHUD hideAllHUDsForView:
                         self.view animated:YES];
                        dictCourseDetail=[result valueForKey:@"CourseDetails"];
                        objGlobals.dictGlobalCourseDetails = dictCourseDetail;
                        tableCount = (int)dictCourseDetail.count;
                        [self createTables];
                    }
                    else
                    {
                        [MBProgressHUD hideAllHUDsForView:
                         self.view animated:YES];
                        [self.view makeToast:[result valueForKey:@"msg"]];
                        //            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Login"message:[result valueForKey:@"msg"] delegate:self cancelButtonTitle:@"Ok" otherButtonTitles:nil,nil];
                        //            [alert show];
                    }
                }
                else
                {
                    [MBProgressHUD hideAllHUDsForView:
                     self.view animated:YES];
                    [self.view makeToast:@"Time Out"];
                }
            }];
        }
        else{
            dictCourseDetail=objGlobals.dictGlobalCourseDetails;
            tableCount = (int)dictCourseDetail.count;
            [self createTables];
        }
    }
    @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    
}
#pragma mark - Clickevent

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    @try
    {    if(buttonIndex == 1){
        NSMutableDictionary *dictionary = [[NSMutableDictionary alloc] initWithDictionary:[[NSUserDefaults standardUserDefaults] objectForKey:@""]];
        [dictionary setObject:[alertView textFieldAtIndex:0].text forKey:[NSString stringWithFormat:@"%ld",(long)[alertView tag]-1000]];
        [[NSUserDefaults standardUserDefaults] setObject:dictionary forKey:@""];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
    } @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
}

- (void) tableButtonClicked:(id) sender{
    @try{
        UIStoryboard *storybord = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
        
        ClassDetailVC *objAssignmentVC=(ClassDetailVC *)[storybord  instantiateViewControllerWithIdentifier:@"ClassDetailVC"];
        NSInteger tag = [sender tag];
        tag = tag-1001;
        NSArray * values = [dictCourseDetail mutableCopy];
        objAssignmentVC.dictClassData = [[NSDictionary alloc] init];
        objAssignmentVC.dictClassData = [values objectAtIndex:tag];
        [self.navigationController pushViewController:objAssignmentVC animated:YES];
    } @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
}

- (IBAction)addTableButtonClicked:(id)sender {
    
    int x;
    if(IS_IPHONE_6 || IS_IPHONE_6_PLUS)
        x = (tableCount%3)*110+30;
    else
        x = (tableCount%3)*110+10;
    
    int y;
    if(IS_IPHONE_6 || IS_IPHONE_6_PLUS)
        y= (tableCount/3)*110+60;
    else
        y= (tableCount/3)*110;
    
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button setBackgroundImage:[UIImage imageNamed:@"icon-bg"] forState:UIControlStateNormal];
    if(IS_IPHONE_6 || IS_IPHONE_6_PLUS)
        [button setFrame:CGRectMake(x, y, 100, 100)];
    else
        [button setFrame:CGRectMake(x, y, 80, 80)];
        [button setTitle:[NSString stringWithFormat:@"Class %d",tableCount+1] forState:UIControlStateNormal];
    [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [button setTag:1000+tableCount+1];
    [button addTarget:self action:@selector(tableButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    [scrollView addSubview:button];
        NSMutableDictionary *dictionary = [[NSMutableDictionary alloc] initWithDictionary:[[NSUserDefaults standardUserDefaults] objectForKey:@""]];
    [dictionary setObject:@"" forKey:[NSString stringWithFormat:@"%d",tableCount+1]];
    [[NSUserDefaults standardUserDefaults] setObject:dictionary forKey:@""];
    [[NSUserDefaults standardUserDefaults] synchronize];
    tableCount++;
        int newCount = 0;
    if(tableCount%3 != 0){
        newCount = (tableCount/3)+1;
    }
    else{
        newCount = tableCount/3;
    }
    if(IS_IPHONE_6 || IS_IPHONE_6_PLUS)
        [scrollView setContentSize:CGSizeMake(scrollView.frame.size.width,(newCount*110)+100)];
    else
        [scrollView setContentSize:CGSizeMake(scrollView.frame.size.width,(newCount*110)+60)];
}

#pragma mark - createTables

- (void) createTables{
    @try{
        int x;
        x = 10;
        int y;
        y=0;
        if (IS_IPHONE_6_PLUS)
            y=20;
        
        int count = 0;
        for(int i=0;i<tableCount;i++){
            if(count >= 3){
                count = 0;
                x = 10;
                if(IS_IPHONE_6)
                    y = y + 121;
                else if (IS_IPHONE_6_PLUS)
                    y = y + 135;
                else
                    y = y + 103;
            }
            UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
            if(IS_IPHONE_6 )
                [button setFrame:CGRectMake(x, y, 115, 115)];
            else if (IS_IPHONE_6_PLUS)
                [button setFrame:CGRectMake(x, y, 125, 125)];
            else
                [button setFrame:CGRectMake(x, y, 95, 95)];
                        [button setBackgroundImage:[UIImage imageNamed:@"icon-bg"] forState:UIControlStateNormal];
            [button setTitle:[NSString stringWithFormat:@"Class %d",i+1] forState:UIControlStateNormal];
            [button setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
            [button setTag:1000+i+1];
            [button addTarget:self action:@selector(tableButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
            [scrollView addSubview:button];
            count++;
            if(IS_IPHONE_6)
                x = x + 121;
            else if (IS_IPHONE_6_PLUS)
                x = x + 135;
            else
                x = x + 103;
        }
        int newCount = 0;
        if(tableCount%3 != 0){
            newCount = (tableCount/3)+1;
        }
        else{
            newCount = tableCount/3;
        }
        if(IS_IPHONE_6 )
            [scrollView setContentSize:CGSizeMake(scrollView.frame.size.width,(newCount*110)+10)];
        else if (IS_IPHONE_6_PLUS)
            [scrollView setContentSize:CGSizeMake(scrollView.frame.size.width,(newCount*110)+30)];
        else
            [scrollView setContentSize:CGSizeMake(scrollView.frame.size.width,(newCount*110))];
        
    } @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    
}

- (BOOL) isNotNull:(NSObject*) object {
    @try
    {    if (!object)
        return YES;
    else if (object == [NSNull null])
        return YES;
    else if ([object isKindOfClass: [NSString class]]) {
        return ([((NSString*)object) isEqualToString:@""]
                || [((NSString*)object) isEqualToString:@"null"]
                || [((NSString*)object) isEqualToString:@"nil"]
                || [((NSString*)object) isEqualToString:@"<null>"]);
    }
        return NO;
    } @catch (NSException *exception) {
        NSLog(@"Exception At: %s %d %s %s %@", __FILE__, __LINE__, __PRETTY_FUNCTION__, __FUNCTION__,exception);
    }
    
}

#pragma mark - Search Delegate
-(void)didSelectSearchedString:(NSString *)selectedString tableView:(id)tableView{
    [tableView toggleHidden:YES];
}

- (void)didReceiveMemoryWarning{
    [super didReceiveMemoryWarning];
}


@end
