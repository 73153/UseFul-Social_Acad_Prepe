//
//  ClassListVC.h
//  POS
//
//  Created by Amit Parmar on 14/02/14.
//  Copyright (c) 2014 N-Tech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ClassListVC : UIViewController
@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;

@property (nonatomic) int tableCount;
- (IBAction)addTableButtonClicked:(id)sender;


@end
