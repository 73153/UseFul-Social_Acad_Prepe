
//  AppDelegate.m
//  PrEP
//
//  Created by Bhushan on 5/1/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import "AppDelegate.h"
#import "ViewController.h"
@interface AppDelegate ()
{
    
}

@end

@implementation AppDelegate
@synthesize dbpath;
@synthesize AltertStr,Title_App_Str,CompSel_App_Str,Increment_Id_App_Str,ID_App_Str,isFromOther;
@synthesize Sele_ID_viewApp_Str,ViewTask_tital,ViewTask_Date,Edit_Date_Appstr,update_titleName;
@synthesize Cal_DescStr,Cal_TitleStr,Cal_dateStr,Pill_countStr,isConform;
DataBase *dbh;

- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
{
    // Override point for customization after application launch.
    
    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent animated:NO];
    
     dbh=[[DataBase alloc]init];
    
    [self checkDB];
    
    
  //Push notifiaction
    
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8.0)
    {
        [[UIApplication sharedApplication] registerUserNotificationSettings:[UIUserNotificationSettings settingsForTypes:(UIUserNotificationTypeSound | UIUserNotificationTypeAlert | UIUserNotificationTypeBadge) categories:nil]];
        [[UIApplication sharedApplication] registerForRemoteNotifications];
    }
    else
    {
        [[UIApplication sharedApplication] registerForRemoteNotificationTypes: (UIRemoteNotificationTypeNewsstandContentAvailability| UIRemoteNotificationTypeBadge | UIRemoteNotificationTypeSound | UIRemoteNotificationTypeAlert)];
    }
    
    
    
    
//    NSTimer *t = [NSTimer scheduledTimerWithTimeInterval:3600.0
//        target: self selector:@selector(onTick:)
//    userInfo: nil repeats:YES];
//    
    
    // Handle launching from a notification ..pradip
    UILocalNotification *locationNotification = [launchOptions objectForKey:UIApplicationLaunchOptionsLocalNotificationKey];
    if (locationNotification) {
        // Set icon badge number to zero
        application.applicationIconBadgeNumber = 0;
    }
    
    return YES;
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    @try {
    UINavigationController *nav= (UINavigationController *) self.window.rootViewController;
    ViewController *view= (ViewController *)[[nav viewControllers] objectAtIndex:0];
     dbh=[[DataBase alloc]init];
    NSMutableArray *UserDateArraya=[[NSMutableArray alloc]init];
    UserDateArraya=[dbh selectAllUser];
       if ([UserDateArraya count]>0)
    {
        view.pin_text_field.text=@"";
      view.enter_pin_view.hidden=NO;
    }
    [nav popToRootViewControllerAnimated:YES];
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }

    //[nav pushViewController:[[ViewController alloc] init] animated:YES];
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application
{
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
    
//    NSTimer *t = [NSTimer scheduledTimerWithTimeInterval:3600.0
//                                                  target: self
//                                                selector:@selector(onTick:)
//                                                userInfo: nil repeats:YES];
    
    
}
//-----------------------------------------------------------------------------------------------------


#pragma mark Data base connected.......
-(void)checkDB
{
    NSArray *arrdir=NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *path=[arrdir objectAtIndex:0];
    
    self.dbpath=[path stringByAppendingString:@"/PREP.sqlite"];
    if(![[NSFileManager defaultManager]fileExistsAtPath:self.dbpath])
    {
        NSError *err;
        NSString *searchpath=[[NSBundle mainBundle]pathForResource:@"PREP" ofType:@"sqlite"];
        
        NSLog(@"%@",searchpath);
        [[NSFileManager defaultManager]copyItemAtPath:searchpath toPath:self.dbpath error:&err];
    }
    
   
    
    
}


//-----------------------------------------------------------------------------------------------------


#pragma mark Push notification Delegate..

//Get deviceToken..

-(void)application:(UIApplication *)application didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)devToken {
    
    @try {
       NSString *deviceTokenString=[NSString stringWithFormat:@"%@",devToken ];
    NSLog(@"%@",deviceTokenString);
    
    deviceToken=[NSString stringWithFormat:@"%@",deviceTokenString];
    
    
    
    deviceToken = [[[[deviceToken description]
                     stringByReplacingOccurrencesOfString: @"<" withString: @""]
                    stringByReplacingOccurrencesOfString: @">" withString: @""]
                   stringByReplacingOccurrencesOfString: @" " withString: @""];
    
    NSLog(@"deviceToken = %@",deviceToken);
    [self PostdeviceToken];
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
 
}



- (void)application:(UIApplication *)app didFailToRegisterForRemoteNotificationsWithError:(NSError *)err {
    
    NSString *str = [NSString stringWithFormat: @"Error: %@", err];
    NSLog(@"%@",str);
    deviceToken = nil;
}

//- (void)application:(UIApplication *)app didReceiveLocalNotification:(UILocalNotification *)notif
//{
//    // Handle the notificaton when the app is running
//    NSLog(@"Recieved Notification %@",notif);
//    
//    
//    
//}

- (void)application:(UIApplication *)application didReceiveRemoteNotification:(NSDictionary *)userInfo fetchCompletionHandler:(void (^)(UIBackgroundFetchResult result))handler {
    @try {
     NSLog(@"Recieved Remote Notification %@", userInfo);
    NSDictionary *aps = [userInfo objectForKey:@"aps"];
    NSLog(@"%@",aps);
      NSDictionary *aps2 = [aps objectForKey:@"alert"];
    NSString *alertMessage = [aps2 objectForKey:@"body"];
    
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"PrEP" message:alertMessage delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [alert show];

    //CREATE TABLE "NOTIFICATION" ("MSG" VARCHAR, "DATE" VARCHAR, "ID" VARCHAR, "READCHECK" INTEGER)
    
    NSDateFormatter *DateFormatter=[[NSDateFormatter alloc] init];
    [DateFormatter setDateFormat:@"MM-dd-yy"];
    NSString *DateStr=[DateFormatter stringFromDate:[NSDate date]];
    
   
    NSMutableDictionary *dic=[[NSMutableDictionary alloc ]init];
    
    [dic setObject:alertMessage forKey:@"MSG"];
    [dic setObject:DateStr forKey:@"DATE"];
    [dic setObject:@"1" forKey:@"ID"];
    [dic setObject:@"1" forKey:@"READCHECK"];
    
    NSMutableArray  *Array=[[NSMutableArray alloc]init];
    [Array addObject:dic];

    [dbh insertnotifications:Array];
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }

}

//-----------------------------------------------------------------------------------------------------

#pragma mark Postmethod token save to save......

-(void)PostdeviceToken
{
    NSMutableURLRequest *request =
    [[NSMutableURLRequest alloc] initWithURL:
     [NSURL URLWithString:@"http://216.55.169.45/~prepapp/master/webservices/adddeviceid.php"]];
    
    [request setHTTPMethod:@"POST"];
    
    NSString *postString =[NSString  stringWithFormat:@"sDeviceId=%@&eDeviceType=IOS",deviceToken];
    
    [request setValue:[NSString
                       stringWithFormat:@"%lu", (unsigned long)[postString length]]
   forHTTPHeaderField:@"Content-length"];
    
    [request setHTTPBody:[postString
                          dataUsingEncoding:NSUTF8StringEncoding]];
    
    NSURLConnection* conS  =[[NSURLConnection alloc]
                             initWithRequest:request delegate:self];
    
      xmldata=[[NSMutableData alloc]init];
    [conS start];
    
}

//------------------------------------------------------------------

#pragma mark - Connection Methods Delegate method..

- (void)connection:(NSURLConnection *)connection didFailWithError:(NSError *)error{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"" message:@"Please check internet connection" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [alert show];
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection {
   
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data{
    [xmldata appendData:data];
     NSString *str1=[[NSString alloc]initWithData:xmldata encoding:NSUTF8StringEncoding];
    NSLog(@"%@",str1);
    
}
-(void)onTick:(NSTimer *)timer{
    NSString *Title;
    NSString *dateStr;
    NSArray *SlectAll=[dbh Select_All_Appointment];
    for (int i=0; i<[SlectAll count]; i++)
    {
         dateStr=[[SlectAll objectAtIndex:i]objectForKey:@"DATE"];
          Title=[[SlectAll objectAtIndex:i]objectForKey:@"TITLE"];
       
        NSDateFormatter *DateFormatter=[[NSDateFormatter alloc] init];
        [DateFormatter setDateFormat:@"MM-dd-yy"];
        NSString *DateStr=[DateFormatter stringFromDate:[NSDate date]];
        
        if ([DateStr isEqualToString:DateStr])
        {
            UIApplication * app = [UIApplication sharedApplication];
       //     NSDate *date = [[NSDate date] dateByAddingTimeInterval:10];
            UILocalNotification *alarm = [[UILocalNotification alloc] init] ;
            if (alarm)
            {
                alarm.fireDate = [NSDate date];
                alarm.timeZone = [NSTimeZone systemTimeZone];
                alarm.repeatInterval = 0;
                alarm.alertBody = Title;
                alarm.alertAction = @"Open";
                [app scheduleLocalNotification:alarm];
            }
            [app presentLocalNotificationNow:alarm];
        }
    }
}

- (void)application:(UIApplication *)application didReceiveLocalNotification:(UILocalNotification *)notification{
    UIApplicationState state = [application applicationState];
    if (state == UIApplicationStateActive) {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Reminder" message:notification.alertBody
        delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
    }
    
    // Request to reload table view data
    [[NSNotificationCenter defaultCenter] postNotificationName:@"reloadData" object:self];
    
    
    // Set icon badge number to zero
    application.applicationIconBadgeNumber = 0;
}@end
