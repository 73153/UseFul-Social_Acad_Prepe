//
//  NotificationViewController.m
//  PrEP
//
//  Created by Bhushan on 5/13/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import "NotificationViewController.h"

#import "SettingViewController.h"
#import "DashBoardViewController.h"
#import "NotificationViewController.h"
#import "AppointmentViewController.h"
#import "CalViewController.h"
#import "DataBase.h"
#import "AppointmentTableViewCell.h"
#import "TimeTableViewCell.h"

@interface NotificationViewController ()
{
    DataBase *dbh;
    NSIndexPath *selectedIndexPath;
}
@end

@implementation NotificationViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
   
  
}

-(void)viewWillAppear:(BOOL)animated {
    @try{
    dbh=[[DataBase alloc]init];
    
    // Do any additional setup after loading the view.
    
    [_view1.layer setCornerRadius:5.0f];
    
    // border
    [_view1.layer setBorderColor:[UIColor orangeColor].CGColor];
    [_view1.layer setBorderWidth:1.5f];
    
    // drop shadow
    [_view1.layer setShadowColor:[UIColor blackColor].CGColor];
    [_view1.layer setShadowOpacity:0.8];
    [_view1.layer setShadowRadius:3.0];
    [_view1.layer setShadowOffset:CGSizeMake(2.0, 2.0)];
    
    
    
    [_view2.layer setCornerRadius:5.0f];
    
    // border
    [_view2.layer setBorderColor:[UIColor orangeColor].CGColor];
    [_view2.layer setBorderWidth:1.5f];
    
    // drop shadow
    [_view2.layer setShadowColor:[UIColor blackColor].CGColor];
    [_view2.layer setShadowOpacity:0.8];
    [_view2.layer setShadowRadius:3.0];
    [_view2.layer setShadowOffset:CGSizeMake(2.0, 2.0)];
    
    
    SelNotication=[[NSMutableArray alloc]init];
    msgArray=[[NSMutableArray alloc]init];
    reIdArray=[[NSMutableArray alloc]init];
    self.arrComplatedAppont = [[NSMutableArray alloc] init];
    
        
    SelNotication=[dbh Selection_All_notification];
    
    NSLog(@"%@",SelNotication);
    
    for (int i=0; i<[SelNotication count]; i++)
    {
        
        [msgArray addObject:[[SelNotication objectAtIndex:i]objectForKey:@"MSG"]];
        
        [reIdArray addObject:[[SelNotication objectAtIndex:i]objectForKey:@"READCHECK"]];
        
        
    }
    
    self.arrComplatedAppont = [dbh getRecentlyCompoletedAppointment];
    NSLog(@"%@",self.arrComplatedAppont);
 [_tblViewRecComp reloadData];
    }  @catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}



#pragma mark UITableViewDelegate Protocol Methods-----------------------------------



- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    @try{
    if (tableView == self.tblViewRecComp) {
        return [self.arrComplatedAppont count];
    }
    else
    {
        return [msgArray count];
    }
    
    
    } @catch(NSException *exception){
            NSLog(@"%@",exception.description);
        }
        
}
 
    


- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath

{
    return 25;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath

{
    @try{
    if (tableView == self.tblViewRecComp) {
        static NSString *simpleTableIdentifier = @"AppointmentTableViewCell";
        AppointmentTableViewCell *cell = (AppointmentTableViewCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
        if (cell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"AppointmentTableViewCell" owner:self options:nil];
            cell = [nib objectAtIndex:0];
            cell.selectionStyle= UITableViewCellSelectionStyleNone;
        }
    
        NSDictionary *dict = [self.arrComplatedAppont objectAtIndex:indexPath.row];
        cell.tital_label.font = [UIFont systemFontOfSize:12];
        cell.index_lable.font = [UIFont systemFontOfSize:12];
        cell.tital_label.text=[dict objectForKey:@"TITLE"];
        cell.index_lable.text =[NSString stringWithFormat:@"%d",(int)indexPath.row+1];
        
        cell.tital_label.frame = CGRectMake(cell.tital_label.frame.origin.x, cell.tital_label.frame.origin.y-5,cell.tital_label.frame.size.width,cell.tital_label.frame.size.height);
        cell.index_lable.frame = CGRectMake(cell.index_lable.frame.origin.x, cell.index_lable.frame.origin.y-5,cell.index_lable.frame.size.width,cell.index_lable.frame.size.height);

        return cell;
    }
    else {
        static NSString *simpleTableIdentifier = @"AppointmentTableViewCell";
        AppointmentTableViewCell *cell = (AppointmentTableViewCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"AppointmentTableViewCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    
    //App_Comp
    
    
    
    int Inder=(int)indexPath.row+1;
    
    cell.tital_label.text=[msgArray objectAtIndex:indexPath.row];
    
    cell.index_lable.text=[NSString stringWithFormat:@"%d",Inder];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
    }
    return nil;
    }  @catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{@try{
    [tableView deselectRowAtIndexPath:indexPath animated:TRUE];
    if (tableView != self.tblViewRecComp) {
        selectedIndexPath = indexPath;
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert"
                                                    message:@"Do you want to delete this notification?"
                                                   delegate:self
                                          cancelButtonTitle:@"NO"
                                          otherButtonTitles:@"YES",nil];
        
    [alert show];
}


}  @catch(NSException *exception){
    NSLog(@"%@",exception.description);
}
    
}


- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex {
    // the user clicked OK
    if (buttonIndex == 0)
    {
        // do something here...
    }else
    {
        NSString * strNotificationID =[[SelNotication objectAtIndex:selectedIndexPath.row]objectForKey:@"ID"];
        
        if([dbh deleteNotification:strNotificationID]) {
            [msgArray removeObjectAtIndex:selectedIndexPath.row];
            [_notification_table_view reloadData];
        }

    }
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)dash_tab_button_action:(id)sender
{@try{
    int index = 0;
    for (UIViewController *vc in self.navigationController.viewControllers) {
        if ([vc isKindOfClass:[DashBoardViewController class]]) {
            [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:index] animated:NO];
        }
        index++;
    }
    DashBoardViewController *objDashBoardViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"DashBoardViewController"];
    [self.navigationController pushViewController:objDashBoardViewController animated:NO];
    
}  @catch(NSException *exception){
    NSLog(@"%@",exception.description);
}
    
}


- (IBAction)setting_tab_button_action:(id)sender
{
    @try{
//    int index = 0;
//    for (UIViewController *vc in self.navigationController.viewControllers) {
//        if ([vc isKindOfClass:[SettingViewController class]]) {
//            [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:index] animated:NO];
//        }
//        index++;
//    }
    SettingViewController *objSettingViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"SettingViewController"];
    [self.navigationController pushViewController:objSettingViewController animated:NO];
    
    }  @catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}


- (IBAction)task_tab_button_action:(id)sender
{
    @try{
    int index = 0;
    for (UIViewController *vc in self.navigationController.viewControllers) {
        if ([vc isKindOfClass:[AppointmentViewController class]]) {
            [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:index] animated:NO];
        }
        index++;
    }
    AppointmentViewController *objAppointmentViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"AppointmentViewController"];
    [self.navigationController pushViewController:objAppointmentViewController animated:NO];
    
    }  @catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}


- (IBAction)cal_tab_button_action:(id)sender
{
    @try{
    int index = 0;
    for (UIViewController *vc in self.navigationController.viewControllers) {
        if ([vc isKindOfClass:[CalViewController class]]) {
            [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:index] animated:NO];
        }
        index++;
    }
    CalViewController *objCalViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"CalViewController"];
    [self.navigationController pushViewController:objCalViewController animated:NO];
    }  @catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}



@end
