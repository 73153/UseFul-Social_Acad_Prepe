//
//  NotificationViewController.h
//  PrEP
//
//  Created by Bhushan on 5/13/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import "ViewController.h"

@interface NotificationViewController : ViewController

{
    NSMutableArray *SelNotication;
    
    NSMutableArray *msgArray,*reIdArray;
    
}


@property (strong, nonatomic) IBOutlet UIView *view1;
@property (strong, nonatomic) IBOutlet UIView *view2;

@property (strong, nonatomic) IBOutlet UITableView *not_table_view;
@property (strong, nonatomic) IBOutlet UITableView *tblViewRecComp;
@property (nonatomic,retain) NSMutableArray *arrComplatedAppont;


- (IBAction)dash_tab_button_action:(id)sender;

- (IBAction)task_tab_button_action:(id)sender;

- (IBAction)cal_tab_button_action:(id)sender;

- (IBAction)setting_tab_button_action:(id)sender;
@property (strong, nonatomic) IBOutlet UITableView *notification_table_view;



@end
