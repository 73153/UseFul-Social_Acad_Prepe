//
//  AddNewTaskViewController.h
//  PrEP
//
//  Created by Bhushan on 5/14/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import "ViewController.h"
#import "AppDelegate.h"

@interface AddNewTaskViewController : ViewController
{
    AppDelegate *AppDel;
    NSString *timeStr;
    NSMutableArray  *Array;
    
}

@property (strong, nonatomic) IBOutlet UIScrollView *scroll_view;

@property (strong, nonatomic) IBOutlet UITextField *title_text;

@property (strong, nonatomic) IBOutlet UITextField *desc_text;
@property (strong, nonatomic) IBOutlet UITextField *date_text;


@property (strong, nonatomic) IBOutlet UIView *date_view;

@property (strong, nonatomic) IBOutlet UIDatePicker *date_picker;





- (IBAction)save_button_action:(id)sender;
- (IBAction)date_cancel_button_action:(id)sender;
- (IBAction)date_done_action:(id)sender;
- (IBAction)back_button_action:(id)sender;



- (IBAction)dash_tab_button_action:(id)sender;

- (IBAction)noti_tab_button_action:(id)sender;



- (IBAction)cal_tab_button_action:(id)sender;

- (IBAction)setting_tab_button_action:(id)sender;


@end
