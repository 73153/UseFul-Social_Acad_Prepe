//
//  CommonDataProvider.m
//  spotcheck
//
//  Created by pradip.r on 8/24/15.
//  Copyright (c) 2015 pradip.r. All rights reserved.
//

#import "CommonDataProvider.h"
#import "Constant.h"

@implementation CommonDataProvider
@synthesize object;
+(CommonDataProvider *)sharedInstance
{
    static CommonDataProvider *instance = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance = [self new];
       });
    return instance;
  }



@end
