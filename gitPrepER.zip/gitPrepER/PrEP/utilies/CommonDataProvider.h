//
//  CommonDataProvider.h
//  spotcheck
//
//  Created by pradip.r on 8/24/15.
//  Copyright (c) 2015 pradip.r. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface CommonDataProvider : NSObject
@property(nonatomic,strong)id object;

+(CommonDataProvider *)sharedInstance;

@end
