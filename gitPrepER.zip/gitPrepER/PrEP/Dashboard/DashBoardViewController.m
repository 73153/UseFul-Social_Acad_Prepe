//
//  DashBoardViewController.m
//  PrEP
//
//  Created by Bhushan on 5/6/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import "DashBoardViewController.h"
#import "overDueTableViewCell.h"
#import "Constant.h"
#define DEGREES_TO_RADIANS(d) (d * M_PI / 180)

@interface DashBoardViewController ()<UIScrollViewDelegate>
{
    DataBase *dbh;
    NSDateFormatter *formater;
}

@end

@implementation DashBoardViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    formater =[[NSDateFormatter alloc]init];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillAppear:(BOOL)animated
{
    @try
    {
      [self addRegularPillTakenBadgeView];
    
    
    
    OverShow=NO;
    upcomingShow=NO;
    CompShow=NO;
    
    Rota=NO;
    
    dbh=[[DataBase alloc]init];
    
    self.arrOverDueAppoint = [[NSMutableArray alloc] init];
    self.arrUpcommingAppoint = [[NSMutableArray alloc]init];
    
    Iscomp_DateArray=[[NSMutableArray alloc]init];
    Iscomp_Tital=[[NSMutableArray alloc]init];
    Iscomp_Time = [[NSMutableArray alloc] init];
    
    UpComming_DateArray=[[NSMutableArray alloc]init];
    UpComming_Tital=[[NSMutableArray alloc]init];;
    arrUpcommingTime = [[NSMutableArray alloc]init];
    Over_DateArray=[[NSMutableArray alloc]init];
    Over_Tital=[[NSMutableArray alloc]init];
    arrDueTime=[[NSMutableArray alloc]init];
    
    
    _main_scroll.delegate = self;
    [_main_scroll setCanCancelContentTouches:NO];
    _main_scroll.clipsToBounds = NO;
    _main_scroll.scrollEnabled = NO;
    
    
    NSMutableArray *UserDateArray=[[NSMutableArray alloc]init];
    
    UserDateArray=[dbh selectAllUser];
    NSString *startDate=[[NSString alloc]init];
    NSString *pillTime=[[NSString alloc]init];
    
    
    if ([UserDateArray count]>0)
    {//PIN,STARTDATE
        startDate=[[UserDateArray objectAtIndex:0] objectForKey:@"STARTDATE"];
        pillTime=[[UserDateArray objectAtIndex:0] objectForKey:@"PILLTIME"];
        
        nameStr=[[UserDateArray objectAtIndex:0] objectForKey:@"NAME"];
        
        appDelegate.Pill_countStr=[[UserDateArray objectAtIndex:0] objectForKey:@"PILLCOUNT"];
  
    }
    else
    {
        appDelegate.Pill_countStr = 0;
    }
    
   // [self PillInsert:startDate Time:pillTime];
    
    
    [_med_label_cont setTitle: appDelegate.Pill_countStr forState: UIControlStateNormal];
    
    NSString *MedStr=[NSString stringWithFormat:@"%@",_med_label_cont.titleLabel.text];
    
    
    MedInt=[MedStr intValue];
    
    
    NSArray *SlectIsComp=[dbh Select_All_Appointment];;
    
    for (int i=0; i<[SlectIsComp count]; i++)
    {
        [Iscomp_DateArray addObject:[[SlectIsComp objectAtIndex:i]objectForKey:@"DATE"]];
        [Iscomp_Tital addObject:[[SlectIsComp objectAtIndex:i]objectForKey:@"TITLE"]];
        [Iscomp_Time addObject:[[SlectIsComp objectAtIndex:i]objectForKey:@"TIME"]];
    }
    
    
    //-------------------------------------------------------------------------------------------------
    
    NSMutableArray *Appointment=[dbh AppointmentSelect_upcomming];
    NSMutableArray *aryAcending=[[NSMutableArray alloc]init];
    NSMutableArray *aryDcending=[[NSMutableArray alloc]init];

    
    
    [formater setDateFormat:@"MM-dd-yy"];
    NSDate *currentDt=[[NSDate alloc]init];
    NSString *currentDte=[formater stringFromDate:currentDt];
    NSDate *dt=[formater dateFromString:currentDte];
    
    for (int i=0; i<Appointment.count; i++) {
       NSString *title= [[Appointment objectAtIndex:i] valueForKey:@"TITLE"];
        NSString *Date=[[Appointment objectAtIndex:i] valueForKey:@"DATE"];
        NSString *time=[[Appointment objectAtIndex:i] valueForKey:@"TIME"];
        NSString *desc=[[Appointment objectAtIndex:i] valueForKey:@"DESC"];
        NSString *isConform=[[Appointment objectAtIndex:i] valueForKey:@"ISCONFORM"];
        NSString *strId=[[Appointment objectAtIndex:i] valueForKey:@"ID"];
        
        
        NSMutableDictionary *dic1=[[NSMutableDictionary alloc]init];
        
        [dic1 setValue:title forKey:@"TITLE"];
        [dic1 setValue:Date forKey:@"DATE"];
        [dic1 setValue:time forKey:@"TIME"];
        [dic1 setValue:desc forKey:@"DESC"];
        [dic1 setValue:isConform forKey:@"ISCONFORM"];
         [dic1 setValue:strId forKey:@"ID"];
        
        [formater setDateFormat:@"MM-dd-yy"];
        
        
        NSDate *date1=[formater dateFromString:Date];
        if ([date1 compare:dt] == NSOrderedDescending)
        {
            [aryDcending addObject:dic1];
        }else if([date1 compare:dt] == NSOrderedAscending)
        {
            [aryAcending addObject:dic1];
        }else
        {
            [aryDcending addObject:dic1];
        }
        
    }

    
    
    NSArray *sortedDecending = [aryDcending sortedArrayUsingFunction:dateSort context:nil];
    NSArray *sortedAecending = [aryAcending sortedArrayUsingFunction:dateSort context:nil];
    
    
    _arrUpcommingAppoint=[NSMutableArray arrayWithArray:sortedDecending];
    _arrOverDueAppoint=[NSMutableArray arrayWithArray:sortedAecending];
//    for (int i=0; i<[UpComming count]; i++)
//    {
//        [UpComming_DateArray addObject:[[UpComming objectAtIndex:i]objectForKey:@"DATE"]];
//        [UpComming_Tital addObject:[[UpComming objectAtIndex:i]objectForKey:@"TITLE"]];
//        [arrUpcommingTime addObject:[[UpComming objectAtIndex:i]objectForKey:@"TIME"]];
//        
//    }
//    NSArray *arrUpCommingTitle = [[self.arrUpcommingAppoint reverseObjectEnumerator] allObjects];
//    [self.arrUpcommingAppoint removeAllObjects];
//    self.arrUpcommingAppoint =(NSMutableArray *) arrUpCommingTitle;
    
//    NSArray *arrUpCommingDate = [[UpComming_DateArray reverseObjectEnumerator] allObjects];
//    [UpComming_DateArray removeAllObjects];
//    UpComming_DateArray =(NSMutableArray *) arrUpCommingDate;
//    
//    NSArray *arrUpCmTime = [[arrUpcommingTime reverseObjectEnumerator] allObjects];
//    [arrUpcommingTime removeAllObjects];
//    arrUpcommingTime =(NSMutableArray *) arrUpCmTime;
    //-------------------------------------------------------------------------------------------------
    
    
   // self.arrOverDueAppoint=[dbh AppointmentSelect_overdue];
    
    
    
    
    
    
//    for (int i=0; i<[Over count]; i++)
//    {
//        [Over_DateArray addObject:[[Over objectAtIndex:i]objectForKey:@"DATE"]];
//        [Over_Tital addObject:[[Over objectAtIndex:i]objectForKey:@"TITLE"]];
//        [arrDueTime addObject:[[Over objectAtIndex:i] objectForKey:@"TIME"]];
//  
//    }
    [_completed_button initWithBorders];
    [_upcoming_button initWithBorders];
    [_overdue_button initWithBorders];

    [self.overdue_tableview reloadData];
    [self.upcoming_tableview reloadData];
    [self.completed_tableview reloadData];
    NSLog(@"viewWillAppear");

    [self pillColor];
    
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}

-(void)DisaplayAllData
{
    
}


- (IBAction)back_button_action:(id)sender
{
    @try {
   
       ViewController *objViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"ViewController"];
    NSArray *viewControllers = [[self navigationController] viewControllers];
    
    
    NSLog(@"%@",viewControllers);
    NSLog( @"%@",viewControllers);
    for( int i=0;i<[viewControllers count];i++)
    {
        id obj=[viewControllers objectAtIndex:i];
        if([obj isKindOfClass:[objViewController class]])
        {
            [[self navigationController] popToViewController:obj animated:NO];
            return;
        }
    }

    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}

- (IBAction)task_button_action:(id)sender
{
    @try {
       int index = 0;
    for (UIViewController *vc in self.navigationController.viewControllers) {
        if ([vc isKindOfClass:[AppointmentViewController class]]) {
            [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:index] animated:NO];
            return;
        }
        index++;
    }
    AppointmentViewController *objAppointmentViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"AppointmentViewController"];
    [self.navigationController pushViewController:objAppointmentViewController animated:NO];
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}

#pragma mark Alerts button Action...

- (IBAction)Appintment_button_action:(id)sender
{
    appDelegate.AltertStr=@"Alerts Set By User";
    
    AlertsViewController *objAlertsViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"AlertsViewController"];
    [self.navigationController pushViewController:objAlertsViewController animated:NO];
}

- (IBAction)medical_alerts_button_action:(id)sender
{
    appDelegate.AltertStr=@"Medical Alerts";
    AlertsViewController *objAlertsViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"AlertsViewController"];
    [self.navigationController pushViewController:objAlertsViewController animated:NO];
}

- (IBAction)normal_alerts_button_action:(id)sender
{
     appDelegate.AltertStr=@"Normal Alerts";
    AlertsViewController *objAlertsViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"AlertsViewController"];
    [self.navigationController pushViewController:objAlertsViewController animated:NO];
}

- (IBAction)notification_Tab_button_action:(id)sender
{
    @try {
   
      int index = 0;
    for (UIViewController *vc in self.navigationController.viewControllers) {
        if ([vc isKindOfClass:[NotificationViewController class]]) {
            [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:index] animated:NO];
            return;
        }
        index++;
    }
    NotificationViewController *objNotificationViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"NotificationViewController"];
    [self.navigationController pushViewController:objNotificationViewController animated:NO];
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}

- (IBAction)cal_tab_button_action:(id)sender
{@try{
    int index = 0;
    for (UIViewController *vc in self.navigationController.viewControllers) {
        if ([vc isKindOfClass:[CalViewController class]]) {
            [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:index] animated:NO];
            return;
        }
        index++;
    }
    CalViewController *objCalViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"CalViewController"];
    [self.navigationController pushViewController:objCalViewController animated:NO];
}@catch(NSException *exception){
    NSLog(@"%@",exception.description);
}
    
}

- (IBAction)setting_tab_button_action:(id)sender
{@try{
    int index = 0;
//    for (UIViewController *vc in self.navigationController.viewControllers) {
//        if ([vc isKindOfClass:[SettingViewController class]]) {
//            [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:index] animated:NO];
//            return;
//        }
//        index++;
//    }
    SettingViewController *objSettingViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"SettingViewController"];
    [self.navigationController pushViewController:objSettingViewController animated:NO];
}@catch(NSException *exception){
    NSLog(@"%@",exception.description);
}
    
}

#pragma mark OverDue Button Action.....

- (IBAction)overdue_button_action:(id)sender
{
    @try{
    if (OverShow == NO)
    {
      
        upcomingShow=NO;
        CompShow=NO;
        
        _view1.hidden=NO;
        _view2.hidden=YES;
        _view3.hidden=YES;
        
        
        if (IS_IPHONE4)
        {
            _view1.frame =  CGRectMake(25,311,270,0);
            [_main_scroll setContentSize:CGSizeMake(320,442)];
            _upcoming_button.frame=CGRectMake(20, 325, 280, 35);
            _completed_button.frame=CGRectMake(20, 372, 280, 35);
            
        }else
        {
            
            _view1.frame =  CGRectMake(25,280,270,0);
            [_main_scroll setContentSize:CGSizeMake(320,500)];
            _upcoming_button.frame=CGRectMake(20, 350, 280, 35);
            _completed_button.frame=CGRectMake(20, 412, 280, 35);
            
        }

        
        
        [UIView animateWithDuration:0.50 animations:^{
           if (IS_IPHONE4)
           {
               _main_scroll.scrollEnabled = YES;
               _view1.frame =  CGRectMake(25,311,270,150);
               
               [_main_scroll setContentSize:CGSizeMake(320,560)];
                _upcoming_button.frame=CGRectMake(20, 458, 280, 35);
               _completed_button.frame=CGRectMake(20, 507, 280, 35);
               
           }else
           {
               _main_scroll.scrollEnabled = YES;
               _view1.frame =  CGRectMake(25,280,270,150);
               [_main_scroll setContentSize:CGSizeMake(320,660)];
               _upcoming_button.frame=CGRectMake(20, 460, 280, 35);
               _completed_button.frame=CGRectMake(20, 510, 280, 35);
           }
        }];
        
        OverShow=YES;
    }
    else
    {
        _main_scroll.scrollEnabled = NO;
        [UIView animateWithDuration:0.50 animations:^{
           if (IS_IPHONE4)
           {
                _view1.frame =  CGRectMake(25,311,270,0);
               [_main_scroll setContentSize:CGSizeMake(320,442)];
               _upcoming_button.frame=CGRectMake(20, 325, 280, 35);
               _completed_button.frame=CGRectMake(20, 372, 280, 35);
           }else{
               _view1.frame =  CGRectMake(25,260,270,0);
               [_main_scroll setContentSize:CGSizeMake(320,510)];
               _upcoming_button.frame=CGRectMake(20, 290, 280, 35);
               _completed_button.frame=CGRectMake(20, 335, 280, 35);
           }
        }];
        
        OverShow=NO;
    }
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}

- (IBAction)upcoming_button_action:(id)sender
{@try{
    if (upcomingShow == NO)
    {
        _view1.hidden=YES;
        _view2.hidden=NO;
        _view3.hidden=YES;
        
        OverShow =NO;
        CompShow=NO;
        if (IS_IPHONE4)
        {
            _view2.frame =  CGRectMake(25,353,270,0);
            [_main_scroll setContentSize:CGSizeMake(320,450)];
            _upcoming_button.frame=CGRectMake(20, 325, 280, 35);
            _completed_button.frame=CGRectMake(20, 372, 280, 35);
        }else
        {
            _view2.frame =  CGRectMake(25,325,270,0);
            [_main_scroll setContentSize:CGSizeMake(320,540)];
            _upcoming_button.frame=CGRectMake(20, 290, 280, 35);
            _completed_button.frame=CGRectMake(20, 335, 280, 35);
        }
        [UIView animateWithDuration:0.50 animations:^{
            if (IS_IPHONE4)
            {
                _main_scroll.scrollEnabled = YES;
                _view2.frame =  CGRectMake(25,290,270,150);
                [_main_scroll setContentSize:CGSizeMake(320,590)];
                _completed_button.frame=CGRectMake(20, 500, 280, 35);
            }else
            {
                 _completed_button.frame=CGRectMake(20, 460, 280, 35);
                _main_scroll.scrollEnabled = YES;
                _view2.frame =  CGRectMake(25,325,270,120);
                [_main_scroll setContentSize:CGSizeMake(320,646)];
                _completed_button.frame=CGRectMake(20, 470, 280, 35);
            }
        }];
        upcomingShow=YES;
    }
    else
    {
        _main_scroll.scrollEnabled = NO;
        [UIView animateWithDuration:0.50 animations:^{
            if (IS_IPHONE4)
            {
                _view2.frame =  CGRectMake(25,353,270,0);
                [_main_scroll setContentSize:CGSizeMake(320,450)];
                _upcoming_button.frame=CGRectMake(20, 290, 280, 35);
                _completed_button.frame=CGRectMake(20, 372, 280, 35);
             }else
            {
                _view2.frame =  CGRectMake(25,325,270,0);
                
                [_main_scroll setContentSize:CGSizeMake(320,540)];
                _upcoming_button.frame=CGRectMake(20, 290, 280, 35);
                _completed_button.frame=CGRectMake(20, 335, 280, 35);
              
                
            }
            
        }];
        
        upcomingShow=NO;
    }
    
    
}@catch(NSException *exception){
    NSLog(@"%@",exception.description);
}
    
}

- (IBAction)completed_button_action:(id)sender
{
    @try{
    
    if (CompShow == NO)
    {
        _view1.hidden=YES;
        _view2.hidden=YES;
        _view3.hidden=NO;
        OverShow =NO;
        upcomingShow=NO;
        
        if (IS_IPHONE4)
        {
            _view3.frame =  CGRectMake(25,400,270,0);
            [_main_scroll setContentSize:CGSizeMake(320,450)];
            
        }else
        {
            _view3.frame =  CGRectMake(25,370,270,0);
            [_main_scroll setContentSize:CGSizeMake(320,540)];
            _completed_button.frame=CGRectMake(20, 335, 280, 35);
        }

        
        
        
        [UIView animateWithDuration:0.50 animations:^{
            if (IS_IPHONE4)
            {
                _main_scroll.scrollEnabled = YES;
                _view3.frame =  CGRectMake(25,400,270,150);
                [_main_scroll setContentSize:CGSizeMake(320,590)];
                
                
                //
                
                _upcoming_button.frame=CGRectMake(20, 325, 280, 35);
                _completed_button.frame=CGRectMake(20, 372, 280, 35);
                
               
                
            }else
            {
                _main_scroll.scrollEnabled = YES;
                _view3.frame =  CGRectMake(25,370,270,150);
                [_main_scroll setContentSize:CGSizeMake(320,660)];
                
                //
                _upcoming_button.frame=CGRectMake(20, 290, 280, 35);
                _completed_button.frame=CGRectMake(20, 335, 280, 35);
                
                
                
            }
            
            
        }];
        
        CompShow=YES;
    }
    else
    {
        
        _main_scroll.scrollEnabled = NO;
        
        [UIView animateWithDuration:0.50 animations:^{
            if (IS_IPHONE4)
            {
                  _main_scroll.scrollEnabled = NO;
                
                _view3.frame =  CGRectMake(25,400,270,0);
                [_main_scroll setContentSize:CGSizeMake(320,450)];
                
                
                
            }else
            {
              
                _view3.frame =  CGRectMake(25,370,270,0);
                
                [_main_scroll setContentSize:CGSizeMake(320,540)];
                _completed_button.frame=CGRectMake(20, 335, 280, 35);
                
            }
            
        }];
        
        CompShow=NO;
    }
    
    
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}

- (IBAction)pill_button_action:(id)sender
{
    @try{
        NSMutableArray *DateArray=[dbh selectAllUser];
        DateArray=[dbh selectAllUser];
        NSString *strStartDate=[[NSString alloc]init];
        strStartDate=[[DateArray objectAtIndex:0] objectForKey:@"STARTDATE"];
        
        NSDate *currentDateInLocal = [NSDate date];
        NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
        NSDate *lastPillTakenDate=UDGetObject(@"dtlastPillTakenDate");
        [dateFormat setDateFormat:@"MM-dd-yy"];
        NSString *strCurrentDate=[dateFormat stringFromDate:currentDateInLocal];
      //  NSString *strLastPillTakenDate=[dateFormat stringFromDate:lastPillTakenDate];
        currentDateInLocal =[dateFormat dateFromString:strCurrentDate];
     //   lastPillTakenDate =[dateFormat dateFromString:strCurrentDate];
        NSDate *startDate=[dateFormat dateFromString:strStartDate];
        if ([currentDateInLocal compare:startDate] == NSOrderedAscending) {
            [self Alert:@"You can not take Pill before Start Date"];
        }else{
            

        if (lastPillTakenDate == nil || [currentDateInLocal compare:lastPillTakenDate] == NSOrderedDescending) {
            
       [self PillInsertReq];
    
    [self updateRegularPillTaken:MedInt];
    
    if (Rota==YES)
    {
        
        if (MedInt<1)
        {
        }else
        {
               MedInt--;
            
        NSString *MeStr=[NSString stringWithFormat:@"%d",MedInt];
        appDelegate.Pill_countStr=[NSString stringWithFormat:@"%@",MeStr];
        [dbh Update_pillCount:nameStr];
            
            
        
    [_med_label_cont setTitle:MeStr forState: UIControlStateNormal];
        
    [_med_label_cont setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];

        [UIView animateWithDuration:0.80 animations:^{
            _pill_button.transform = CGAffineTransformMakeRotation(DEGREES_TO_RADIANS(180));
            
        }];
        [UIView animateWithDuration:0.80 animations:^{
            _pill_button.transform = CGAffineTransformMakeRotation(DEGREES_TO_RADIANS(360));
            
        }];
        Rota=NO;
        }
    }
    else
    {
        if (MedInt<1)
        {
            
        }else{
        
        MedInt--;
 
        NSString *MeStr=[NSString stringWithFormat:@"%d",MedInt];
            
        appDelegate.Pill_countStr=[NSString stringWithFormat:@"%@",MeStr];
        
        [dbh Update_pillCount:nameStr];
        
       
            
        [_med_label_cont setTitle:MeStr forState: UIControlStateNormal];
        
        [_med_label_cont setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        
        [UIView animateWithDuration:0.80 animations:^{
            _pill_button.transform = CGAffineTransformMakeRotation(DEGREES_TO_RADIANS(180));
            
        }];
        [UIView animateWithDuration:0.80 animations:^{
            _pill_button.transform = CGAffineTransformMakeRotation(DEGREES_TO_RADIANS(360));
            
        }];
        Rota=YES;
        }
    }
        }else if ([currentDateInLocal compare:lastPillTakenDate] == NSOrderedSame) {
            [self Alert:@"You have already taken today's pill"];
        }
    
        }
     }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}


#pragma mark UITableViewDelegate Protocol Methods-----------------------------------



- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    @try{
    if(tableView.tag==0)
        return [self.arrOverDueAppoint count];
 
    if (tableView.tag==1)
         return [self.arrUpcommingAppoint count];
 
    if(tableView.tag==2)
         return [Iscomp_Tital count];
 
    return 0;
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 35;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    @try{
    if (tableView.tag==0)
    {
        static NSString *simpleTableIdentifier = @"DashboardCustomCellTableViewCell";
        
        overDueTableViewCell *cell = (overDueTableViewCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
        if (cell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"overDueTableViewCell" owner:self options:nil];
            cell = [nib objectAtIndex:0];
            cell.selectionStyle= UITableViewCellSelectionStyleNone;
        }
        cell.lblTitle.text=[NSString stringWithFormat:@"%@ is due",[[self.arrOverDueAppoint objectAtIndex:indexPath.row] valueForKey:@"TITLE"]];
        cell.lblDateTime.text=[NSString stringWithFormat:@"%@ %@",[[self.arrOverDueAppoint objectAtIndex:indexPath.row] valueForKey:@"DATE"],[[self.arrOverDueAppoint objectAtIndex:indexPath.row] valueForKey:@"TIME"]];
        
     //   int Ins=indexPath.row+1;
      //  cell.index_label.text=[NSString stringWithFormat:@"%d",Ins];
        
        
        return cell;
    }
    if (tableView.tag==1)
    {
        static NSString *simpleTableIdentifier = @"DashboardCustomCellTableViewCell";
        
        DashboardCustomCellTableViewCell *cell = (DashboardCustomCellTableViewCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
        if (cell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"DashboardCustomCellTableViewCell" owner:self options:nil];
            cell = [nib objectAtIndex:0];
            cell.selectionStyle= UITableViewCellSelectionStyleNone;
        }
        cell.tital_label.text=[[self.arrUpcommingAppoint objectAtIndex:indexPath.row] valueForKey:@"TITLE"];
        cell.date_label.text=[NSString stringWithFormat:@"%@ %@",[[self.arrUpcommingAppoint objectAtIndex:indexPath.row] valueForKey:@"DATE"],[[self.arrUpcommingAppoint objectAtIndex:indexPath.row] valueForKey:@"TIME"]];
        
        
           int Ins=(int)indexPath.row+1;
        cell.index_label.text=[NSString stringWithFormat:@"%d",Ins];
        
       
        if ([[[_arrUpcommingAppoint objectAtIndex:indexPath.row] valueForKey:@"ISCONFORM"] isEqualToString:@"1"])
            {
                cell.tital_label.textColor=[self colorWithHexString:@"0759B7"];
            }else{
                cell.tital_label.textColor=[UIColor blackColor];
            }
        
         return cell;
        
    } if(tableView.tag==2)
    {
        
        static NSString *simpleTableIdentifier = @"DashboardCustomCellTableViewCell";
        
        DashboardCustomCellTableViewCell *cell = (DashboardCustomCellTableViewCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
        if (cell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"DashboardCustomCellTableViewCell" owner:self options:nil];
            cell = [nib objectAtIndex:0];
            cell.selectionStyle= UITableViewCellSelectionStyleNone;
        }
        
        
        cell.tital_label.text=[Iscomp_Tital objectAtIndex:indexPath.row];
        cell.date_label.text=[NSString stringWithFormat:@"%@ %@",[Iscomp_DateArray objectAtIndex:indexPath.row],[Iscomp_Time objectAtIndex:indexPath.row]];
        
         int Ins=(int)indexPath.row+1;
        cell.index_label.text=[NSString stringWithFormat:@"%d",Ins];
        
       
        
        return cell;
        
        
    }
  
    
    return 0;
   


    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    @try{
    
    if (tableView.tag==0)
    {
        if ([[[self.arrOverDueAppoint objectAtIndex:indexPath.row] valueForKey:@"ISCONFORM"] isEqualToString:@"1"])
        {
            appDelegate.isFromOther=YES;
        }else{
            appDelegate.isFromOther=NO;
        }

        
        appDelegate.ID_App_Str=[[self.arrOverDueAppoint valueForKey:@"ID"] objectAtIndex:indexPath.row];
        appDelegate.isFromDashboard = TRUE;
        EditAppointmentViewViewController *objEditAppointmentViewViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"EditAppointmentViewViewController"];
        objEditAppointmentViewViewController.strTitle = [[self.arrOverDueAppoint valueForKey:@"TITLE"] objectAtIndex:indexPath.row];
        objEditAppointmentViewViewController.strDesc = [[self.arrOverDueAppoint valueForKey:@"DESC"] objectAtIndex:indexPath.row];
        objEditAppointmentViewViewController.strDate = [[self.arrOverDueAppoint valueForKey:@"DATE"]objectAtIndex:indexPath.row];
        objEditAppointmentViewViewController.strTime = [[self.arrOverDueAppoint valueForKey:@"TIME"]objectAtIndex:indexPath.row];

        [self.navigationController pushViewController:objEditAppointmentViewViewController animated:YES];
        
    }
    
    if (tableView.tag==1)
    {
        if ([[[self.arrUpcommingAppoint objectAtIndex:indexPath.row] valueForKey:@"ISCONFORM"] isEqualToString:@"1"])
        {
            appDelegate.isFromOther=YES;
        }else{
            appDelegate.isFromOther=NO;
        }

        
        
         appDelegate.ID_App_Str=[[self.arrUpcommingAppoint valueForKey:@"ID" ] objectAtIndex:indexPath.row];
        
                appDelegate.isFromDashboard = TRUE;
        EditAppointmentViewViewController *objEditAppointmentViewViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"EditAppointmentViewViewController"];
        objEditAppointmentViewViewController.strTitle = [[self.arrUpcommingAppoint valueForKey:@"TITLE"] objectAtIndex:indexPath.row];
        objEditAppointmentViewViewController.strDesc = [[self.arrUpcommingAppoint valueForKey:@"DESC"] objectAtIndex:indexPath.row];
        objEditAppointmentViewViewController.strDate = [[self.arrUpcommingAppoint valueForKey:@"DATE"] objectAtIndex:indexPath.row];
        objEditAppointmentViewViewController.strTime = [[self.arrUpcommingAppoint valueForKey:@"TIME"]objectAtIndex:indexPath.row];

        
        [self.navigationController pushViewController:objEditAppointmentViewViewController animated:YES];
    }

    if (tableView.tag==2)
    {
         appDelegate.CompSel_App_Str=@"1";
        
         appDelegate.Title_App_Str=[Iscomp_Tital objectAtIndex:indexPath.row];
        
        EditAppointmentViewViewController *objEditAppointmentViewViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"EditAppointmentViewViewController"];
        [self.navigationController pushViewController:objEditAppointmentViewViewController animated:NO];
    }
    
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}

-(void)PillInsertReq
{
    @try{
    UDSetValue(@"firstPillTaken", @"firstPillTaken");
    NSDate *currentDateInLocal = [NSDate date];
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    NSDateFormatter *dateFormat1 = [[NSDateFormatter alloc] init];
    
   
   
        
    [dateFormat setDateFormat:@"MM-dd-yy"];
    NSString *DateStr = [dateFormat stringFromDate:currentDateInLocal];
        NSDate *lastPillTakenDate=[dateFormat dateFromString:DateStr];
        
    [[NSUserDefaults standardUserDefaults] setObject:lastPillTakenDate forKey:@"dtlastPillTakenDate"];
    [dateFormat1 setDateFormat:@"hh:mm a"];
    
    NSString* timeStr=[dateFormat1 stringFromDate:currentDateInLocal];
    
    NSMutableDictionary *dic=[[NSMutableDictionary alloc ]init];
      
     [dic setObject:@"1" forKey:@"USER_ID"];
     [dic setObject:@"Medicine 1" forKey:@"MED_NAME"];
     [dic setObject:DateStr forKey:@"START_DATE"];
     [dic setObject:@"0" forKey:@"MED_TAKEN"];
     [dic setObject:@"1" forKey:@"MED_QUNTITY"];
     [dic setObject:timeStr forKey:@"MED_TIME"];
    
    NSMutableArray *dealArray=[[NSMutableArray alloc]init];
    
    [dealArray addObject:dic];
    
    [[NSUserDefaults standardUserDefaults] setObject:DateStr forKey:@"lastPillTakenDate"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    
    [dbh insertMEDICAL_RECORD:dealArray];
       
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}


-(UIColor*)colorWithHexString:(NSString*)hex
{
    NSString *cString = [[hex stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]] uppercaseString];
    
    // String should be 6 or 8 characters
    if ([cString length] < 6) return [UIColor grayColor];
    
    // strip 0X if it appears
    if ([cString hasPrefix:@"0X"]) cString = [cString substringFromIndex:2];
    
    if ([cString length] != 6) return  [UIColor grayColor];
    
    // Separate into r, g, b substrings
    NSRange range;
    range.location = 0;
    range.length = 2;
    NSString *rString = [cString substringWithRange:range];
    
    range.location = 2;
    NSString *gString = [cString substringWithRange:range];
    
    range.location = 4;
    NSString *bString = [cString substringWithRange:range];
    
    // Scan values
    unsigned int r, g, b;
    [[NSScanner scannerWithString:rString] scanHexInt:&r];
    [[NSScanner scannerWithString:gString] scanHexInt:&g];
    [[NSScanner scannerWithString:bString] scanHexInt:&b];
    
    return [UIColor colorWithRed:((float) r / 255.0f)
                           green:((float) g / 255.0f)
                            blue:((float) b / 255.0f)
                           alpha:1.0f];
}

NSComparisonResult dateSort(NSString *s1, NSString *s2, void *context) {
    NSDateFormatter *format=[[NSDateFormatter alloc]init];
    [format setDateFormat:@"MM-dd-YY"];
    NSDate *d1 =[format dateFromString:[s1 valueForKey:@"DATE"]];
    NSDate *d2 = [format  dateFromString:[s2 valueForKey:@"DATE"]];
    return [d1 compare:d2];
}

-(void)pillColor
{
    
    NSString *MedStr=[NSString stringWithFormat:@"%@",_med_label_cont.titleLabel.text];
    MedInt=[MedStr intValue];
    UDSetValue(MedStr,@"med");
    NSString *initialPillCount=[[NSUserDefaults standardUserDefaults] objectForKey:@"initialCount"];
    intialCount=[initialPillCount intValue];
    NSDateFormatter *formatter=[[NSDateFormatter alloc]init];
    //   NSTimeZone *timeZone = [NSTimeZone timeZoneWithName:@"UTC"];
    [formatter setDateFormat:@"MM-dd-yy"];
    // [formatter setTimeZone:timeZone];
    NSString *strlastPillTakenDate=[[NSUserDefaults standardUserDefaults]objectForKey:@"lastPillTakenDate"];
    
    NSDate *lastPillTakenDate=[[NSDate alloc]init];
    lastPillTakenDate= [formatter dateFromString:strlastPillTakenDate];
    NSDate *currentDate=[[NSDate alloc]init];
    NSString *time=[formatter stringFromDate:currentDate];
    currentDate=[formatter dateFromString:time];
    
    if ([lastPillTakenDate compare:currentDate]== NSOrderedAscending)
    {
        [_med_label_cont setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    }else{
        NSString *firstPill=UDGetValue(@"firstPillTaken");
        
        if (!firstPill) {
            [_med_label_cont setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
        }else
        {
            [_med_label_cont setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
            
        }
    }

    
}

-(void)addRegularPillTakenBadgeView
{
    _lblWelcome.layer.cornerRadius=12;
    _lblWelcome.clipsToBounds=YES;
    _lblApointRem.layer.cornerRadius=12;
    _lblApointRem.clipsToBounds=YES;
    _lblApointRem.hidden=YES;
    _lblHiv.layer.cornerRadius=12;
    _lblHiv.clipsToBounds=YES;
    _lblHiv.hidden=YES;
    _lblRegularPillTaken.layer.cornerRadius=10;
    _lblRegularPillTaken.clipsToBounds=YES;
    _lblRegularPillTaken.hidden=YES;
    
    _imgApointRem.hidden=YES;
    _imgHiv.hidden=YES;
    _imgRegularPillTkn.hidden=YES;
    
    int iscompeleted=UDGetInt(@"isCompleted");
    if (iscompeleted == 1) {
          _imgApointRem.hidden=NO;
        _lblApointRem.hidden=NO;
        _lblApointRem.text=@"1";
    }else if (iscompeleted == 2) {
        _imgApointRem.hidden=NO;
        _lblApointRem.hidden=NO;
        _lblApointRem.text=@"2";

    }else if(iscompeleted == 3){
        _imgApointRem.hidden=NO;
        _lblApointRem.hidden=NO;
        _lblApointRem.text=@"3";
      _imgHiv.hidden=NO;
        _lblHiv.hidden=NO;
        _lblHiv.text=@"1";
    }
 }

-(void)updateRegularPillTaken:(int)pillCount
{
    formater =[[NSDateFormatter alloc] init];
    int isBefore=1;
   DataBase *db;
    db=[[DataBase alloc]init];
    NSDate *currentDateInLocal = [NSDate date];
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:@"MM-dd-yy"];
    NSString *strCurrentDate = [dateFormat stringFromDate:currentDateInLocal];
    NSDate *currentDate=[dateFormat dateFromString:strCurrentDate];
    NSMutableArray *ary1=[[NSMutableArray alloc]init];
    ary1=[db selectRegularPillTaken];
    int lastpill=(int)ary1.count-1;
   
    
    NSMutableArray *aryMedicationReport=[[NSMutableArray alloc]init];
    aryMedicationReport= [db selectAllUser];
    NSString *sheduledTime=[[NSString alloc]init];
    sheduledTime=[[aryMedicationReport objectAtIndex:0] valueForKey:@"PILLTIME"];
    NSMutableArray *aryPilltakenTime=[[NSMutableArray alloc]init];
    aryPilltakenTime=[db selectMEDICAL_RECORD];
    int n=aryPilltakenTime.count;
    NSString *pilltakenTime=[[aryPilltakenTime objectAtIndex:n-1] valueForKey:@"MED_TIME"];
    NSString *pilltakenDate=[[aryPilltakenTime objectAtIndex:n-1] valueForKey:@"START_DATE"];
    
    
  
    
    NSDate *dteSheduled=[[NSDate alloc]init];
    NSDate *dtePilltaken=[[NSDate alloc]init];
    [formater setDateFormat:@"hh:mm a"];
    dteSheduled=[formater dateFromString:sheduledTime];
    dtePilltaken=[formater dateFromString:pilltakenTime];
    NSString *timeDiff =[self calculateDifference:dteSheduled oldTime:dtePilltaken];
    NSTimeInterval interval =[dteSheduled timeIntervalSinceDate:dtePilltaken];
    if (interval <= 0) {
        timeDiff=[@"-" stringByAppendingString:timeDiff];
        isBefore=0;
    }
    
    
    
    //insert Reguar Pill taken
    if (lastpill>=0)
    {
        
        if (pillCount<=10)
        {
            [self disableNotification:@"You have PillCount less than 10"];
            NSDate *curentDate=[[NSDate alloc]init];
            [self enableNotification:curentDate alertBody:@"You have PillCount less than 10"];
        }
        
        NSMutableDictionary *dicRgularPillTkn=[[NSMutableDictionary alloc]init];
        NSString *strMed=[[ary1 objectAtIndex:lastpill] valueForKey:@"MED_ID"];
        NSString *medTknDate=[[ary1 objectAtIndex:lastpill] valueForKey:@"MED_TAKEN_DATE"];
        int medId=[strMed integerValue];
        [formater setDateFormat:@"MM-dd-yy"];
        NSDate *lastPillTaknDate=[formater dateFromString:medTknDate];
        [formater setDateFormat:@"dd-MM-yyyy"];
        NSString *strdateTaken=[formater stringFromDate:lastPillTaknDate];
        NSDate *dateTaken=[[NSDate alloc]init];
        [formater setDateFormat:@"dd-MM-yyyy"];
        dateTaken=[formater dateFromString:strdateTaken];
        
        if (medId == 30) {
            _imgRegularPillTkn.hidden=NO;
            _lblRegularPillTaken.hidden=NO;
            _lblRegularPillTaken.text=@"30";
        }else if(medId == 60){
            _imgRegularPillTkn.hidden=NO;
            _lblRegularPillTaken.hidden=NO;
            _lblRegularPillTaken.text=@"60";
        }else if(medId == 90){
            _imgRegularPillTkn.hidden=NO;
            _lblRegularPillTaken.hidden=NO;
            _lblRegularPillTaken.text=@"90";
        }
        
    if ([lastPillTaknDate compare:currentDate] == NSOrderedAscending)
    {
        
        
         NSDate *newDate1 = [lastPillTaknDate dateByAddingTimeInterval:60*60*24*1];
        [dateFormat setDateFormat:@"MM-dd-yy"];
        NSString *strMissedPillaken=[dateFormat stringFromDate:newDate1];
      
        
       
        if ([newDate1 compare:currentDate] == NSOrderedSame)
        {
            
            //insert Medication Report
            NSMutableArray *aryMedicationReport=[[NSMutableArray alloc]init];
            NSMutableDictionary *dicMedicationReport=[[NSMutableDictionary alloc]init];
            [dicMedicationReport setObject:timeDiff forKey:@"MED_TIME_DIFF"];
            [dicMedicationReport setObject:[NSString stringWithFormat:@"%d", medId ] forKey:@"MED_TAKEN"];
            [dicMedicationReport setObject:pilltakenDate forKey:@"MED_TAKEN_DATE"];
            [dicMedicationReport setObject:pilltakenTime forKey:@"MED_TAKEN_TIME"];
            [dicMedicationReport setObject:sheduledTime forKey:@"MED_SCHEDULE_TIME"];
            [dicMedicationReport setObject:[NSString stringWithFormat:@"%d",isBefore] forKey:@"ISAFTER_OR_BEFORE"];
            [aryMedicationReport addObject:dicMedicationReport];
            [db insertMedicationReport:aryMedicationReport];
            
                //insert Regular pill taken
                medId=medId+1;
                [dicRgularPillTkn setObject:strCurrentDate forKey:@"MED_TAKEN_DATE"];
                [dicRgularPillTkn setObject:[NSNumber numberWithInt:medId] forKey:@"MED_ID"];
                [dicRgularPillTkn setObject:[NSNumber numberWithInt:1] forKey:@"ISAFTER_OR_BEFORE"];
                [dicRgularPillTkn setObject:[NSNumber numberWithInt:1] forKey:@"MED_TAKEN"];
                NSMutableArray *aryRegPilTkn=[[NSMutableArray alloc]init];
                [aryRegPilTkn addObject:dicRgularPillTkn];
                [db insertRegularPillTaken:aryRegPilTkn];
        }
        else
        {
                while(!([newDate1 compare:currentDate] == NSOrderedSame))
               {
                //insert Medication Report
                NSMutableArray *aryMedicationReport=[[NSMutableArray alloc]init];
                NSMutableDictionary *dicMedicationReport=[[NSMutableDictionary alloc]init];
                [dicMedicationReport setObject:@"-" forKey:@"MED_TIME_DIFF"];
                [dicMedicationReport setObject:@"-" forKey:@"MED_TAKEN"];
                [dicMedicationReport setObject:strMissedPillaken forKey:@"MED_TAKEN_DATE"];
                [dicMedicationReport setObject:@"-" forKey:@"MED_TAKEN_TIME"];
                [dicMedicationReport setObject:sheduledTime forKey:@"MED_SCHEDULE_TIME"];
                [dicMedicationReport setObject:@"-" forKey:@"ISAFTER_OR_BEFORE"];
                [aryMedicationReport addObject:dicMedicationReport];
                [db insertMedicationReport:aryMedicationReport];
                    
                newDate1=[newDate1 dateByAddingTimeInterval:60*60*24*1];
                [dateFormat setDateFormat:@"MM-dd-yy"];
                strMissedPillaken=[dateFormat stringFromDate:newDate1];
                }
                
                NSMutableArray *aryMedicationReport=[[NSMutableArray alloc]init];
                NSMutableDictionary *dicMedicationReport=[[NSMutableDictionary alloc]init];
                [dicMedicationReport setObject:timeDiff forKey:@"MED_TIME_DIFF"];
                [dicMedicationReport setObject:[NSString stringWithFormat:@"%d", medId ] forKey:@"MED_TAKEN"];
                [dicMedicationReport setObject:pilltakenDate forKey:@"MED_TAKEN_DATE"];
                [dicMedicationReport setObject:pilltakenTime forKey:@"MED_TAKEN_TIME"];
                [dicMedicationReport setObject:sheduledTime forKey:@"MED_SCHEDULE_TIME"];
                [dicMedicationReport setObject:[NSString stringWithFormat:@"%d",isBefore] forKey:@"ISAFTER_OR_BEFORE"];
                [aryMedicationReport addObject:dicMedicationReport];
                [db insertMedicationReport:aryMedicationReport];
                [db deleteRegularPillTaken];
                _imgRegularPillTkn.hidden=YES;
            }
    }
        
    }
    else
    {
         NSMutableArray *ary=[[NSMutableArray alloc]init];
        ary=[db selectMedicationReport];
        if (ary.count ==0) {
            [dateFormat setDateFormat:@"dd-MM-yyyy"];
            NSString *strdateTaken=[formater stringFromDate:currentDateInLocal];
            [dateFormat setDateFormat:@"dd-MM-yyyy"];
            NSDate *dateTaken=[[NSDate alloc]init];
            dateTaken=[formater dateFromString:strdateTaken];
            
            
            NSMutableArray *aryMedicationReport=[[NSMutableArray alloc]init];
            NSMutableDictionary *dicMedicationReport=[[NSMutableDictionary alloc]init];
            //insert medication report
            
            [dicMedicationReport setObject:timeDiff forKey:@"MED_TIME_DIFF"];
            [dicMedicationReport setObject:[NSString stringWithFormat:@"%d", 1] forKey:@"MED_TAKEN"];
            [dicMedicationReport setObject:strCurrentDate forKey:@"MED_TAKEN_DATE"];
            [dicMedicationReport setObject:pilltakenTime forKey:@"MED_TAKEN_TIME"];
            [dicMedicationReport setObject:sheduledTime forKey:@"MED_SCHEDULE_TIME"];
            [dicMedicationReport setObject:[NSString stringWithFormat:@"%d", isBefore] forKey:@"ISAFTER_OR_BEFORE"];
            [aryMedicationReport addObject:dicMedicationReport];
            [db insertMedicationReport:aryMedicationReport];
        }else
        {
        NSString *strlastMadication=[[ary objectAtIndex:ary.count-1] valueForKey:@"MED_TAKEN_DATE"];
        [formater setDateFormat:@"MM-dd-yy"];
        NSDate *lastMedication=[[NSDate alloc]init];
        lastMedication= [formater dateFromString:strlastMadication];
        [formater setDateFormat:@"dd-MM-yyyy"];
        NSString *str1=[formater stringFromDate:lastMedication];
        lastMedication= [formater dateFromString:str1];
    
        if ([lastMedication compare:currentDate] == NSOrderedAscending)
        {
            NSDate *newDate1 = [lastMedication dateByAddingTimeInterval:60*60*24*1];
            [formater setDateFormat:@"MM-dd-yy"];
            strlastMadication=[formater stringFromDate:newDate1];
            while(!([newDate1 compare:currentDate] == NSOrderedSame))
            {
                //insert Medication Report
                NSMutableArray *aryMedicationReport=[[NSMutableArray alloc]init];
                NSMutableDictionary *dicMedicationReport=[[NSMutableDictionary alloc]init];
                [dicMedicationReport setObject:@"-" forKey:@"MED_TIME_DIFF"];
                [dicMedicationReport setObject:@"-" forKey:@"MED_TAKEN"];
                [dicMedicationReport setObject:strlastMadication forKey:@"MED_TAKEN_DATE"];
                [dicMedicationReport setObject:@"-" forKey:@"MED_TAKEN_TIME"];
                [dicMedicationReport setObject:sheduledTime forKey:@"MED_SCHEDULE_TIME"];
                [dicMedicationReport setObject:@"-" forKey:@"ISAFTER_OR_BEFORE"];
                [aryMedicationReport addObject:dicMedicationReport];
                [db insertMedicationReport:aryMedicationReport];
                
                newDate1=[newDate1 dateByAddingTimeInterval:60*60*24*1];
                [dateFormat setDateFormat:@"MM-dd-yy"];
                strlastMadication=[dateFormat stringFromDate:newDate1];
            }

            
        [dateFormat setDateFormat:@"dd-MM-yyyy"];
        NSString *strdateTaken=[formater stringFromDate:currentDateInLocal];
        [dateFormat setDateFormat:@"dd-MM-yyyy"];
        NSDate *dateTaken=[[NSDate alloc]init];
        dateTaken=[formater dateFromString:strdateTaken];

        
        NSMutableArray *aryMedicationReport=[[NSMutableArray alloc]init];
        NSMutableDictionary *dicMedicationReport=[[NSMutableDictionary alloc]init];
        //insert medication report
    
        [dicMedicationReport setObject:timeDiff forKey:@"MED_TIME_DIFF"];
        [dicMedicationReport setObject:[NSString stringWithFormat:@"%d", 1] forKey:@"MED_TAKEN"];
        [dicMedicationReport setObject:strCurrentDate forKey:@"MED_TAKEN_DATE"];
        [dicMedicationReport setObject:pilltakenTime forKey:@"MED_TAKEN_TIME"];
        [dicMedicationReport setObject:sheduledTime forKey:@"MED_SCHEDULE_TIME"];
        [dicMedicationReport setObject:[NSString stringWithFormat:@"%d", isBefore] forKey:@"ISAFTER_OR_BEFORE"];
        [aryMedicationReport addObject:dicMedicationReport];
        [db insertMedicationReport:aryMedicationReport];
        }
        //  insert regular pill taken
        NSMutableDictionary *dicRegPilData=[[NSMutableDictionary alloc]init];
        [dicRegPilData setObject:[NSNumber numberWithInt:1] forKey:@"MED_ID"];
        [dicRegPilData setObject:[NSNumber numberWithInt:1] forKey:@"ISAFTER_OR_BEFORE"];
        [dicRegPilData setObject:[NSNumber numberWithInt:1] forKey:@"MED_TAKEN"];
        [dicRegPilData setObject:strCurrentDate forKey:@"MED_TAKEN_DATE"];
   
        NSMutableArray *insertRegularPill=[[NSMutableArray alloc]init];
            [insertRegularPill addObject:dicRegPilData];
        
          [db insertRegularPillTaken:insertRegularPill];
    }
    
    
         //       CREATE TABLE "MED_RECORD_TIME" ("MED_ID" INTEGER PRIMARY KEY,"MED_TIME_DIFF" VARCHAR,"MED_TAKEN" INTEGER DEFAULT (null) ,"MED_TAKEN_DATE" VARCHAR, "MED_TAKEN_TIME" VARCHAR, "MED_SCHEDULE_TIME" VARCHAR, "ISAFTER_OR_BEFORE" INTEGER)
        
        
}
}

-(void)enableNotification:(NSDate *)date alertBody:(NSString *)title
{
    UILocalNotification* localNotification = [[UILocalNotification alloc] init];
    localNotification.fireDate = date;
    localNotification.alertBody = title;
    localNotification.soundName=UILocalNotificationDefaultSoundName;
    [[UIApplication sharedApplication] scheduleLocalNotification:localNotification];
    NSLog(@"%@",localNotification);

}



-(void)disableNotification:(NSString*)alertBodyTitle
{
    NSArray *arrayOfLocalNotifications = [[UIApplication sharedApplication] scheduledLocalNotifications] ;
    
    for (UILocalNotification *localNotification in arrayOfLocalNotifications)
    {
        if ([localNotification.alertBody isEqualToString:alertBodyTitle])
        {
            NSLog(@"the notification this is canceld is %@", localNotification.alertBody);
            
            [[UIApplication sharedApplication] cancelLocalNotification:localNotification] ;
            // delete the notification from the system
        }
    }
}


- (NSString *)calculateDifference:(NSDate *)currentTime oldTime:(NSDate *)oldTime
{
    NSDate *date1 = currentTime;
    NSDate *date2 = oldTime;
    
    NSTimeInterval secondsBetween = [date2 timeIntervalSinceDate:date1];
    
    int hh = secondsBetween / (60*60);
    double rem = fmod(secondsBetween, (60*60));
    int mm = rem / 60;
    rem = fmod(rem, 60);
    int ss = rem;
   int  gapBetweenStartTimeAndEndTime = hh;
    NSDate * dateDifference = [NSDate dateWithTimeIntervalSinceReferenceDate:secondsBetween];
    NSString *str;
    
    if (hh < 0)
    {
        hh=-hh;
        if (mm < 0)
        {
            mm=-mm;
        }
         str = [NSString stringWithFormat:@"%02d:%02d",hh,mm];
    }else if(hh > 0)
    {
        if (mm<0) {
            mm=-mm;
            str = [NSString stringWithFormat:@"%02d:%02d",hh,mm];
        }else
        {
         str = [NSString stringWithFormat:@"%02d:%02d",hh,mm];
        }
    }else if (hh == 0)
    {
        if (mm<0) {
            mm=-mm;
            str = [NSString stringWithFormat:@"%02d:%02d",hh,mm];
        }else{
            str = [NSString stringWithFormat:@"%02d:%02d",hh,mm];
        }
    }
       return str;
}

-(void)Alert:(NSString *)alertBody
{
    UIAlertView *myAlert = [[UIAlertView alloc]               initWithTitle:@"Alert"
                                                                    message:alertBody
                                                                   delegate:self
                                                          cancelButtonTitle:@"Ok"
                                                          otherButtonTitles:nil];
    
    [myAlert show];
}

@end
