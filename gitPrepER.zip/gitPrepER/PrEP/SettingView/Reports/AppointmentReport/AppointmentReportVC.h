//
//  AppointmentReportVC.h
//  PrEP
//
//  Created by pradip.r on 10/29/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppointmentReportVC : UIViewController<UITableViewDataSource,UITableViewDelegate>
- (IBAction)onbtnSelectFrame:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *onbtnSelectFrame;
@property (weak, nonatomic) IBOutlet UILabel *lblAppoinCompletOnTime;
@property (weak, nonatomic) IBOutlet UILabel *lblAppointLateOrDue;
@property (weak, nonatomic) IBOutlet UITableView *tblviewAppointReport;
@property (weak, nonatomic) IBOutlet UITableView *tblviewSelectFrameTime;
- (IBAction)onbtnBack:(id)sender;

@end
