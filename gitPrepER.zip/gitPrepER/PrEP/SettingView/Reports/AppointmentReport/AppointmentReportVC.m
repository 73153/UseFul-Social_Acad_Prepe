 //
//  AppointmentReportVC.m
//  PrEP
//
//  Created by pradip.r on 10/29/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import "AppointmentReportVC.h"
#import "AppointmentReportTVC.h"
#import "MedicationReportSingleColTVC.h"
#import "Constant.h"
#import "DataBase.h"

@interface AppointmentReportVC ()
{
    NSMutableArray *arySelectAppointReportType;
    NSMutableArray *aryAppointData;
    NSMutableArray *arySelectAppointReport;
    DataBase *dbh;
    NSDateFormatter *formater;
    int CompletedOnTime;
   int NotCompletedOnTime;
    NSMutableArray *arySelectAppointReport30Days;
    NSMutableArray *arySelectAppointReport60Days;
    NSMutableArray *arySelectAppointReport90Days;
}
@end

@implementation AppointmentReportVC

- (void)viewDidLoad {
    [super viewDidLoad];
    dbh=[[DataBase alloc]init];
    
    _tblviewSelectFrameTime.hidden=YES;
    
    arySelectAppointReport=[[NSMutableArray alloc]init];
    
    aryAppointData=[[NSMutableArray alloc]init];
    aryAppointData=[dbh getRecentlyCompoletedAppointment];
    
    
    
    formater=[[NSDateFormatter alloc]init];
    
    if(aryAppointData.count == 0)
    {
     _tblviewAppointReport.hidden=YES;
    [appDelegate.window makeToast:@"No Appointment Report" duration:1.0 position:@"center"];
    }
    else
    {
        NSArray *sorted = [aryAppointData sortedArrayUsingFunction:dateSort1 context:nil];
        arySelectAppointReport=[NSMutableArray arrayWithArray:sorted];
        _tblviewAppointReport.hidden=NO;
        [self updateData];
    }
    
    arySelectAppointReportType=[[NSMutableArray alloc]initWithObjects:@"Past 30 Days",@"Past 90 Days",@"Past 60 Days",@"Other", nil];
    UDSetObject(@"Other", @"selectFrame");
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 1 ;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (tableView.tag==0)
    {
      return arySelectAppointReport.count+1;
    }
    return arySelectAppointReportType.count;
}


- (UITableViewCell *)tableView:(UITableView *)tv cellForRowAtIndexPath:(NSIndexPath*)indexPath
{
    @try
    {
        if (tv.tag == 0)
        {
            static NSString *CellIdentifier = @"AppointmentReportTVC";
            
            AppointmentReportTVC *cell = (AppointmentReportTVC *)[_tblviewAppointReport dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil)
            {
                NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"AppointmentReportTVC" owner:self options:nil];
                cell = [nib objectAtIndex:0];
                cell.selectionStyle= UITableViewCellSelectionStyleNone;
            }
            
            if (indexPath.row == 0)
            {
                cell.txtDate.text=@"Date";
                cell.txtAppointTitle.text=@"Appointment Title";
                cell.txtDateCompleted.text=@"Date Completed";
            }else
            {
                cell.txtDate.text=[[arySelectAppointReport objectAtIndex:indexPath.row -1] valueForKey:@"DATE"];
                cell.txtAppointTitle.text=[[arySelectAppointReport objectAtIndex:indexPath.row-1] valueForKey:@"TITLE"];
                cell.txtDateCompleted.text=[[arySelectAppointReport objectAtIndex:indexPath.row-1] valueForKey:@"DATECOMPLETED"];
            }
            return cell;
        }
        else if(tv.tag == 1)
        {
            static NSString *CellIdentifier = @"MedicationReportSingleColTVC";
            MedicationReportSingleColTVC *cell = (MedicationReportSingleColTVC *)[_tblviewSelectFrameTime dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil)
            {
                NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"MedicationReportSingleColTVC" owner:self options:nil];
                cell = [nib objectAtIndex:0];
                cell.selectionStyle= UITableViewCellSelectionStyleNone;
            }
            cell.lblTitle.text=[arySelectAppointReportType objectAtIndex:indexPath.row];
            NSString *type=[arySelectAppointReportType objectAtIndex:indexPath.row];
            
            NSString *MedicationType=UDGetObject(@"selectFrame");
            if ([type isEqualToString:MedicationType]) {
                cell.accessoryType = UITableViewCellAccessoryCheckmark;
            }else{
                cell.accessoryType = UITableViewCellAccessoryNone;
            }
            
                return cell;
        }
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}

//- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
// 
//}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView.tag == 0)
    {
        
    }else if (tableView.tag == 1)
    {
        _tblviewSelectFrameTime.hidden=YES;
        UDSetObject([arySelectAppointReportType objectAtIndex:indexPath.row], @"selectFrame");
        
        [self updateData];
        
        NSString *strSelectedType=[arySelectAppointReportType objectAtIndex:indexPath.row];
        [_onbtnSelectFrame setTitle:strSelectedType forState:UIControlStateNormal];
     
    
        if ([strSelectedType isEqualToString:@"Past 30 Days"])
        {
              arySelectAppointReport=[[NSMutableArray alloc]init];
            arySelectAppointReport=arySelectAppointReport30Days;
            [self updateLable];
        }else if ([strSelectedType isEqualToString:@"Past 60 Days"])
        {
              arySelectAppointReport=[[NSMutableArray alloc]init];
            arySelectAppointReport=arySelectAppointReport60Days;
            [self updateLable];
            
        }else if ([strSelectedType isEqualToString:@"Past 90 Days"])
        {
              arySelectAppointReport=[[NSMutableArray alloc]init];
            arySelectAppointReport=arySelectAppointReport90Days;
            [self updateLable];
        }else if ([strSelectedType isEqualToString:@"Other"])
        {
            
        }
     
        [_tblviewAppointReport reloadData];
        [_tblviewSelectFrameTime reloadData];
  
        
    }
}

- (IBAction)onbtnSelectFrame:(id)sender
{
    _tblviewSelectFrameTime.hidden=NO;
}

- (IBAction)onbtnBack:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];

}


-(void)updateData
{
    CompletedOnTime=0;
    NotCompletedOnTime=0;
    
 
    NSArray *sorted = [aryAppointData sortedArrayUsingFunction:dateSort1 context:nil];
    arySelectAppointReport=[[NSMutableArray alloc]init];
    arySelectAppointReport=[NSMutableArray arrayWithArray:sorted];
    
    arySelectAppointReport30Days=[[NSMutableArray alloc]init];
    arySelectAppointReport60Days=[[NSMutableArray alloc]init];
    arySelectAppointReport90Days=[[NSMutableArray alloc]init];
    
    NSDate *currentDate=[[NSDate alloc]init];
    NSDate *date30=[[NSDate alloc]init];
    NSDate *date60=[[NSDate alloc]init];
    NSDate *date90=[[NSDate alloc]init];
    date30=[currentDate dateByAddingTimeInterval:-60*60*24*30];
    date60=[currentDate dateByAddingTimeInterval:-60*60*24*30];
    date90=[currentDate dateByAddingTimeInterval:-60*60*24*30];

    NSString *strCurrentDate=[formater stringFromDate:currentDate];
    NSString *strdate30=[formater stringFromDate:date30];
    NSString *strdate60=[formater stringFromDate:date60];
    NSString *strdate90=[formater stringFromDate:date90];
    
    currentDate=[formater dateFromString:strCurrentDate];
    date30=[formater dateFromString:strdate30];
    date60=[formater dateFromString:strdate60];
    date90=[formater dateFromString:strdate90];
    
    
    for (int i=0; i<arySelectAppointReport.count; i++)
    {
        NSString *strDateScheduled=[[NSString alloc]init];
        strDateScheduled=[[arySelectAppointReport objectAtIndex:i] valueForKey:@"DATE"];
        NSString *strDateCompleted=[[NSString alloc]init];
       strDateCompleted=[[arySelectAppointReport objectAtIndex:i] valueForKey:@"DATECOMPLETED"];
        [formater setDateFormat:@"MM-dd-yy"];
        NSDate *dateScheduled=[[NSDate alloc]init];
        NSDate *dateCompleted=[[NSDate alloc]init];
        dateScheduled=[formater dateFromString:strDateScheduled];
        dateCompleted=[formater dateFromString:strDateCompleted];
        [formater setDateFormat:@"dd-MM-yyyy"];
        strDateScheduled=[formater stringFromDate:dateScheduled];
        strDateCompleted=[formater stringFromDate:dateCompleted];
        dateScheduled=[formater dateFromString:strDateScheduled];
        dateCompleted=[formater dateFromString:strDateCompleted];
        
        if ([dateScheduled compare:dateCompleted] == NSOrderedAscending)
        {
            NotCompletedOnTime+=1;
        }else if ([dateScheduled compare:dateCompleted] == NSOrderedDescending)
        {
            CompletedOnTime+=1;
        }else if ([dateScheduled compare:dateCompleted] == NSOrderedSame)
        {
            CompletedOnTime+=1;
        }
        
        
        
        if ([dateScheduled compare:currentDate] == NSOrderedAscending)
        {
            if ([date30 compare:dateScheduled]==NSOrderedDescending)
            {
                [arySelectAppointReport30Days addObject:[arySelectAppointReport objectAtIndex:i]];
                [arySelectAppointReport60Days addObject:[arySelectAppointReport objectAtIndex:i]];
                [arySelectAppointReport90Days addObject:[arySelectAppointReport objectAtIndex:i]];
            }else if ([date60 compare:dateScheduled]==NSOrderedDescending)
            {
                [arySelectAppointReport60Days addObject:[arySelectAppointReport objectAtIndex:i]];
                 [arySelectAppointReport90Days addObject:[arySelectAppointReport objectAtIndex:i]];
            }else if ([date90 compare:dateScheduled]==NSOrderedDescending)
            {
                [arySelectAppointReport90Days addObject:[arySelectAppointReport objectAtIndex:i]];
            }
            
            
        }else if ([dateScheduled compare:currentDate] == NSOrderedSame)
        {
            [arySelectAppointReport30Days addObject:[arySelectAppointReport objectAtIndex:i]];
            [arySelectAppointReport60Days addObject:[arySelectAppointReport objectAtIndex:i]];
            [arySelectAppointReport90Days addObject:[arySelectAppointReport objectAtIndex:i]];
        }
        
    }
    
    
    _lblAppoinCompletOnTime.text=[NSString stringWithFormat:@"%d",CompletedOnTime];
    _lblAppointLateOrDue.text=[NSString stringWithFormat:@"%d",NotCompletedOnTime];
    
    
    
    [_tblviewAppointReport reloadData];

}


-(void)updateLable
{
    CompletedOnTime=0;
    NotCompletedOnTime=0;
    
    for (int i=0; i<arySelectAppointReport.count; i++)
    {
        NSString *strDateScheduled=[[NSString alloc]init];
        strDateScheduled=[[arySelectAppointReport objectAtIndex:i] valueForKey:@"DATE"];
        NSString *strDateCompleted=[[NSString alloc]init];
        strDateCompleted=[[arySelectAppointReport objectAtIndex:i] valueForKey:@"DATECOMPLETED"];
        [formater setDateFormat:@"MM-dd-yy"];
        NSDate *dateScheduled=[[NSDate alloc]init];
        NSDate *dateCompleted=[[NSDate alloc]init];
        dateScheduled=[formater dateFromString:strDateScheduled];
        dateCompleted=[formater dateFromString:strDateCompleted];
        [formater setDateFormat:@"dd-MM-yyyy"];
        strDateScheduled=[formater stringFromDate:dateScheduled];
        strDateCompleted=[formater stringFromDate:dateCompleted];
        dateScheduled=[formater dateFromString:strDateScheduled];
        dateCompleted=[formater dateFromString:strDateCompleted];
        
        if ([dateScheduled compare:dateCompleted] == NSOrderedAscending)
        {
            NotCompletedOnTime+=1;
        }else if ([dateScheduled compare:dateCompleted] == NSOrderedDescending)
        {
            CompletedOnTime+=1;
        }else if ([dateScheduled compare:dateCompleted] == NSOrderedSame)
        {
            CompletedOnTime+=1;
        }
       
 
}
    _lblAppoinCompletOnTime.text=[NSString stringWithFormat:@"%d",CompletedOnTime];
    _lblAppointLateOrDue.text=[NSString stringWithFormat:@"%d",NotCompletedOnTime];
}




NSComparisonResult dateSort1(NSString *s1, NSString *s2, void *context) {
    NSDateFormatter *format=[[NSDateFormatter alloc]init];
        [format setDateFormat:@"MM-dd-yy"];
        NSDate *d1 =[format dateFromString:[s1 valueForKey:@"DATE"]];
        NSDate *d2 = [format  dateFromString:[s2 valueForKey:@"DATE"]];
        return [d1 compare:d2];
}

@end
