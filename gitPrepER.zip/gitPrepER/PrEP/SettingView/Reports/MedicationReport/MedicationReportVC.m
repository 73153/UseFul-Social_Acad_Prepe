//
//  MedicationReportVC.m
//  PrEP
//
//  Created by pradip.r on 10/23/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import "MedicationReportVC.h"
#import "DataBase.h"
#import "MedicationReportSingleColTVC.h"
#import "MedicationReportMultiColTVC.h"
#import "Constant.h"


@interface MedicationReportVC ()
{
    DataBase *dbh;
    NSMutableArray *arySelectMedicationReport;
    NSMutableArray *arySelectMedicationReportType;
    NSString *startDate;
    NSString *endDate;
    NSString *DateTitle;
    NSString *daysInFrame;
    int DaysComplaint;
    int DaysNonComplaint;
    NSDateFormatter *formater;
    int DaysMissed;
    double avgMedTAkenEarly;
    double avgMedTAkenLate;
    double avgMin;
    double avgMinLate;
    NSString *strAvgMedtakenEarly;
    NSString *strAvgMedtakenLate;
}
@end

@implementation MedicationReportVC

- (void)viewDidLoad
{
    [super viewDidLoad];
       formater=[[NSDateFormatter alloc]init];
    dbh =[[DataBase alloc]init];
    arySelectMedicationReport=[[NSMutableArray alloc]init];
    arySelectMedicationReport=[dbh selectMedicationReport];
    
    arySelectMedicationReportType=[[NSMutableArray alloc]initWithObjects:@"Past 30 Days",@"Past 90 Days",@"Past 60 Days",@"Other", nil];
  _tblViewMedicationReportType.hidden=YES;
    UDSetObject(@"Other", @"MedicationType");
    
    if (arySelectMedicationReport.count == 0) {
        _tblViewMedicationReport.hidden=YES;
    [appDelegate.window makeToast:@"No Medication Report" duration:1.0 position:@"center"];
    }else{
         _tblViewMedicationReport.hidden=NO;
          [self updateData];
    }
}


-(void)viewWillAppear:(BOOL)animated
{

    self.tblViewMedicationReport.separatorStyle = UITableViewCellSeparatorStyleNone;
  
}
#pragma mark -table view dat sources

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1 ;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (tableView.tag==0)
    {
       return  arySelectMedicationReport.count+13;
    }
    
    return arySelectMedicationReportType.count;
}


- (UITableViewCell *)tableView:(UITableView *)tv cellForRowAtIndexPath:(NSIndexPath*)indexPath {
    @try{
        
        if (tv.tag == 0)
        {
              static NSString *CellIdentifier = @"MedicationReportMultiColTVC";
        
        MedicationReportMultiColTVC *cell = (MedicationReportMultiColTVC *)[_tblViewMedicationReport dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"MedicationReportMultiColTVC" owner:self options:nil];
            cell = [nib objectAtIndex:0];
            cell.selectionStyle= UITableViewCellSelectionStyleNone;
        }

        
        if ((indexPath.row == 0)  || (indexPath.row == 1))
        {
            cell.txtDate.hidden=YES;
            cell.txtScheduledTime.hidden=YES;
            cell.txtActualTime.hidden=YES;
            cell.txtTimeDifference.hidden=YES;
            cell.lblEndTitle.hidden=YES;
            cell.lblFrontTitle.hidden=YES;
            cell.lblCenterTitle.hidden=NO;
            
            if ((indexPath.row == 0) )
            {
                cell.lblCenterTitle.text=@"Medication Report";
                cell.backgroundColor=[UIColor whiteColor];
                [cell.contentView.layer setBorderColor:[UIColor blackColor].CGColor];
                [cell.contentView.layer setBorderWidth:1.0f];
            }else{
                cell.lblCenterTitle.text=DateTitle;
                cell.backgroundColor=[UIColor whiteColor];
                [cell.contentView.layer setBorderColor:[UIColor blackColor].CGColor];
                [cell.contentView.layer setBorderWidth:1.0f];
            }
            return cell;

        }else{
            
            if (indexPath.row >= arySelectMedicationReport.count+3)
            {
                if(indexPath.row == arySelectMedicationReport.count+3 || indexPath.row == arySelectMedicationReport.count+9)
                {
                    cell.backgroundColor=[UIColor clearColor];
                }else{
                    cell.backgroundColor=[UIColor whiteColor];
                }
                cell.txtDate.hidden=YES;
                cell.txtScheduledTime.hidden=YES;
                cell.txtActualTime.hidden=YES;
                cell.txtTimeDifference.hidden=YES;
                cell.lblEndTitle.hidden=NO;
                cell.lblFrontTitle.hidden=NO;
                cell.lblCenterTitle.hidden=YES;
                
            }else
            {
                cell.txtDate.hidden=NO;
                cell.txtScheduledTime.hidden=NO;
                cell.txtActualTime.hidden=NO;
                cell.txtTimeDifference.hidden=NO;
                cell.lblEndTitle.hidden=YES;
                cell.lblFrontTitle.hidden=YES;
                cell.lblCenterTitle.hidden=YES;

            }
            
            
                   
            if (indexPath.row == 2)
            {
                 cell.backgroundColor=[UIColor whiteColor];
                cell.txtDate.text=@"Date";
                cell.txtScheduledTime.text=@"ScheduledTime";
                cell.txtActualTime.text=@"Actual Time";
                cell.txtTimeDifference.text=@"Time Difference";
            }
            else if((indexPath.row >2) && (indexPath.row < (arySelectMedicationReport.count+3)))
            {
                cell.backgroundColor=[UIColor whiteColor];
                cell.txtDate.text=[[arySelectMedicationReport objectAtIndex:(indexPath.row-3)] valueForKey:@"MED_TAKEN_DATE"];
                cell.txtScheduledTime.text=[[arySelectMedicationReport objectAtIndex:(indexPath.row-3)] valueForKey:@"MED_SCHEDULE_TIME"];
                cell.txtActualTime.text=[[arySelectMedicationReport objectAtIndex:(indexPath.row-3)] valueForKey:@"MED_TAKEN_TIME"];
                cell.txtTimeDifference.text=[[arySelectMedicationReport objectAtIndex:(indexPath.row-3)] valueForKey:@"MED_TIME_DIFF"];
            
            }else if(indexPath.row == arySelectMedicationReport.count+3)
            {
                cell.lblEndTitle.hidden=YES;
                cell.lblFrontTitle.hidden=YES;
                cell.lblCenterTitle.hidden=YES;
                [cell.contentView.layer setBorderColor:[UIColor clearColor].CGColor];
            }
            else if(indexPath.row == arySelectMedicationReport.count+4)
            {
                cell.lblEndTitle.hidden=YES;
                cell.lblFrontTitle.hidden=YES;
                cell.lblCenterTitle.hidden=NO;
                cell.lblCenterTitle.text=@"Statistics";
                [cell.contentView.layer setBorderColor:[UIColor blackColor].CGColor];
                [cell.contentView.layer setBorderWidth:1.0f];
            }
            else if(indexPath.row > arySelectMedicationReport.count+4 || indexPath.row <=arySelectMedicationReport.count+8)
            {
                [cell.contentView.layer setBorderColor:[UIColor blackColor].CGColor];
                [cell.contentView.layer setBorderWidth:1.0f];
                
                if (indexPath.row == arySelectMedicationReport.count+5) {
                   cell.lblFrontTitle.text=@"Days In Time Frame:";
                    cell.lblEndTitle.text=daysInFrame;
                }else if (indexPath.row == arySelectMedicationReport.count+6)
                {
                    cell.lblFrontTitle.text=@"Days Compliant (within 1 Hour):";
                    cell.lblEndTitle.text=[NSString stringWithFormat:@"%d",DaysComplaint];
                }else if (indexPath.row == arySelectMedicationReport.count+7)
                {
                    cell.lblFrontTitle.text=@"Days non Compliant:";
                    cell.lblEndTitle.text=[NSString stringWithFormat:@"%d",DaysNonComplaint];
                }
                else if (indexPath.row == arySelectMedicationReport.count+8)
                {
                    cell.lblFrontTitle.text=@"Days missed:";
                    cell.lblEndTitle.text=[NSString stringWithFormat:@"%d",DaysMissed];
                }else if (indexPath.row == arySelectMedicationReport.count+9)
                {
                    cell.lblEndTitle.hidden=YES;
                    cell.lblFrontTitle.hidden=YES;
                    cell.lblCenterTitle.hidden=YES;
                    [cell.contentView.layer setBorderColor:[UIColor clearColor].CGColor];
                }
                else if (indexPath.row == arySelectMedicationReport.count+10)
                {
                    cell.lblEndTitle.hidden=YES;
                    cell.lblFrontTitle.text=@"When Non Compitant:";
                }
                else if (indexPath.row == arySelectMedicationReport.count+11)
                {
                    cell.lblFrontTitle.text=@"Average time when med Taken early:";
                    cell.lblEndTitle.text=strAvgMedtakenEarly;
                }
                else if (indexPath.row == arySelectMedicationReport.count+12)
                {
                    cell.lblFrontTitle.text=@"Average time when med Taken Late:";
                    cell.lblEndTitle.text= strAvgMedtakenLate;
                }
              
            }
              return cell;
               }
          return cell;
    }else if(tv.tag == 1)
    {
        static NSString *CellIdentifier = @"MedicationReportSingleColTVC";
        MedicationReportSingleColTVC *cell = (MedicationReportSingleColTVC *)[_tblViewMedicationReportType dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil)
        {
            NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"MedicationReportSingleColTVC" owner:self options:nil];
            cell = [nib objectAtIndex:0];
            cell.selectionStyle= UITableViewCellSelectionStyleNone;
        }
        cell.lblTitle.text=[arySelectMedicationReportType objectAtIndex:indexPath.row];
        NSString *type=[arySelectMedicationReportType objectAtIndex:indexPath.row];
        
        NSString *MedicationType=UDGetObject(@"MedicationType");
        if ([type isEqualToString:MedicationType]) {
            cell.accessoryType = UITableViewCellAccessoryCheckmark;
        }else{
            cell.accessoryType = UITableViewCellAccessoryNone;
        }

        
        
        return cell;
    }
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.row == arySelectMedicationReport.count+9)
    {
        return 10;
    }
    
    return 30;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView.tag == 0) {
        
    }else if (tableView.tag == 1)
    {
      if(arySelectMedicationReport.count==0)
      {
          _tblViewMedicationReportType.hidden=YES;
          [appDelegate.window makeToast:@"No Medication Report" duration:1.0 position:@"center"];

      }else{

        _tblViewMedicationReportType.hidden=YES;
        NSString *strSelectedType=[arySelectMedicationReportType objectAtIndex:indexPath.row];
        [_btnSelectMedicationType setTitle:strSelectedType forState:UIControlStateNormal];
        NSMutableArray *aryMedType=[[NSMutableArray alloc]init];
        aryMedType=[dbh selectMedicationReport];
          UDSetObject(strSelectedType, @"MedicationType");
        if ([strSelectedType isEqualToString:@"Past 30 Days"])
        {
            if (aryMedType.count>=30)
            {
                arySelectMedicationReport=[[NSMutableArray alloc]init];
                arySelectMedicationReport= [NSMutableArray arrayWithArray:[aryMedType subarrayWithRange:NSMakeRange(aryMedType.count-30,30)]];
            }
            else
            {
                arySelectMedicationReport=[[NSMutableArray alloc]init];
                arySelectMedicationReport=[NSMutableArray arrayWithArray:aryMedType];
            }
        }else if ([strSelectedType isEqualToString:@"Past 60 Days"])
        {
            if (aryMedType.count>=60)
            {
                arySelectMedicationReport=[[NSMutableArray alloc]init];
                arySelectMedicationReport= [NSMutableArray arrayWithArray:[aryMedType subarrayWithRange:NSMakeRange(aryMedType.count-60,60)]];
            }
            else
            {
                arySelectMedicationReport=[[NSMutableArray alloc]init];
                arySelectMedicationReport=[NSMutableArray arrayWithArray:aryMedType];
            }

        }else if ([strSelectedType isEqualToString:@"Past 90 Days"])
        {
            if (aryMedType.count>=90)
            {
                arySelectMedicationReport=[[NSMutableArray alloc]init];
                arySelectMedicationReport= [NSMutableArray arrayWithArray:[aryMedType subarrayWithRange:NSMakeRange(aryMedType.count-90,90)]];
            }
            else
            {
                arySelectMedicationReport=[[NSMutableArray alloc]init];
                arySelectMedicationReport=[NSMutableArray arrayWithArray:aryMedType];
            }
        }else if ([strSelectedType isEqualToString:@"Other"])
        {
            arySelectMedicationReport=[[NSMutableArray alloc]init];
            arySelectMedicationReport=[NSMutableArray arrayWithArray:aryMedType];
        }
           [self updateData];
           [_tblViewMedicationReport reloadData];
           [_tblViewMedicationReport reloadData];
  
    }
    }
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}



- (IBAction)onbtnBack:(id)sender {
    
    [self.navigationController popViewControllerAnimated:YES];
    
}

-(void)updateData
{
    avgMedTAkenEarly=0;
    avgMedTAkenLate=0;
    avgMin=0;
    avgMinLate=0;
    DaysComplaint=0;
    DaysNonComplaint=0;
    DaysMissed=0;

    
    if (arySelectMedicationReport)
    {
        daysInFrame =[NSString stringWithFormat:@"%lu",(unsigned long)arySelectMedicationReport.count];
        startDate =[[arySelectMedicationReport objectAtIndex:0] valueForKey:@"MED_TAKEN_DATE"];
        endDate =[[arySelectMedicationReport objectAtIndex:(arySelectMedicationReport.count-1)] valueForKey:@"MED_TAKEN_DATE"];
    }
    
    
    DateTitle=[[startDate stringByAppendingString:@" To "]stringByAppendingString:endDate];
    
    
    for (int i=0; i<arySelectMedicationReport.count; i++) {
        NSString *strDaysComplaint=[[arySelectMedicationReport objectAtIndex:i] valueForKey:@"MED_TIME_DIFF"];
        if (![strDaysComplaint isEqualToString:@"-"])
        {
            NSString *minus=[strDaysComplaint substringToIndex:1];
            NSString *strHour=[[NSString alloc]init];
            NSString *strMin=[[NSString alloc]init];;
            
            if ([minus isEqualToString:@"-"])
            {
                strHour=[strDaysComplaint substringWithRange:NSMakeRange(1,2)];
                strMin=[strDaysComplaint substringFromIndex:4];
                int hr=[strHour intValue];
                int mn=[strMin intValue];
                avgMedTAkenLate=avgMedTAkenLate+hr;
                avgMinLate=avgMinLate+mn;
                
                if (avgMinLate == 60) {
                    avgMedTAkenEarly=avgMedTAkenEarly+1;
                    avgMinLate=0;
                }
                
            }else
            {
                strHour=[strDaysComplaint substringWithRange:NSMakeRange(0,2)];
                strMin =[strDaysComplaint substringFromIndex:3];
                int hr=[strHour intValue];
                int mn=[strMin intValue];
                avgMedTAkenEarly=avgMedTAkenEarly+hr;
                avgMin=avgMin+mn;
                
                if (avgMin == 60) {
                    avgMedTAkenEarly=avgMedTAkenEarly+1;
                    avgMin=0;
                }
            }
            
            
            
            int hour=[strHour intValue];
            int min =[strMin intValue];
            if (hour == 1)
            {
                if (min == 0)
                {
                    DaysComplaint+=1;
                }
            }else if(hour < 1)
            {
                DaysComplaint+=1;
            }else if(hour > 1)
            {
                DaysNonComplaint+=1;
            }
        }else{
            DaysMissed+=1;
        }
    }
    
    int toatldays=arySelectMedicationReport.count-DaysMissed;
    
    avgMin=avgMin/toatldays;
    avgMinLate=avgMinLate/toatldays;
    
    avgMedTAkenEarly=avgMedTAkenEarly/toatldays;
    avgMedTAkenLate=avgMedTAkenLate/toatldays;
    
    
    
    strAvgMedtakenEarly=[NSString stringWithFormat:@"%d Hours %d min",(int)avgMedTAkenEarly,(int)avgMin];
    strAvgMedtakenLate=[NSString stringWithFormat:@"%d hours %d min",(int)avgMedTAkenLate,(int)avgMinLate];
}


- (IBAction)onbtnSelectMedicationType:(id)sender {
    _tblViewMedicationReportType.hidden=NO;
}
@end
