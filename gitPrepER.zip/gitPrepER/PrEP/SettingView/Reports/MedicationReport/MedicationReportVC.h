//
//  MedicationReportVC.h
//  PrEP
//
//  Created by pradip.r on 10/23/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MedicationReportVC : UIViewController<UITableViewDataSource,UITableViewDelegate>
@property (weak, nonatomic) IBOutlet UIButton *onbtnBack;
- (IBAction)onbtnBack:(id)sender;
@property (weak, nonatomic) IBOutlet UITableView *tblViewMedicationReport;
@property (weak, nonatomic) IBOutlet UITableView *tblViewMedicationReportType;
- (IBAction)onbtnSelectMedicationType:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *btnSelectMedicationType;

@end
