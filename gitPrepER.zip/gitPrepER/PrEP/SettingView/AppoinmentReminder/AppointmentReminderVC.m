//
//  AppointmentReminderVC.m
//  PrEP
//
//  Created by pradip.r on 10/14/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import "AppointmentReminderVC.h"
#import "DataBase.h"
#import "AddApoinmentCell.h"
#import "Constant.h"
@interface AppointmentReminderVC ()
{
    NSMutableArray *addApoinmentTitleArray;
    DataBase *dbh;
}
@end

@implementation AppointmentReminderVC

- (void)viewDidLoad {
    @try{
    [super viewDidLoad];
    
    _btnSelectTime.layer.shadowOpacity=0.5;
    _btnSelectTime.layer.shadowRadius=0.5;
    _btnSelectTime.layer.cornerRadius=0.5;

    
       
    dbh=[[DataBase alloc]init];
      addApoinmentTitleArray=[[NSMutableArray alloc] initWithObjects:@"15 minutes",@"30 minutes",@"1 hour",@"2 hours",@"1 day",@"2 days",@"3 days", nil];
    _tblView.hidden=YES;
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}

-(void)viewWillAppear:(BOOL)animated
{
    [_tblView reloadData];
    NSString *appointType=UDGetObject(@"appointType");
    [_btnSelectTime setTitle:appointType forState:UIControlStateNormal];
    [_tblView reloadData];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1 ;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [addApoinmentTitleArray count];
}

- (UITableViewCell *)tableView:(UITableView *)tv cellForRowAtIndexPath:(NSIndexPath*)indexPath {
    @try{
    static NSString *CellIdentifier = @"celll";
    AddApoinmentCell *cell = [_tblView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    // NOTE: Add some code like this to create a new cell if there are none to reuse
    if(cell == nil)
    {
        cell = [[AddApoinmentCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        
    }
    
    NSString *string = [addApoinmentTitleArray objectAtIndex:indexPath.row];
    
    cell.textLabel.text = string;
    
    NSString *appointType=UDGetObject(@"appointType");
    if ([cell.textLabel.text isEqualToString:appointType]) {
        cell.accessoryType = UITableViewCellAccessoryCheckmark;
    }else{
         cell.accessoryType = UITableViewCellAccessoryNone;
    }
    
    
    return cell;
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *strSelected = [addApoinmentTitleArray objectAtIndex:indexPath.row];
   [_btnSelectTime setTitle:strSelected forState:UIControlStateNormal];
    _tblView.hidden=YES;
    UDSetObject(strSelected, @"appointType");
    
}

-(void)UpdateNotification:(int)timeInterVal
{
    [[UIApplication sharedApplication] cancelAllLocalNotifications];
    
    NSDateFormatter *formatter=[[NSDateFormatter alloc]init];
   NSMutableArray *aryAppointment= [dbh AppointmentSelect_upcomming];
     NSMutableArray *AllUser=[dbh selectAllUser];
   
    for (int i=0; i <AllUser.count; i++)
    {
        NSString *strDate=[[AllUser objectAtIndex:i] valueForKey:@"STARTDATE"];
        NSString *strTime=[[AllUser  objectAtIndex:i] valueForKey:@"PILLTIME"];
        [formatter setDateFormat:@"MM-dd-yy"];
        NSDate *date=[formatter dateFromString:strDate];
        [formatter setDateFormat:@"dd-MM-yyyy"];
        strDate=[formatter stringFromDate:date];
        strDate =[strDate stringByAppendingString:@" "];
        strDate=[strDate stringByAppendingString:strTime];
        [formatter setDateFormat:@"dd-MM-yyyy hh:mm a"];
        NSDate *appointDate=[formatter dateFromString:strDate];
        [self enableNotification:appointDate alertBody:@"Please Take Your Medicine"];
    }
    
    
 //   NSDate *newDate30 = [dateFromString dateByAddingTimeInterval:-timeInterVal];
    for (int i=0; i <aryAppointment.count; i++)
    {
        NSString *strDate=[[aryAppointment objectAtIndex:i] valueForKey:@"DATE"];
        NSString *strTime=[[aryAppointment objectAtIndex:i] valueForKey:@"TIME"];
        NSString *strTitle=[[aryAppointment objectAtIndex:i] valueForKey:@"TITLE"];
        NSString *strIsConform=[[aryAppointment objectAtIndex:i] valueForKey:@"ISCONFORM"];
        
        if ([strIsConform isEqualToString:@"1"])
        {
            [formatter setDateFormat:@"MM-dd-yy"];
            NSDate *date=[formatter dateFromString:strDate];
            [formatter setDateFormat:@"dd-MM-yyyy"];
            strDate=[formatter stringFromDate:date];
            strDate =[strDate stringByAppendingString:@" "];
            strDate=[strDate stringByAppendingString:strTime];
            [formatter setDateFormat:@"dd-MM-yyyy hh:mm a"];
            NSDate *appointDate=[formatter dateFromString:strDate];
            NSDate *appointReminder=[appointDate dateByAddingTimeInterval:-timeInterVal];
            [self enableNotification:appointReminder alertBody:strTitle];
        }else
        {
            if ([strTitle isEqualToString:@"1 Month Visit"])
            {
                [formatter setDateFormat:@"MM-dd-yy"];
                NSDate *date=[formatter dateFromString:strDate];
                [formatter setDateFormat:@"dd-MM-yyyy"];
                strDate=[formatter stringFromDate:date];
                strDate =[strDate stringByAppendingString:@" "];
                strDate=[strDate stringByAppendingString:strTime];
                [formatter setDateFormat:@"dd-MM-yyyy hh:mm a"];
                NSDate *appointDate=[formatter dateFromString:strDate];
                NSDate *appointReminder=[appointDate dateByAddingTimeInterval:-timeInterVal];
                [self enableNotification:appointReminder alertBody:strTitle];
                 UDSetObject(appointReminder,@"1monthVisit");
                
            }
            else if ([strTitle isEqualToString:@"3 Month Visit"])
            {
                [formatter setDateFormat:@"MM-dd-yy"];
                NSDate *date=[formatter dateFromString:strDate];
                [formatter setDateFormat:@"dd-MM-yyyy"];
                strDate=[formatter stringFromDate:date];
                strDate =[strDate stringByAppendingString:@" "];
                strDate=[strDate stringByAppendingString:strTime];
                [formatter setDateFormat:@"dd-MM-yyyy hh:mm a"];
                NSDate *appointDate=[formatter dateFromString:strDate];
                NSDate *appointReminder=[appointDate dateByAddingTimeInterval:-timeInterVal];
                [self enableNotification:appointReminder alertBody:strTitle];
                 UDSetObject(appointReminder,@"3monthVisit");
            }
            else if ([strTitle isEqualToString:@"6 Month Visit"])
            {
                [formatter setDateFormat:@"MM-dd-yy"];
                NSDate *date=[formatter dateFromString:strDate];
                [formatter setDateFormat:@"dd-MM-yyyy"];
                strDate=[formatter stringFromDate:date];
                strDate =[strDate stringByAppendingString:@" "];
                strDate=[strDate stringByAppendingString:strTime];
                [formatter setDateFormat:@"dd-MM-yyyy hh:mm a"];
                NSDate *appointDate=[formatter dateFromString:strDate];
                NSDate *appointReminder=[appointDate dateByAddingTimeInterval:-timeInterVal];
                [self enableNotification:appointReminder alertBody:strTitle];
                 UDSetObject(appointReminder,@"6monthVisit");
            }

        }
        
    }
    
}



- (IBAction)onbtnAction:(id)sender
{
    @try{
    NSString *strSelected = _btnSelectTime.titleLabel.text;
    if ([strSelected isEqualToString:@"15 minutes"])
    {
        int timeInterval=60*15;
        [self UpdateNotification:timeInterval];
    }else if ([strSelected isEqualToString:@"30 minutes"])
    {
        int timeInterval=60*30;
        [self UpdateNotification:timeInterval];
        
    }else if ([strSelected isEqualToString:@"1 hour"])
    {
        int timeInterval=60*60;
        [self UpdateNotification:timeInterval];
        
    }else if ([strSelected isEqualToString:@"2 hours"])
    {
        int timeInterval=60*60*2;
        [self UpdateNotification:timeInterval];
        
    }else if ([strSelected isEqualToString:@"1 day"])
    {
        int timeInterval=60*60*24;
        [self UpdateNotification:timeInterval];
    }else if ([strSelected isEqualToString:@"2 days"])
    {
        int timeInterval=60*60*24*2;
        [self UpdateNotification:timeInterval];
    }else if ([strSelected isEqualToString:@"3 days"])
    {
        int timeInterval=60*60*24*3;
        [self UpdateNotification:timeInterval];
    }

    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert" message:@"Your Appointment reminder has been set" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
    [alert show];

    
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}

- (IBAction)onbtnSelectTime:(id)sender {
       _tblView.hidden=NO;
    [_tblView reloadData];

}

- (IBAction)onbtnBack:(id)sender {
     [self.navigationController popViewControllerAnimated:YES];
}


-(void)enableNotification:(NSDate *)date alertBody:(NSString *)title
{
    UILocalNotification* localNotification = [[UILocalNotification alloc] init];
    localNotification.fireDate = date;
    localNotification.alertBody = title;
    localNotification.soundName=UILocalNotificationDefaultSoundName;
    [[UIApplication sharedApplication] scheduleLocalNotification:localNotification];
    NSLog(@"%@",localNotification);
}



- (IBAction)noti_tab_button_action:(id)sender
{
    @try{
        int index = 0;
        for (UIViewController *vc in self.navigationController.viewControllers) {
            if ([vc isKindOfClass:[NotificationViewController class]]) {
                [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:index] animated:NO];
            }
            index++;
        }
        NotificationViewController *objNotificationViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"NotificationViewController"];
        
        
        [self.navigationController pushViewController:objNotificationViewController animated:NO];
        
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}

- (IBAction)task_tab_button_action:(id)sender

{@try{
    int index = 0;
    for (UIViewController *vc in self.navigationController.viewControllers) {
        if ([vc isKindOfClass:[AppointmentViewController class]]) {
            [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:index] animated:NO];
        }
        index++;
    }
    AppointmentViewController *objAppointmentViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"AppointmentViewController"];
    [self.navigationController pushViewController:objAppointmentViewController animated:NO];
}  @catch(NSException *exception){
    NSLog(@"%@",exception.description);
}
    
}


- (IBAction)cal_tab_button_action:(id)sender
{@try{
    int index = 0;
    for (UIViewController *vc in self.navigationController.viewControllers) {
        if ([vc isKindOfClass:[CalViewController class]]) {
            [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:index] animated:NO];
        }
        index++;
    }
    CalViewController *objCalViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"CalViewController"];
    [self.navigationController pushViewController:objCalViewController animated:NO];
}  @catch(NSException *exception){
    NSLog(@"%@",exception.description);
}
    
}

- (IBAction)setting_tab_button_action:(id)sender
{@try{
    //    int index = 0;
    //    for (UIViewController *vc in self.navigationController.viewControllers) {
    //        if ([vc isKindOfClass:[SettingViewController class]]) {
    //            [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:index] animated:NO];
    //        }
    //        index++;
    //    }
    SettingViewController *objSettingViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"SettingViewController"];
    [self.navigationController pushViewController:objSettingViewController animated:NO];
}  @catch(NSException *exception){
    NSLog(@"%@",exception.description);
}
    
}


- (IBAction)dash_tab_button_action:(id)sender
{
DashBoardViewController *objDashBoardViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"DashBoardViewController"];

[self.navigationController pushViewController:objDashBoardViewController animated:YES];
}
@end
