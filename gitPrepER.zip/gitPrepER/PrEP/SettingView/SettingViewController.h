//
//  SettingViewController.h
//  PrEP
//
//  Created by Bhushan on 5/15/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import "ViewController.h"
#import "AppDelegate.h"
#import "UIButton+StyledButton.h"
#import"DataBase.h"
@interface SettingViewController : ViewController<UITextFieldDelegate>
{
    AppDelegate *AppDel;
    NSString *DateStr,*PinNewStr,*titleStr;
    DataBase *dbs;
    NSString *nameStr;
    NSString *Pill_TIME,*PillCountStr;
 
    
}
@property (strong, nonatomic) IBOutlet UIButton *btnMedTkn;
@property (strong, nonatomic) IBOutlet UIButton *btnHiv;
@property (strong, nonatomic) IBOutlet UIButton *btnCompletedAppiont;
@property (strong, nonatomic) IBOutlet UIButton *btnOverdue;
@property (strong, nonatomic) IBOutlet UIButton *btnSaveUpdateDate;
@property (copy) NSDate *date4;
@property (strong, nonatomic) IBOutlet UIButton *update_pill_button;
@property (strong, nonatomic) IBOutlet UIButton *medicine_reminders_button;
@property (strong, nonatomic) IBOutlet UIButton *task_reminder_button;
@property (strong, nonatomic) IBOutlet UIButton *btnSaveUpdatePin;

@property (strong, nonatomic) IBOutlet UIButton *appointment_rem_button;

@property (strong, nonatomic) IBOutlet UIButton *update_date_button;

@property (strong, nonatomic) IBOutlet UIButton *pill_setting_button;

@property (strong, nonatomic) IBOutlet UITextField *pin_enter_old_pin;
@property (weak, nonatomic) IBOutlet UIButton *updatePinButton;

@property (strong, nonatomic) IBOutlet UITextField *pin_enter_new_pin_text;

@property (strong, nonatomic) IBOutlet UITextField *Pin_enter_old_pin_text;

@property (strong, nonatomic) IBOutlet UIButton *pin_save;


@property (weak, nonatomic) IBOutlet UIView *pinView;

@property (strong, nonatomic) IBOutlet UIView *edit_date_view;

@property (strong, nonatomic) IBOutlet UITextField *enter_date_text;

@property (strong, nonatomic)IBOutlet UIDatePicker *date_pickview;

@property (strong, nonatomic) IBOutlet UIButton *reports_button;


@property (strong, nonatomic) IBOutlet UIButton *rep_ove_app_button;


@property (strong, nonatomic) IBOutlet UIButton *rep_com_app_button;

@property (strong, nonatomic) IBOutlet UIButton *rep_hiv_button;

@property (strong, nonatomic) IBOutlet UIButton *rep_med_button;

@property (strong, nonatomic) IBOutlet UIView *report_view;


- (IBAction)btnDoneDate:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *outSave;

@property (weak, nonatomic) IBOutlet UIButton *outlateBtnUpdatePin;
@property (weak, nonatomic) IBOutlet UIButton *outBtnReport;

- (IBAction)btnDateCancel:(id)sender;


@property (weak, nonatomic) IBOutlet UIButton *outBtnUpdateStartDate;

//- (IBAction)date_cancel_action:(id)send;

- (IBAction)date_done_button_action:(id)sender;

- (IBAction)pin_back_button_action:(id)sender;

- (IBAction)pin_save_button:(id)sender;

- (IBAction)dash_tab_button_action:(id)sender;

- (IBAction)noti_tab_button_action:(id)sender;

- (IBAction)task_tab_button_action:(id)sender;

- (IBAction)cal_tab_button_action:(id)sender;

- (IBAction)back_button_action:(id)sender;

- (IBAction)report_back_button_action:(id)sender;



- (IBAction)update_pin_button_action:(id)sender;

- (IBAction)medicine_rem_button_action:(id)sender;

- (IBAction)task_rem_button_action:(id)sender;

- (IBAction)app_rem_button_action:(id)sender;

- (IBAction)update_strate_button_action:(id)sender;

- (IBAction)pill_button_action:(id)sender;

- (IBAction)save_edit_button_action:(id)sender;

- (IBAction)edit_back_button_action:(id)sender;

- (IBAction)reports_button_action:(id)sender;

-(IBAction)update_date_back_button:(id)sender;


@property (strong, nonatomic) IBOutlet UIView *update_date_editdate_view;
@property (weak, nonatomic) IBOutlet UITextField *update_date_textfield;

-(IBAction)update_date_editdate_view_donebutton:(id)sender;
-(IBAction)update_date_editdate_view_cancel:(id)sender;
-(IBAction)update_date_textfieldbutton_action:(id)sender;

@property (strong, nonatomic) IBOutlet UIView *report_overdue_view;

@property (strong, nonatomic) IBOutlet UIView *report_completed_view;

@property (strong, nonatomic) IBOutlet UIView *report_hiv_tests_view;

@property (strong, nonatomic) IBOutlet UIView *report_medication_view;

-(IBAction)overdue_appointment_button_action:(id)sender;

-(IBAction)completed_appointment_button_action:(id)sender;

-(IBAction)hiv_tests_completed_button_action:(id)sender;

-(IBAction)medication_taken_button_action:(id)sender;


-(IBAction)overdue_appointment_back_button_action:(id)sender;

-(IBAction)completed_appointment_back_button_action:(id)sender;

-(IBAction)hiv_tests_completed_back_button_action:(id)sender;

-(IBAction)medication_taken_back_button_action:(id)sender;


@property (weak, nonatomic) IBOutlet UIView *medicine_reminder_view;

- (IBAction)medicine_to_back:(id)sender;
@property (weak, nonatomic) IBOutlet UITextField *set_hour_medicine_reminder_textfield;
- (IBAction)medicine_reminder_save_action:(id)sender;

@property (weak, nonatomic) IBOutlet UIView *viewReminderApoinment;
- (IBAction)btnAppoinmentReminderBack:(id)sender;
@property (weak, nonatomic) IBOutlet UIView *viewDatePicker;



@end
