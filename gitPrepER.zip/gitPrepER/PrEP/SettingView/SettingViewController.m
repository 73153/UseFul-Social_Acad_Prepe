//
//  SettingViewController.m
//  PrEP
//
//  Created by Bhushan on 5/15/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import "SettingViewController.h"
#import "DashBoardViewController.h"
#import "NotificationViewController.h"
#import "AppointmentViewController.h"
#import "CalViewController.h"
#import "DataBase.h"
#import "SteupViewController.h"
#import "Constant.h"
#import "AppointmentReminderVC.h"
#define MAX_LENGTH 4
#import "MedicationReportVC.h"
#import "AppointmentReportVC.h"

@interface SettingViewController ()
{
    DataBase *dbh;
    NSMutableArray *UserArray;
    NSDate *date5;
    NSDateFormatter *dateFormatter;

}

@end

@implementation SettingViewController
{
    NSDate *date1;
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    @try{
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
   
    dbh=[[DataBase alloc]init];
    
        [self setDateLimit];
    
    
    [_update_pill_button initWithBorders];
    
    [_update_pill_button initWithBorders];
    [_update_pill_button initWithBorders];
    [_medicine_reminders_button initWithBorders];
    [_outBtnReport initWithBorders];
    [_outBtnUpdateStartDate initWithBorders];
    [_outlateBtnUpdatePin initWithBorders];
    

    [_task_reminder_button initWithBorders];
    [_appointment_rem_button initWithBorders];
    
    [_update_date_button initWithBorders];
    
    [_update_date_button initWithBorders];
    
    [_pill_setting_button initWithBorders];
    
    [_reports_button initWithBorders];
    [_outSave initWithBorders];
    [_btnSaveUpdatePin initWithBorders];
    [_btnSaveUpdateDate initWithBorders];
    [_btnMedTkn initWithBorders];
    [_btnHiv initWithBorders];
    [_btnCompletedAppiont initWithBorders];
    [_btnOverdue initWithBorders];
    //report view....
    
    [_rep_ove_app_button initWithBorders];
    [_rep_com_app_button initWithBorders];
    [_rep_hiv_button initWithBorders];
    [_rep_med_button initWithBorders];
    
    
    
    UserArray=[[NSMutableArray alloc]init];
    
    UserArray=[dbh selectAllUser];
    
    
    [self.edit_date_view setHidden:YES];
    [self.report_view setHidden:YES];
    [self.pinView setHidden:YES];
    [self.update_date_editdate_view setHidden:YES];
   // [self.date_pickview setHidden:YES];
    
    [_report_overdue_view setHidden:YES];
    [_report_completed_view setHidden:YES];
    [_report_hiv_tests_view setHidden:YES];
    [_report_medication_view setHidden:YES];
    [_medicine_reminder_view setHidden:YES];
    [_viewReminderApoinment setHidden:YES];
    
    
    if ([UserArray count]>0)
    {
        
        DateStr=[[UserArray objectAtIndex:0] objectForKey:@"STARTDATE"];
        
        PinNewStr=[[UserArray objectAtIndex:0] objectForKey:@"PIN"];
        
        titleStr=[[UserArray objectAtIndex:0] objectForKey:@"NAME"];
        
        Pill_TIME=[[UserArray objectAtIndex:0] objectForKey:@"PILLTIME"];
        
        PillCountStr=[[UserArray objectAtIndex:0] objectForKey:@"PILLCOUNT"];
        
        _enter_date_text.text=DateStr;
        
    }
    _set_hour_medicine_reminder_textfield.delegate=self;
   
    
    
    // adding number pad to textfield ...
    _update_date_textfield.layer.cornerRadius=2.0f;
    _update_date_textfield.layer.masksToBounds=YES;
    _update_date_textfield.layer.borderColor=[[UIColor grayColor]CGColor];
    _update_date_textfield.layer.borderWidth= 2.5f;
    _update_date_textfield.backgroundColor=[UIColor clearColor];
    
    _pin_enter_new_pin_text.layer.cornerRadius=2.0f;
    _pin_enter_new_pin_text.layer.masksToBounds=YES;
    _pin_enter_new_pin_text.layer.borderColor=[[UIColor grayColor]CGColor];
    _pin_enter_new_pin_text.layer.borderWidth= 2.5f;
    _pin_enter_new_pin_text.backgroundColor=[UIColor clearColor];
    
    _Pin_enter_old_pin_text.layer.cornerRadius=2.0f;
    _Pin_enter_old_pin_text.layer.masksToBounds=YES;
    _Pin_enter_old_pin_text.layer.borderColor=[[UIColor grayColor]CGColor];
    _Pin_enter_old_pin_text.layer.borderWidth= 2.5f;
    _Pin_enter_old_pin_text.backgroundColor=[UIColor clearColor];

    
    
    _set_hour_medicine_reminder_textfield.layer.cornerRadius=2.0f;
    _set_hour_medicine_reminder_textfield.layer.masksToBounds=YES;
    _set_hour_medicine_reminder_textfield.layer.borderColor=[[UIColor grayColor]CGColor];
    _set_hour_medicine_reminder_textfield.layer.borderWidth= 2.5f;
    _set_hour_medicine_reminder_textfield.backgroundColor=[UIColor clearColor];


    UIToolbar* numberToolbar = [[UIToolbar alloc]initWithFrame:CGRectMake(0, 0, 320, 50)];
    numberToolbar.items = [NSArray arrayWithObjects:
                           [[UIBarButtonItem alloc]initWithTitle:@"Cancel" style:UIBarButtonItemStyleBordered target:self action:@selector(cancelNumberPad)],
                           [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil],
                           [[UIBarButtonItem alloc]initWithTitle:@"Apply" style:UIBarButtonItemStyleDone target:self action:@selector(doneWithNumberPad)],
                           nil];
    [numberToolbar sizeToFit];
    UIToolbar* numberToolbar2 = [[UIToolbar alloc]initWithFrame:CGRectMake(0, 0, 320, 50)];
    numberToolbar2.items = [NSArray arrayWithObjects:
                           [[UIBarButtonItem alloc]initWithTitle:@"Cancel" style:UIBarButtonItemStyleBordered target:self action:@selector(cancelNumberPad)],
                           [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil],
                           [[UIBarButtonItem alloc]initWithTitle:@"Apply" style:UIBarButtonItemStyleDone target:self action:@selector(doneWithNumberPad1)],
                           nil];
    [numberToolbar2 sizeToFit];
    UIToolbar* numberToolbar3 = [[UIToolbar alloc]initWithFrame:CGRectMake(0, 0, 320, 50)];
    numberToolbar3.items = [NSArray arrayWithObjects:
                            [[UIBarButtonItem alloc]initWithTitle:@"Cancel" style:UIBarButtonItemStyleBordered target:self action:@selector(cancelNumberPad)],
                            [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil],
                            [[UIBarButtonItem alloc]initWithTitle:@"Apply" style:UIBarButtonItemStyleDone target:self action:@selector(doneWithNumberPad2)],
                            nil];
    [numberToolbar3 sizeToFit];
    _set_hour_medicine_reminder_textfield.inputAccessoryView = numberToolbar;
    _Pin_enter_old_pin_text.inputAccessoryView = numberToolbar2;
    _pin_enter_new_pin_text.inputAccessoryView = numberToolbar3;
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]
                                   initWithTarget:self
                                   action:@selector(dismissKeyboar)];
    
    [self.medicine_reminder_view addGestureRecognizer:tap];
    
      [self.edit_date_view addGestureRecognizer:tap];
    self.update_date_textfield.delegate = self;
     self.viewDatePicker.frame = CGRectMake(0, self.view.frame.size.height, self.view.frame.size.width, 242) ;
    
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)date_done_button_action:(id)sender
{
    @try{
   /* NSDate *date = [_date_pickview date];
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    
    [dateFormat setDateFormat:@"MM-dd-yy"];
    
    _update_date_textfield.text = [dateFormat stringFromDate:[NSDate date]];
    
    NSDateFormatter *dateFormat1 = [[NSDateFormatter alloc] init];
    
    [dateFormat1 setDateFormat:@"hh:mm a"];
    [dateFormat1 setTimeZone:[NSTimeZone systemTimeZone]];
    NSString *pill_time=[dateFormat1 stringFromDate:date];
    
    [self.edit_date_view setHidden:YES];
    
//    DataBase *dbase = [[DataBase alloc]init];
//    
//    NSMutableArray *editeddata = [[NSMutableArray alloc]init];
//    
//    editeddata=[dbase selectAllUser];
//    
//    [editeddata setValue:_update_date_textfield.text forKey:@"STARTDATE"];
//    
//    [dbh UserUpdate:editeddata];
    
    UILocalNotification* localNotification = [[UILocalNotification alloc] init];
    localNotification.fireDate = [_date_pickview date];
    localNotification.alertBody = @"Please Take Your Medicine";
    localNotification.timeZone = [NSTimeZone systemTimeZone];
    [[UIApplication sharedApplication] scheduleLocalNotification:localNotification];
    
    [[NSUserDefaults standardUserDefaults]setObject:[_date_pickview date] forKey:@"Fire_Date"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    */
        
        NSString *firstPill=UDGetValue(@"firstPillTaken");
        
        if ([firstPill isEqualToString:@"firstPillTaken"]) {
            
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert" message:@"You can not Update Start Date Now" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
            [alert show];
            
        }else
        {
    [[UIApplication sharedApplication] cancelAllLocalNotifications];
    
    NSMutableDictionary *dic=[[NSMutableDictionary alloc ]init];
    
    [dic setObject:titleStr forKey:@"NAME"];
    
    [dic setObject:PinNewStr forKey:@"PIN"];
    
    
    [dic setObject:_update_date_textfield.text forKey:@"STARTDATE"];
    
    
    [dic setObject:Pill_TIME forKey:@"PILLTIME"];
    
    [dic setObject:PillCountStr forKey:@"PILLCOUNT"];
    
    NSMutableArray  *Array=[[NSMutableArray alloc]init];
    
    [Array addObject:dic];
    
      [dbh UserUpdate:Array];
    
        [self updateDate];
    
    [self disableNotification:@"Please Take Your Medicine"];
    NSDateFormatter *dateFormat1=[[NSDateFormatter alloc]init];

    NSString *dateOnly=_update_date_textfield.text;
        NSDate *date=[[NSDate alloc]init];
    [dateFormat1 setDateFormat:@"dd-MM-yyyy"];
    dateOnly=[dateFormat1 stringFromDate:date];
    dateOnly =[dateOnly stringByAppendingString:@" "];
    dateOnly =[dateOnly stringByAppendingString:Pill_TIME];
    dateFormat1=[[NSDateFormatter alloc]init];
    [dateFormat1 setDateFormat:@"dd-MM-yyyy hh:mm a"];
    NSDate *notificationDate=[dateFormat1 dateFromString:dateOnly];
    
    [self enableNotification:notificationDate alertBody:@"Please Take Your Medicine"];
    UDSetObject(notificationDate, @"Fire_Date");
    //    NSString *initialPillCount=PillCountStr;
    //    UDSetObject(initialPillCount, @"initialCount");
    UDSetObject(_update_date_textfield.text, @"lastPillTakenDate");
        UDSetObject(nil,@"dtlastPillTakenDate");
    [dbh deleteRegularPillTaken];
        [dbh deleteMedicationReport];
        NSString *MedStr=UDGetValue(@"med");
        UDSetValue(MedStr,@"initialCount");
        [dbh resetAppointments];
    
    DashBoardViewController *objDashBoardViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"DashBoardViewController"];
    
    [self.navigationController pushViewController:objDashBoardViewController animated:YES];
        }
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}

- (IBAction)pin_back_button_action:(id)sender
{
    _pinView.hidden=YES;
}

- (IBAction)pin_save_button:(id)sender
{
    @try{
    NSString *rawString = [_Pin_enter_old_pin_text text];
    NSCharacterSet *whitespace = [NSCharacterSet whitespaceAndNewlineCharacterSet];
    NSString *trimmed = [rawString stringByTrimmingCharactersInSet:whitespace];
    
    NSString *rawString1 = [_pin_enter_new_pin_text text];
    NSCharacterSet *whitespace1 = [NSCharacterSet whitespaceAndNewlineCharacterSet];
    NSString *trimmed1 = [rawString1 stringByTrimmingCharactersInSet:whitespace1];
    
    
    
    
    
    if([trimmed length] == 0)
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"PrEP" message:@"old pin is empty" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
        
        
    }else if ([trimmed1 length] == 0)
    {
        
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"PrEP" message:@"New pin is empty" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
        
    }else if ([_pin_enter_new_pin_text.text isEqual:PinNewStr])
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"PrEP" message:@"Perious and new pin number is same please enter new pin" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
    }else
    {
        
       
        
        
        NSMutableDictionary *dic=[[NSMutableDictionary alloc ]init];
        
        [dic setObject:titleStr forKey:@"NAME"];
        
        [dic setObject:_pin_enter_new_pin_text.text forKey:@"PIN"];
        
        [dic setObject:DateStr forKey:@"STARTDATE"];
        
         [dic setObject:Pill_TIME forKey:@"PILLTIME"];
        
         [dic setObject:PillCountStr forKey:@"PILLCOUNT"];
        
        NSMutableArray *Array1=[[NSMutableArray alloc]init];
        
        [Array1 addObject:dic];
        
        
        if ([Array1 count]>0)
        {
            
            [dbh UserUpdate:Array1];
            _pinView.hidden=YES;
            
        }
        
    }

    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}

- (IBAction)dash_tab_button_action:(id)sender
{
    @try{
    int index = 0;
    for (UIViewController *vc in self.navigationController.viewControllers) {
        if ([vc isKindOfClass:[DashBoardViewController class]]) {
            [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:index] animated:NO];
        }
        index++;
    }
    DashBoardViewController *objDashBoardViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"DashBoardViewController"];
    [self.navigationController pushViewController:objDashBoardViewController animated:NO];
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}

- (IBAction)noti_tab_button_action:(id)sender
{
    @try{
    int index = 0;
    for (UIViewController *vc in self.navigationController.viewControllers) {
        if ([vc isKindOfClass:[NotificationViewController class]]) {
            [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:index] animated:NO];
        }
        index++;
    }
    NotificationViewController *objNotificationViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"NotificationViewController"];
    [self.navigationController pushViewController:objNotificationViewController animated:NO];
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}

- (IBAction)task_tab_button_action:(id)sender
{
    @try{
    int index = 0;
    for (UIViewController *vc in self.navigationController.viewControllers) {
        if ([vc isKindOfClass:[AppointmentViewController class]]) {
            [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:index] animated:NO];
        }
        index++;
    }
    AppointmentViewController *objAppointmentViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"AppointmentViewController"];
    [self.navigationController pushViewController:objAppointmentViewController animated:NO];
    
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}

- (IBAction)cal_tab_button_action:(id)sender
{
    @try{
    int index = 0;
    for (UIViewController *vc in self.navigationController.viewControllers) {
        if ([vc isKindOfClass:[CalViewController class]]) {
            [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:index] animated:NO];
        }
        index++;
    }
    CalViewController *objCalViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"CalViewController"];
    [self.navigationController pushViewController:objCalViewController animated:NO];
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}


- (IBAction)back_button_action:(id)sender
{
    self.viewDatePicker.frame = CGRectMake(0, self.view.frame.size.height, self.view.frame.size.width, 242) ;
    [self.navigationController popViewControllerAnimated:YES];
}

- (IBAction)report_back_button_action:(id)sender {
    [self.report_view setHidden:YES];
}

- (IBAction)update_pin_button_action:(id)sender
{
 [_pinView setHidden:NO];
    
}

- (IBAction)medicine_rem_button_action:(id)sender
{
    
    [_medicine_reminder_view setHidden:NO];
    
}

- (IBAction)task_rem_button_action:(id)sender
{
}

- (IBAction)app_rem_button_action:(id)sender
{
    @try{
    AppointmentReminderVC *objAppointmentReminderVC=[self.storyboard instantiateViewControllerWithIdentifier:@"AppointmentReminderVC"];
    [self.navigationController pushViewController:objAppointmentReminderVC animated:NO];
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}

- (IBAction)update_strate_button_action:(id)sender
{
    @try{
    _edit_date_view.hidden=NO;
    
    UserArray=[dbh selectAllUser];
    
    if ([UserArray count]>0)
    {
        
        _update_date_textfield.text=[NSString stringWithFormat:@"%@",[[UserArray objectAtIndex:0] objectForKey:@"STARTDATE"]] ;
        
    }
    
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}

- (IBAction)pill_button_action:(id)sender
{
    
    
    _pinView.hidden=NO;
}

- (IBAction)save_edit_button_action:(id)sender
{
    
      if ([_enter_date_text.text isEqualToString:DateStr])
    {
          UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"PrEP" message:@"Perious and current date is same Please 'Choose different one'" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
        [alert show];
        
    }else
    {
        
        NSMutableDictionary *dic=[[NSMutableDictionary alloc ]init];
        
        [dic setObject:titleStr forKey:@"NAME"];
        
        [dic setObject:PinNewStr forKey:@"PIN"];
        
        [dic setObject:_enter_date_text.text forKey:@"STARTDATE"];
        
        
        
        NSMutableArray  *Array=[[NSMutableArray alloc]init];
        
        [Array addObject:dic];
        
        
        if ([Array count]>0)
        {
            
            [dbh UserUpdate:Array];
            _edit_date_view.hidden=YES;
            
        }
    }
  
    
}

- (IBAction)edit_back_button_action:(id)sender
{
    
    _edit_date_view.hidden=YES;
}

- (IBAction)reports_button_action:(id)sender
{
    [self.report_view setHidden:NO];
}

-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    if (textField.tag == 101 || textField.tag == 102) {
        
        if (textField.text.length >= MAX_LENGTH && range.length == 0)
        {
            return NO; // return NO to not change text
        }
        
        /* for backspace */
        if([string length]==0)
        {
            return YES;
        }
        
        /*  limit to only numeric characters  */
        
        NSCharacterSet *myCharSet = [NSCharacterSet characterSetWithCharactersInString:@"0123456789"];
        for (int i = 0; i < [string length]; i++) {
            unichar c = [string characterAtIndex:i];
            if ([myCharSet characterIsMember:c]) {
                return YES;
            }
        }
        
        return NO;
    }
    
    if (textField.tag == 1)
    {
        
        
        /* for backspace */
        if([string length]==0)
        {
            return YES;
        }
        
        /*  limit to only numeric characters  */
        
        NSCharacterSet *myCharSet = [NSCharacterSet characterSetWithCharactersInString:@"0123456789"];
        for (int i = 0; i < [string length]; i++) {
            unichar c = [string characterAtIndex:i];
            if ([myCharSet characterIsMember:c]) {
                return YES;
            }
        }
        
        return NO;
    } else if (textField.tag == 2)
    {
        
        
        /* for backspace */
        if([string length]==0)
        {
            return YES;
        }
        
        /*  limit to only numeric characters  */
        
        NSCharacterSet *myCharSet = [NSCharacterSet characterSetWithCharactersInString:@"0123456789"];
        for (int i = 0; i < [string length]; i++) {
            unichar c = [string characterAtIndex:i];
            if ([myCharSet characterIsMember:c]) {
                return YES;
            }
        }
        
        return NO;
    }
    else
        
        return YES;
    
}

#pragma Mark Arth-------


-(IBAction)update_date_back_button:(id)sender
{
    [self.edit_date_view setHidden:YES];
}
-(IBAction)update_date_textfieldbutton_action:(id)sender
{
    [self.update_date_editdate_view setHidden:NO];
   // [self.date_pickview setHidden:NO];
    
}
-(IBAction)update_date_editdate_view_donebutton:(id)sender
{
   
    
    [dateFormatter setDateFormat:@"MM-dd-yy"];
    
    NSString *formatedDate = [dateFormatter stringFromDate:self.date_pickview.date];
    
    self.update_date_textfield.text =formatedDate;
    
    //[datepk removeFromSuperview];
   // self.date_pickview.hidden = YES;
    self.update_date_editdate_view.hidden=YES;
}
-(IBAction)update_date_editdate_view_cancel:(id)sender
{
    [self.update_date_editdate_view setHidden:YES];
  //  [self.date_pickview setHidden:YES];
}


-(IBAction)overdue_appointment_button_action:(id)sender
{
    AppointmentReportVC *objAppointmentReportVC=[self.storyboard instantiateViewControllerWithIdentifier:@"AppointmentReportVC"];
    [self.navigationController pushViewController:objAppointmentReportVC animated:NO];
}

-(IBAction)medication_taken_button_action:(id)sender
{
    MedicationReportVC *objMedicationReportVC=[self.storyboard instantiateViewControllerWithIdentifier:@"MedicationReportVC"];
    [self.navigationController pushViewController:objMedicationReportVC animated:NO];
//  [_report_medication_view setHidden:NO];
}


//report back button actions...

-(IBAction)overdue_appointment_back_button_action:(id)sender
{
    [_report_overdue_view setHidden:YES];
    
}

-(IBAction)completed_appointment_back_button_action:(id)sender
{
    [_report_completed_view setHidden:YES];
    
}

-(IBAction)hiv_tests_completed_back_button_action:(id)sender
{
    [_report_hiv_tests_view setHidden:YES];
    
}

-(IBAction)medication_taken_back_button_action:(id)sender
{
    [_report_medication_view setHidden:YES];
    
}

- (IBAction)medicine_to_back:(id)sender {
    
    
    [_medicine_reminder_view setHidden:YES];

}
//notification edited by
- (IBAction)medicine_reminder_save_action:(id)sender {
    
    @try {
        NSString *numberFromTheKeyboard = _set_hour_medicine_reminder_textfield.text;
    int x = [numberFromTheKeyboard intValue];
    
    if(numberFromTheKeyboard.length == 2)
    {
        
        if (x <= 12)
        {
            
             [_set_hour_medicine_reminder_textfield resignFirstResponder];
             [_medicine_reminder_view setHidden:YES];
            NSMutableDictionary *dic=[[NSMutableDictionary alloc ]init];
            
            [dic setObject:titleStr forKey:@"NAME"];
            
            [dic setObject:PinNewStr forKey:@"PIN"];
            
            
            [dic setObject:DateStr forKey:@"STARTDATE"];
            
            
            [dic setObject:Pill_TIME forKey:@"PILLTIME"];
            
            [dic setObject:PillCountStr forKey:@"PILLCOUNT"];
            
            NSMutableArray  *Array=[[NSMutableArray alloc]init];
            
            [Array addObject:dic];
            
            [dbh UserUpdate:Array];
            
            // [NSDate dateWithTimeIntervalSinceNow:10]
            [self setupLocalNotifications];
         
          }else{
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"set hour"
                                                            message:@"enter valid hour"
                                                           delegate:self
                                                  cancelButtonTitle:@"OK"
                                                  otherButtonTitles:nil];
            [alert show];
          }
        
        
    }else{
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"set hour"
                                                        message:@"lenth must be less than 2"
                                                       delegate:self
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil];
        [alert show];
    }
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}


// adding number pad ...pradip
-(void)cancelNumberPad{
    [_pin_enter_new_pin_text resignFirstResponder];
    [_Pin_enter_old_pin_text resignFirstResponder];
    [_set_hour_medicine_reminder_textfield resignFirstResponder];
    _set_hour_medicine_reminder_textfield.text = @"";
}

-(void)doneWithNumberPad{
  NSString *numberFromTheKeyboard = _set_hour_medicine_reminder_textfield.text;
    int x = [numberFromTheKeyboard intValue];
    
    if(numberFromTheKeyboard.length == 2)
    {
        
        if (x <= 12)
        {
            [self setupLocalNotifications];
        [_set_hour_medicine_reminder_textfield resignFirstResponder];
            
        }else{
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"set hour"
                message:@"enter valid hour"
            delegate:self
            cancelButtonTitle:@"OK"
            otherButtonTitles:nil];
            [alert show];
        }
        
        
    }else{
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"set hour"
                                                        message:@"lenth must be less than 2"
                                                       delegate:self
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil];
        [alert show];
    }
}
-(void)doneWithNumberPad1 {
    if ([PinNewStr isEqualToString:_Pin_enter_old_pin_text.text]) {
        
        [_Pin_enter_old_pin_text  resignFirstResponder];
    } else{
        _Pin_enter_old_pin_text.text = @"";
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert"
        message:@"your Current pin is Wrong"
        delegate:self cancelButtonTitle:@"OK"
        otherButtonTitles:nil];
    [alert show];
    }
    }
- (void)doneWithNumberPad2 {
    
     if ([_pin_enter_new_pin_text.text  isEqualToString:_Pin_enter_old_pin_text.text])
     {
         UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert"
                                                         message:@"You have Entered Same Pin"
                                                        delegate:self cancelButtonTitle:@"OK"
                                               otherButtonTitles:nil];
         [alert show];
     }else{
         
     [_pin_enter_new_pin_text  resignFirstResponder];
    NSMutableDictionary *dic=[[NSMutableDictionary alloc ]init];
    
    [dic setObject:titleStr forKey:@"NAME"];
    
    [dic setObject:_pin_enter_new_pin_text forKey:@"PIN"];
    
    
    [dic setObject:DateStr forKey:@"STARTDATE"];
    
    
    [dic setObject:Pill_TIME forKey:@"PILLTIME"];
    
    [dic setObject:PillCountStr forKey:@"PILLCOUNT"];
    
    NSMutableArray  *Array=[[NSMutableArray alloc]init];
    
    [Array addObject:dic];
    
    [dbh UserUpdate:Array];
  }
}
-(void)dismissKeyboard {
    [_set_hour_medicine_reminder_textfield resignFirstResponder];
}
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    [self.view endEditing:YES];
}

- (void)setupLocalNotifications {
    
    
    NSDate *date=(NSDate*)[[NSUserDefaults standardUserDefaults]objectForKey:@"Fire_Date"];
    NSDateFormatter *formatter = [[NSDateFormatter alloc] init];
    [formatter setDateFormat:@"hh:mm a"];
    NSString *stringFromDate = [formatter stringFromDate:date];
    
    NSString *numberFromTheKeyboard = _set_hour_medicine_reminder_textfield.text;
    NSString *n1=@"Please Take Your Medicine On Time :";
    n1=[n1 stringByAppendingString:stringFromDate];
    int x= [numberFromTheKeyboard intValue];
    
    NSDate *minusOneHr = [date dateByAddingTimeInterval:-60*60*x];
    
   // [[UIApplication sharedApplication]cancelAllLocalNotifications];
    UILocalNotification* localNotification = [[UILocalNotification alloc] init];
    localNotification.fireDate = minusOneHr;
    localNotification.alertBody = n1;
    localNotification.timeZone = [NSTimeZone systemTimeZone];
    [[UIApplication sharedApplication] scheduleLocalNotification:localNotification];
    [self dismissViewControllerAnimated:YES completion:nil];
    
 }
- (IBAction)btnAppoinmentReminderBack:(id)sender {
    [_viewReminderApoinment setHidden:YES];
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    if (textField.tag == 100) {
    [UIView animateWithDuration:0.50 animations:^{
        
       self.viewDatePicker.frame = CGRectMake(0, self.view.frame.size.height - 242, self.view.frame.size.width, 242) ;
    }];
    return NO;
    }else
        return YES;
}
- (IBAction)btnDateCancel:(id)sender {
    [UIView animateWithDuration:0.50 animations:^{
        self.viewDatePicker.frame = CGRectMake(0, self.view.frame.size.height, self.view.frame.size.width, 242) ;
    }];
}

- (IBAction)btnDoneDate:(id)sender {
    @try{
        
        NSString *firstPill=UDGetValue(@"firstPillTaken");
        
        if ([firstPill isEqualToString:@"firstPillTaken"]) {
            
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert" message:@"You can not Update Start Date Now" delegate:nil cancelButtonTitle:@"OK" otherButtonTitles:nil];
            [alert show];
            
        }else
        {
    NSDate *date = [_date_pickview date];
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
  //  NSTimeZone *gmt = [NSTimeZone systemTimeZone];
 //   [dateFormat setTimeZone:[NSTimeZone systemTimeZone]];
    [dateFormat setDateFormat:@"MM-dd-yy"];
    
    _update_date_textfield.text = [dateFormat stringFromDate:date];
    
        }
            
    [UIView animateWithDuration:0.50 animations:^{
        self.viewDatePicker.frame = CGRectMake(0, self.view.frame.size.height, self.view.frame.size.width, 242) ;
    }];
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}

-(void)dismissKeyboar {
    [_update_date_textfield resignFirstResponder];
}






-(void)updateDate
{
 
    UDSetInt(0,@"isCompleted");
    UDSetObject(@"3 days", @"appointType");
    [dbh resetAppointments];
    
    NSString *StaryDate=_update_date_textfield.text;
    
  //  StaryDate=[StaryDate substringToIndex:10];
    
    
    dateFormatter = [[NSDateFormatter alloc] init];
    
    [dateFormatter setDateFormat:@"MM-dd-yy"];
    NSDate *dateFromString = [[NSDate alloc] init];
    
    dateFromString = [dateFormatter dateFromString:StaryDate];
    
    //3 day......
    
//    int daysToAdd = 3;
//    NSDate *newDate1 = [dateFromString dateByAddingTimeInterval:60*60*24*daysToAdd];
//    
//    NSString *ThreeDayStr = [dateFormatter stringFromDate:newDate1];
//    
//    appDelegate.update_titleName=@"3 Day Phone Call";
//    
//    
//    [dbh UpdateSetting_startdate:ThreeDayStr];
    
    
    //14 day....
    
//    int daysToAdd14 = 14;
//    NSDate *newDate14 = [dateFromString dateByAddingTimeInterval:60*60*24*daysToAdd14];
//    
//    NSString *Str14 = [dateFormatter stringFromDate:newDate14];
//    
//    appDelegate.update_titleName=@"14 Day Phone Call";
//    [dbh UpdateSetting_startdate:Str14];
    
    // 1 month
    
    
    NSDate *oneMonthVisit= UDGetObject(@"1monthVisit");
    [self disableNotificationAppoint:oneMonthVisit];
    int daysToAdd30 = 30;
    int daysToAdd27=27;
    NSDate *newDate30 = [dateFromString dateByAddingTimeInterval:60*60*24*daysToAdd30];
    
    NSString *Str30 = [dateFormatter stringFromDate:newDate30];
    
    appDelegate.update_titleName=@"1 Month Visit";
    [dbh UpdateDateAppo_startdate:Str30];
    
    NSDate *newDate27 = [dateFromString dateByAddingTimeInterval:60*60*24*daysToAdd27];
    
    UDSetObject(newDate27,@"1monthVisit");
    [self enableNotification:newDate27 alertBody:@"1 Month Visit"];
    
    
    // 3 month
    NSDate *threeMonthVisit= UDGetObject(@"3monthVisit");
    [self disableNotificationAppoint:threeMonthVisit];
    
    int daysToAdd90 = 90;
    int DaysToAd87=87;
    NSDate *newDate90 = [dateFromString dateByAddingTimeInterval:60*60*24*daysToAdd90];
    
    NSString *Str90 = [dateFormatter stringFromDate:newDate90];
    
    appDelegate.update_titleName=@"3 Month Visit";
    [dbh UpdateDateAppo_startdate:Str90];
    
    NSDate *newDate87 = [dateFromString dateByAddingTimeInterval:60*60*24*DaysToAd87];

    UDSetObject(newDate87,@"3monthVisit");
    [self enableNotification:newDate87 alertBody:@"3 Month Visit"];
    
    // 6 month
    NSDate *sixMonthVisit= UDGetObject(@"6monthVisit");
    [self disableNotificationAppoint:sixMonthVisit];
    
    int daysToAdd6M = 180;
    int daysToAdd6M3 = 177;
    
    NSDate *newDate6M = [dateFromString dateByAddingTimeInterval:60*60*24*daysToAdd6M];
    
    NSString *Str6M = [dateFormatter stringFromDate:newDate6M];
    
    appDelegate.update_titleName=@"6 Month Visit";
    [dbh UpdateDateAppo_startdate:Str6M];
    
    NSDate *newDate6M3 = [dateFromString dateByAddingTimeInterval:60*60*24*daysToAdd6M3];
    
    UDSetObject(newDate6M3,@"6monthVisit");
    [self enableNotification:newDate6M3 alertBody:@"6 Month Visit"];
    // 9 month
    
    
//    int daysToAdd9M = 270;
//    NSDate *newDate9M = [dateFromString dateByAddingTimeInterval:60*60*24*daysToAdd9M];
//    
//    NSString *Str9M = [dateFormatter stringFromDate:newDate9M];
//    
//    appDelegate.update_titleName=@"9 Month Visit";
//    [dbh UpdateSetting_startdate:Str9M];
//    // 1 yr12 Month Visit
//    
//    
//    int daysToAdd1yr = 365;
//    NSDate *newDate1yr = [dateFromString dateByAddingTimeInterval:60*60*24*daysToAdd1yr];
//    
//    NSString *Str1yr = [dateFormatter stringFromDate:newDate1yr];
//    
//    appDelegate.update_titleName=@"12 Month Visit";
//    [dbh UpdateSetting_startdate:Str1yr];
    
  //  [self.navigationController popViewControllerAnimated:TRUE];
    
}

-(void)enableNotification:(NSDate *)date alertBody:(NSString *)title
{
    UILocalNotification* localNotification = [[UILocalNotification alloc] init];
    localNotification.fireDate = date;
    localNotification.alertBody = title;
    localNotification.soundName=UILocalNotificationDefaultSoundName;
    [[UIApplication sharedApplication] scheduleLocalNotification:localNotification];
    NSLog(@"%@",localNotification);
}

-(void)disableNotificationAppoint:(NSDate *)DateVisit
{
    NSArray *arrayOfLocalNotifications = [[UIApplication sharedApplication] scheduledLocalNotifications] ;
    
    for (UILocalNotification *localNotification in arrayOfLocalNotifications)
    {
        if ([localNotification.fireDate isEqualToDate:DateVisit])
        {
            NSLog(@"the notification this is canceld is %@", localNotification.alertBody);
            
            [[UIApplication sharedApplication] cancelLocalNotification:localNotification] ;
            // delete the notification from the system
        }
    }
}


-(void)disableNotification:(NSString*)alertBodyTitle
{
    NSArray *arrayOfLocalNotifications = [[UIApplication sharedApplication] scheduledLocalNotifications] ;
    
    for (UILocalNotification *localNotification in arrayOfLocalNotifications)
    {
        if ([localNotification.alertBody isEqualToString:alertBodyTitle])
        {
            NSLog(@"the notification this is canceld is %@", localNotification.alertBody);
            
            [[UIApplication sharedApplication] cancelLocalNotification:localNotification] ;
            // delete the notification from the system
        }
    }
}


-(void)setDateLimit
{
    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    NSDate *currentDate = [NSDate date];
    NSDateComponents *comps = [[NSDateComponents alloc] init];
    [comps setYear:30];
    NSDate *maxDate = [calendar dateByAddingComponents:comps toDate:currentDate options:0];
    NSDate *minDate = currentDate;
    
    [_date_pickview setMaximumDate:maxDate];
    [_date_pickview setMinimumDate:minDate];
}
@end
