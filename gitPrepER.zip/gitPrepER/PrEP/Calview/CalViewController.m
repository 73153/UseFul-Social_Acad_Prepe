//
//  CalViewController.m
//  PrEP
//
//  Created by Bhushan on 5/15/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import "CalViewController.h"
#import "SettingViewController.h"
#import "DashBoardViewController.h"
#import "NotificationViewController.h"
#import "AppointmentViewController.h"
#import "CalViewController.h"
#import <CoreGraphics/CoreGraphics.h>
#import "CKCalendarView.h"
#import "DataBase.h"
#import "CalDetailsViewController.h"
#import "DashBoardViewController.h"
#import "AddAppointmentViewController.h"
#import "CKCalendarView.h"
#import "Constant.h"

#define DEGREES_TO_RADIANS(d) (d * M_PI / 180)
@interface CalViewController ()<CKCalendarDelegate,UIScrollViewDelegate>
{
    DataBase *dbh;
    //AppDelegate *appDelegate;
    
    
    
}

@property(nonatomic, weak) CKCalendarView *calendar;
@property(nonatomic, strong) UILabel *dateLabel;
@property(nonatomic, strong) NSDateFormatter *dateFormatter;
@property(nonatomic, strong) NSDate *minimumDate;
@property(nonatomic, strong) NSMutableArray *disabledDates;
@end

@implementation CalViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
      //  AppointmentViewController *arrDate = [[AppointmentViewController alloc] init];

}

-(void)viewWillAppear:(BOOL)animated {
    @try{
    DashBoardViewController *dash=[[DashBoardViewController alloc]init];
    _delegate=dash.self;
    
    UIView *view = [self.view viewWithTag:10000];
    [view removeFromSuperview];
    
    CKCalendarView *calendar = [[CKCalendarView alloc] initWithStartDay:startMonday];
    self.calendar = calendar;
    self.calendar.delegate = self;
    self.calendar.tag = 10000;
    self.dateFormatter = [[NSDateFormatter alloc] init];
    [self.dateFormatter setDateFormat:@"MM-dd-yy"];
    //   self.minimumDate = [self.dateFormatter dateFromString:@"20/09/2014"];
    self.calendar.onlyShowCurrentMonth = NO;
    self.calendar.adaptHeightToNumberOfWeeksInMonth = YES;
    
    self.calendar.frame = CGRectMake(10, 255, 300, 320);
    [self.view addSubview:self.calendar];
    // Do any additional setup after loading the view.
    
    dbh=[[DataBase alloc]init];
    
    
    AppDel=[[UIApplication sharedApplication] delegate];
    
    //appDelegate=[[UIApplication sharedApplication] delegate];
    
    //Calender
    
    self.disabledDates =[[NSMutableArray alloc]init];
    
    UserDateArray=[[NSMutableArray alloc]init];
    
    UserDateArray=[dbh AppointmentSelect_Inconform];
    
    
    
    for (int i=0; i<[UserDateArray count]; i++)
    {
        
        NSString *dateStr;
        
        
        if ([[[UserDateArray objectAtIndex:i] objectForKey:@"DATE"]isKindOfClass:[NSNull class]])
        {
            dateStr=@"";
            //   NSLog(@"abcd");
        }
        else
        {
            dateStr=[[UserDateArray objectAtIndex:i] objectForKey:@"DATE"];
           // dateStr=[dateStr substringToIndex:10];
            
            
            NSDate *date1=[self.dateFormatter dateFromString:dateStr];
            //  NSLog(@"abcde");
            
            
            [self.disabledDates addObject:date1];
        }
    }

    //  self.dateLabel = [[UILabel alloc] initWithFrame:CGRectMake(10, CGRectGetMaxY(calendar.frame) + 4, self.view.bounds.size.width, 24)];
    //   [self.view addSubview:self.dateLabel];
    
    self.view.backgroundColor = [UIColor whiteColor];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(localeDidChange) name:NSCurrentLocaleDidChangeNotification object:nil];
    
    
    //********************
    
    OverShow=NO;
    upcomingShow=NO;
    CompShow=NO;
    
    Rota=NO;
    
    dbh=[[DataBase alloc]init];
    Iscomp_DateArray=[[NSMutableArray alloc]init];
    Iscomp_Tital=[[NSMutableArray alloc]init];
    
    UpComming_DateArray=[[NSMutableArray alloc]init];
    UpComming_Tital=[[NSMutableArray alloc]init];;
    Over_DateArray=[[NSMutableArray alloc]init];
    Over_Tital=[[NSMutableArray alloc]init];;
    
    
    
    
    NSMutableArray *UserDateArray1=[[NSMutableArray alloc]init];
    
    UserDateArray1=[dbh selectAllUser];
    
    
    if ([UserDateArray1 count]>0)
    {//PIN,STARTDATE
        
        nameStr=[[UserDateArray1 objectAtIndex:0] objectForKey:@"NAME"];
        
        AppDel.Pill_countStr=[[UserDateArray1 objectAtIndex:0] objectForKey:@"PILLCOUNT"];
        
    }

    [_med_label_count setTitle: AppDel.Pill_countStr forState: UIControlStateNormal];
    
    
    
    [self pillColor];
    
    
    
    NSArray *SlectIsComp=[dbh Select_All_Appointment];;
    
    for (int i=0; i<[SlectIsComp count]; i++)
    {
        [Iscomp_DateArray addObject:[[SlectIsComp objectAtIndex:i]objectForKey:@"DATE"]];
        [Iscomp_Tital addObject:[[SlectIsComp objectAtIndex:i]objectForKey:@"TITLE"]];
        
    }
    
    
    AppDel.Increment_Id_App_Str=[NSString stringWithFormat:@"%lu",(unsigned long)[Iscomp_DateArray count]+2];
    
    NSLog(@"%@",AppDel.Increment_Id_App_Str);
    
    //-------------------------------------------------------------------------------------------------
    
    NSArray *UpComming=[dbh AppointmentSelect_upcomming];
    
    
    for (int i=0; i<[UpComming count]; i++)
    {
        [UpComming_DateArray addObject:[[UpComming objectAtIndex:i]objectForKey:@"DATE"]];
        [UpComming_Tital addObject:[[UpComming objectAtIndex:i]objectForKey:@"TITLE"]];
        
    }
    
    
    
    //-------------------------------------------------------------------------------------------------
    
    
    NSArray *Over=[dbh AppointmentSelect_overdue];
    
    for (int i=0; i<[Over count]; i++)
    {
        [Over_DateArray addObject:[[Over objectAtIndex:i]objectForKey:@"DATE"]];
        [Over_Tital addObject:[[Over objectAtIndex:i]objectForKey:@"TITLE"]];
        
    }
    

    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}


- (IBAction)dash1_tab_button_action:(id)sender
{
    @try{
    int index = 0;
    for (UIViewController *vc in self.navigationController.viewControllers) {
        if ([vc isKindOfClass:[DashBoardViewController class]]) {
            [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:index] animated:NO];
        }
        index++;
    }
    DashBoardViewController *objDashBoardViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"DashBoardViewController"];
    [self.navigationController pushViewController:objDashBoardViewController animated:NO];
    
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}

- (IBAction)noti1_tab_button_action:(id)sender
{
    @try{
    int index = 0;
    for (UIViewController *vc in self.navigationController.viewControllers) {
        if ([vc isKindOfClass:[NotificationViewController class]]) {
            [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:index] animated:NO];
        }
        index++;
    }
    NotificationViewController *objNotificationViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"NotificationViewController"];
    [self.navigationController pushViewController:objNotificationViewController animated:NO];
    
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}

- (IBAction)task1_tab_button_action:(id)sender
{
    @try{
    int index = 0;
    for (UIViewController *vc in self.navigationController.viewControllers) {
        if ([vc isKindOfClass:[AppointmentViewController class]]) {
            [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:index] animated:NO];
        }
        index++;
    }
    AppointmentViewController *objAppointmentViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"AppointmentViewController"];
    [self.navigationController pushViewController:objAppointmentViewController animated:NO];
    
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}



- (IBAction)setting1_tab_button_action:(id)sender
{
    @try{
//    int index = 0;
//    for (UIViewController *vc in self.navigationController.viewControllers) {
//        if ([vc isKindOfClass:[SettingViewController class]]) {
//            [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:index] animated:NO];
//        }
//        index++;
//    }
    SettingViewController *objSettingViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"SettingViewController"];
    [self.navigationController pushViewController:objSettingViewController animated:NO];
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}

- (IBAction)back_button_action:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}



#pragma mark -pill action

- (IBAction)pil1_btn:(id)sender {
    @try{
        NSMutableArray *DateArray=[dbh selectAllUser];
        DateArray=[dbh selectAllUser];
        NSString *strStartDate=[[NSString alloc]init];
        strStartDate=[[DateArray objectAtIndex:0] objectForKey:@"STARTDATE"];
        
        
        NSDate *currentDateInLocal = [NSDate date];
        NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
        NSDate *lastPillTakenDate=UDGetObject(@"dtlastPillTakenDate");
        [dateFormat setDateFormat:@"MM-dd-yy"];
        NSString *strCurrentDate=[dateFormat stringFromDate:currentDateInLocal];
        //  NSString *strLastPillTakenDate=[dateFormat stringFromDate:lastPillTakenDate];
        currentDateInLocal =[dateFormat dateFromString:strCurrentDate];
        //   lastPillTakenDate =[dateFormat dateFromString:strCurrentDate];
        NSDate *startDate=[dateFormat dateFromString:strStartDate];
        if ([currentDateInLocal compare:startDate] == NSOrderedAscending) {
            [self Alert:@"You can not take Pill before Start Date"];
        }else{
            

        if (lastPillTakenDate == nil || [currentDateInLocal compare:lastPillTakenDate] == NSOrderedDescending) {
        
        
        [self PillInsertReq];
    [_delegate updateRegularPillTaken:MedInt];
    if (Rota==YES)
    {
        
        if (MedInt<1)
        {
            
        }else{
            
            MedInt--;
            
            
            NSString *MeStr=[NSString stringWithFormat:@"%d",MedInt];
            
            AppDel.Pill_countStr=[NSString stringWithFormat:@"%@",MeStr];
            
            [dbh Update_pillCount:nameStr];
            
            
            
            [_med_label_count setTitle:MeStr forState: UIControlStateNormal];
            
            [_med_label_count setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
            
            [UIView animateWithDuration:0.80 animations:^{
                _pill_button1.transform = CGAffineTransformMakeRotation(DEGREES_TO_RADIANS(180));
                
            }];
            [UIView animateWithDuration:0.80 animations:^{
                _pill_button1.transform = CGAffineTransformMakeRotation(DEGREES_TO_RADIANS(360));
                
            }];
            Rota=NO;
        }
    }
    else
    {
        if (MedInt<1)
        {
            
        }else{
            
            MedInt--;
            
            NSString *MeStr=[NSString stringWithFormat:@"%d",MedInt];
            
            AppDel.Pill_countStr=[NSString stringWithFormat:@"%@",MeStr];
            
            
            
            [dbh Update_pillCount:nameStr];
            
            [_med_label_count setTitle:MeStr forState: UIControlStateNormal];
            
            [_med_label_count setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
            
            
            
            
            [UIView animateWithDuration:0.80 animations:^{
                _pill_button1.transform = CGAffineTransformMakeRotation(DEGREES_TO_RADIANS(180));
                
            }];
            [UIView animateWithDuration:0.80 animations:^{
                _pill_button1.transform = CGAffineTransformMakeRotation(DEGREES_TO_RADIANS(360));
                
            }];
            
            
            Rota=YES;
        }
    }
   
    }else if ([currentDateInLocal compare:lastPillTakenDate] == NSOrderedSame) {
        [self Alert:@"You have already taken today's pill"];
    }
        }
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}

-(void)PillInsertReq
{
     UDSetValue(@"firstPillTaken", @"firstPillTaken");
    NSDate *currentDateInLocal = [NSDate date];
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    NSDateFormatter *dateFormat1 = [[NSDateFormatter alloc] init];
    
    [dateFormat setDateFormat:@"MM-dd-yy"];
    NSString *DateStr = [dateFormat stringFromDate:currentDateInLocal];
    NSDate *lastPillTakenDate=[dateFormat dateFromString:DateStr];
    
    [[NSUserDefaults standardUserDefaults] setObject:lastPillTakenDate forKey:@"dtlastPillTakenDate"];
    
    [dateFormat1 setDateFormat:@"hh:mm a"];
    
    NSString* timeStr=[dateFormat1 stringFromDate:currentDateInLocal];
    
    NSMutableDictionary *dic=[[NSMutableDictionary alloc ]init];
    
    
    [dic setObject:@"1" forKey:@"USER_ID"];
    [dic setObject:@"Medicine 1" forKey:@"MED_NAME"];
    [dic setObject:DateStr forKey:@"START_DATE"];
    [dic setObject:@"0" forKey:@"MED_TAKEN"];
    [dic setObject:@"1" forKey:@"MED_QUNTITY"];
    [dic setObject:timeStr forKey:@"MED_TIME"];
    
    [[NSUserDefaults standardUserDefaults] setObject:DateStr forKey:@"lastPillTakenDate"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    NSMutableArray *dealArray=[[NSMutableArray alloc]init];
    
    [dealArray addObject:dic];
    
    [dbh insertMEDICAL_RECORD:dealArray];
    
}


- (IBAction)add_appoint_action:(id)sender
{
    @try{
    AddAppointmentViewController *objAddAppointmentViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"AddAppointmentViewController"];
    [self.navigationController pushViewController:objAddAppointmentViewController animated:YES];
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}

- (void)localeDidChange {
    [self.calendar setLocale:[NSLocale currentLocale]];
}

- (BOOL)dateIsDisabled:(NSDate *)date {
    for (NSDate *disabledDate in self.disabledDates) {
        if ([disabledDate isEqualToDate:date]) {
            return YES;
        }
    }
    return NO;
}

#pragma mark -
#pragma mark - CKCalendarDelegate

- (void)calendar:(CKCalendarView *)calendar configureDateItem:(CKDateItem *)dateItem forDate:(NSDate *)date {
    dateItem.selectedBackgroundColor = [UIColor clearColor];

    // TODO: play with the coloring if we want to...
    if ([self dateIsDisabled:date]) {
        if ([date compare:[NSDate date]] == NSOrderedAscending) {
            dateItem.selectedBackgroundColor = [UIColor clearColor];
        }
        else{
            dateItem.backgroundColor = [UIColor redColor];
            dateItem.textColor = [UIColor whiteColor];
        }
    }
}

//- (BOOL)calendar:(CKCalendarView *)calendar willSelectDate:(NSDate *)date {
//    return ![self dateIsDisabled:date];
//}

- (void)calendar:(CKCalendarView *)calendar didSelectDate:(NSDate *)date
{
    // self.dateLabel.text = [self.dateFormatter stringFromDate:date];
    
    AppDel.Cal_dateStr=[self.dateFormatter stringFromDate:date];
    
    NSLog(@"%@",AppDel.Cal_dateStr);
    
    CalDetailsViewController *objCalDetailsViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"CalDetailsViewController"];
    self.calendar.delegate = nil;
    [self.navigationController pushViewController:objCalDetailsViewController animated:YES];
}

- (BOOL)calendar:(CKCalendarView *)calendar willChangeToMonth:(NSDate *)date {
    if ([date laterDate:self.minimumDate] == date) {
        self.calendar.backgroundColor = [UIColor clearColor];
        return YES;
    } else {
        self.calendar.backgroundColor = [UIColor clearColor];
        return NO;
    }
}

- (void)calendar:(CKCalendarView *)calendar didLayoutInRect:(CGRect)frame {
    NSLog(@"calendar layout: %@", NSStringFromCGRect(frame));
}

-(void)pillColor
{
    
    NSString *MedStr=[NSString stringWithFormat:@"%@",_med_label_count.titleLabel.text];
    MedInt=[MedStr intValue];
    UDSetValue(MedStr,@"med");
    NSString *initialPillCount=[[NSUserDefaults standardUserDefaults] objectForKey:@"initialCount"];
    intialCount=[initialPillCount intValue];
    NSDateFormatter *formatter=[[NSDateFormatter alloc]init];
    //   NSTimeZone *timeZone = [NSTimeZone timeZoneWithName:@"UTC"];
    [formatter setDateFormat:@"MM-dd-yy"];
    // [formatter setTimeZone:timeZone];
    NSString *strlastPillTakenDate=[[NSUserDefaults standardUserDefaults]objectForKey:@"lastPillTakenDate"];
    
    NSDate *lastPillTakenDate=[[NSDate alloc]init];
    lastPillTakenDate= [formatter dateFromString:strlastPillTakenDate];
    NSDate *currentDate=[[NSDate alloc]init];
    NSString *time=[formatter stringFromDate:currentDate];
    currentDate=[formatter dateFromString:time];
    
    if ([lastPillTakenDate compare:currentDate]== NSOrderedAscending)
    {
        [_med_label_count setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    }else{
        NSString *firstPill=UDGetValue(@"firstPillTaken");
        
        if (!firstPill) {
            [_med_label_count setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
        }else
        {
            [_med_label_count setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
            
        }
    }
    
    
}

    
-(void)Alert:(NSString *)alertBody
{
    UIAlertView *myAlert = [[UIAlertView alloc]               initWithTitle:@"Alert"
                                                                    message:alertBody
                                                                   delegate:self
                                                          cancelButtonTitle:@"Ok"
                                                          otherButtonTitles:nil];
    [myAlert show];
}



@end
