//
//  CalViewController.h
//  PrEP
//
//  Created by Bhushan on 5/15/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import "ViewController.h"
#import "AppDelegate.h"

@interface CalViewController : ViewController
{
    NSMutableArray *Iscomp_DateArray,*Iscomp_Tital;
    NSMutableArray *UpComming_DateArray,*UpComming_Tital;
    NSMutableArray *Over_DateArray,*Over_Tital;
    
    
    
    
    
    AppDelegate *AppDel;
    BOOL Rota;
    int MedInt;
    int intialCount;
    NSString *nameStr;
    
    
    BOOL OverShow;
    BOOL upcomingShow;
    
    BOOL CompShow;
    
    
}
@property (nonatomic,strong)id<UpdateRegularPill> delegate;
@property (nonatomic,retain) NSMutableArray *arrTopFiveAppoint;
@property (nonatomic,retain) NSMutableArray *arrTopFiveAppointTime;
@property (strong, nonatomic) IBOutlet UIButton *med_label_count;
@property (weak, nonatomic) IBOutlet UIButton *pill_button1;


- (IBAction)dash1_tab_button_action:(id)sender;

- (IBAction)noti1_tab_button_action:(id)sender;

- (IBAction)task1_tab_button_action:(id)sender;


- (IBAction)setting1_tab_button_action:(id)sender;

//- (IBAction)back1_button_action:(id)sender;

- (IBAction)pil1_btn:(id)sender;

- (IBAction)add_appoint_action:(id)sender;



@end
