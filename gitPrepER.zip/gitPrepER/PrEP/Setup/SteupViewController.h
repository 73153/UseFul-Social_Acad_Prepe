//
//  SteupViewController.h
//  PrEP
//
//  Created by Bhushan on 5/1/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//


#import <UIKit/UIKit.h>
#import "UITextField+StyleTextField.h"
#import"DataBase.h"

@interface SteupViewController : UIViewController
{
    UIToolbar *datePikrToolbar;
    NSDateFormatter *dateFormatter;
    IBOutlet UIView *Date_view;
    DataBase *dbh;
    NSArray *UserDateArray;
}

@property (weak, nonatomic) IBOutlet UIScrollView *main_scroll;
@property (weak, nonatomic) IBOutlet UITextField *name_textfield;
@property (weak, nonatomic) IBOutlet UITextField *pin_textfield;
@property (weak, nonatomic) IBOutlet UITextField *start_date_text;
@property (nonatomic,retain) IBOutlet UITextField *txtMedicineTime;
@property (nonatomic) BOOL isDate;

@property (weak, nonatomic) IBOutlet UIButton *save_button;
@property (strong, nonatomic) IBOutlet UITextField *pill_qua_text;
@property (strong, nonatomic) UIDatePicker *Date_picker;
@property(nonatomic,retain) UIToolbar *datePikrToolbar;
@property(nonatomic,retain)NSDateFormatter *dateFormatter;
@property(nonatomic,retain)IBOutlet UIView *Date_view;

- (IBAction)back_button_action:(id)sender;
- (IBAction)Done_Pick_button:(id)sender;
- (IBAction)cancel_Pick_button:(id)sender;
//-(void)cancelDatePkrBtnActn;
//-(void)doneDatePkrBtnActn;
- (IBAction)save_button_action:(id)sender;
-(void)updateDate;

@end
