//
//  SteupViewController.m
//  PrEP
//
//  Created by Bhushan on 5/1/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import "SteupViewController.h"
#import "Constant.h"
#define IS_IPHONE5 (([[UIScreen mainScreen] bounds].size.height-568)?NO:YES)
#define MAX_LENGTH 4
#define MAX_LENGTH_Pi 2


@interface SteupViewController ()

@end

@implementation SteupViewController
@synthesize Date_view,dateFormatter,datePikrToolbar;
@synthesize pill_qua_text;

- (void)viewDidLoad
{
    @try{
     [super viewDidLoad];
    [_save_button initWithBorders];
     dbh=[[DataBase alloc]init];
    UserDateArray=[dbh selectAllUser];
 
        _name_textfield.autocapitalizationType=UITextAutocapitalizationTypeWords;
        _name_textfield.clearButtonMode = UITextFieldViewModeWhileEditing;
        _pin_textfield.clearButtonMode = UITextFieldViewModeWhileEditing;
        _txtMedicineTime.clearButtonMode=UITextFieldViewModeWhileEditing;
        _start_date_text.clearButtonMode = UITextFieldViewModeWhileEditing;
        pill_qua_text.clearButtonMode = UITextFieldViewModeWhileEditing;

    if ([UserDateArray count]>0)
    {//PIN,STARTDATE
        
        _name_textfield.text=[[UserDateArray objectAtIndex:0] objectForKey:@"NAME"];
        _pin_textfield.text=[[UserDateArray objectAtIndex:0] objectForKey:@"PIN"];
    
        NSString *DateStr=[[UserDateArray objectAtIndex:0] objectForKey:@"STARTDATE"];
        
        NSString *TimeStr=[[UserDateArray objectAtIndex:0] objectForKey:@"PILLTIME"];
        
        _start_date_text.text=DateStr;
        self.txtMedicineTime.text =TimeStr;
         pill_qua_text.text=[[UserDateArray objectAtIndex:0] objectForKey:@"PILLCOUNT"];
 
    }
    
    

    //Save_button shadow set
    [_save_button initWithBorders];
    
    _save_button.layer.shadowColor = [UIColor blackColor].CGColor;
    
#pragma textfield layout

    [_name_textfield initTextFieldStyle];
    [_start_date_text initTextFieldStyle];
    [_pin_textfield initTextFieldStyle];
    [pill_qua_text initTextFieldStyle];
    [self.txtMedicineTime initTextFieldStyle];
    self.Date_picker = [[UIDatePicker alloc] initWithFrame:CGRectMake(0, 44, self.view.frame.size.width, 198)];
    [Date_view addSubview:self.Date_picker];
        
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }

}

//------------------------------------------------------------
#pragma mark - Custom Methods
#pragma mark -
//------------------------------------------------------------
-(void)viewWillAppear:(BOOL)animated
{
  

}
-(void)updateDate
{
    @try {
        
      UDSetObject(@"3 days", @"appointType");
    NSDate *dateFromString = [[NSDate alloc] init];
    NSString *StaryDate=_start_date_text.text;
    
   // StaryDate=[StaryDate substringToIndex:10];
    
    dateFormatter = [[NSDateFormatter alloc] init];
    
    [dateFormatter setDateFormat:@"MM-dd-yy"];
    
    
    dateFromString = [dateFormatter dateFromString:StaryDate];
    
    //3 day......
    
//    int daysToAdd = 3;
//    NSDate *newDate1 = [dateFromString dateByAddingTimeInterval:60*60*24*daysToAdd];
//    
//    NSString *ThreeDayStr = [dateFormatter stringFromDate:newDate1];
//    
//    appDelegate.update_titleName=@"3 Day Phone Call";
//    
//    
//    [dbh UpdateDateAppo_startdate:ThreeDayStr];
    
    
    //14 day....
    
//    int daysToAdd14 = 14;
//    NSDate *newDate14 = [dateFromString dateByAddingTimeInterval:60*60*24*daysToAdd14];
//    
//    NSString *Str14 = [dateFormatter stringFromDate:newDate14];
//    
//    appDelegate.update_titleName=@"14 Day Phone Call";
//     [dbh UpdateDateAppo_startdate:Str14];
    
    // 1 month
    
    NSDate *oneMonthVisit= UDGetObject(@"1monthVisit");
    [self disableNotificationAppoint:oneMonthVisit];
    int daysToAdd30 = 30;
    int daysToAdd27=27;
    NSDate *newDate30 = [dateFromString dateByAddingTimeInterval:60*60*24*daysToAdd30];
    
    NSString *Str30 = [dateFormatter stringFromDate:newDate30];
    
    appDelegate.update_titleName=@"1 Month Visit";
    [dbh UpdateDateAppo_startdate:Str30];
    
    NSDate *newDate27 = [dateFromString dateByAddingTimeInterval:60*60*24*daysToAdd27];
    
    UDSetObject(newDate27,@"1monthVisit");
    [self enableNotification:newDate27 alertBody:@"1 Month Visit"];
    
    
    // 3 month
    NSDate *threeMonthVisit= UDGetObject(@"3monthVisit");
    [self disableNotificationAppoint:threeMonthVisit];
    
    int daysToAdd90 = 90;
    int DaysToAd87=87;
    NSDate *newDate90 = [dateFromString dateByAddingTimeInterval:60*60*24*daysToAdd90];
    
    NSString *Str90 = [dateFormatter stringFromDate:newDate90];
    
    appDelegate.update_titleName=@"3 Month Visit";
    [dbh UpdateDateAppo_startdate:Str90];
    
    NSDate *newDate87 = [dateFromString dateByAddingTimeInterval:60*60*24*DaysToAd87];
    
    UDSetObject(newDate87,@"3monthVisit");
    [self enableNotification:newDate87 alertBody:@"3 Month Visit"];
    
    // 6 month
    NSDate *sixMonthVisit= UDGetObject(@"6monthVisit");
    [self disableNotificationAppoint:sixMonthVisit];
    
    int daysToAdd6M = 180;
    int daysToAdd6M3 = 177;
    
    NSDate *newDate6M = [dateFromString dateByAddingTimeInterval:60*60*24*daysToAdd6M];
    
    NSString *Str6M = [dateFormatter stringFromDate:newDate6M];
    
    appDelegate.update_titleName=@"6 Month Visit";
    [dbh UpdateDateAppo_startdate:Str6M];
    
    NSDate *newDate6M3 = [dateFromString dateByAddingTimeInterval:60*60*24*daysToAdd6M3];
    
    UDSetObject(newDate6M3,@"6monthVisit");
    [self enableNotification:newDate6M3 alertBody:@"6 Month Visit"];
    
    
    // 9 month
    
    
//    int daysToAdd9M = 270;
//    NSDate *newDate9M = [dateFromString dateByAddingTimeInterval:60*60*24*daysToAdd9M];
//    
//    NSString *Str9M = [dateFormatter stringFromDate:newDate9M];
//    
//     appDelegate.update_titleName=@"9 Month Visit";
//    [dbh UpdateDateAppo_startdate:Str9M];
    // 1 yr12 Month Visit
    
    
//    int daysToAdd1yr = 365;
//    NSDate *newDate1yr = [dateFromString dateByAddingTimeInterval:60*60*24*daysToAdd1yr];
//    
//     NSString *Str1yr = [dateFormatter stringFromDate:newDate1yr];
//    
//     appDelegate.update_titleName=@"12 Month Visit";
//    [dbh UpdateDateAppo_startdate:Str1yr];
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }

}

//------------------------------------------------------------
#pragma mark - UIscrollView Methods
#pragma mark -
//------------------------------------------------------------
static NSInteger stepRange1[] = {
    
    0,0,0,0,50,100
};

//------------------------------------------------------------

static NSInteger getScrollPos21(NSInteger i) {
    
    if (i < 1 || i > 5)
        return 0 ;
    return stepRange1[i] ;
}

//------------------------------------------------------------

static NSInteger stepRange[] = {
    
    0,0,0,0,50,100
};

//------------------------------------------------------------

static NSInteger getScrollPos2(NSInteger i) {
    
    if (i < 1 || i > 5)
        return 0 ;
    return stepRange[i] ;
}

//------------------------------------------------------------
#pragma mark - UITextField Methods
#pragma mark -
//------------------------------------------------------------
- (void)textViewDidBeginEditing:(UITextView *)textView
{
    
    
    _main_scroll.scrollEnabled = YES;
     CGPoint point = CGPointMake(0,700);
    [_main_scroll setContentOffset:point animated:YES] ;
    
}

//------------------------------------------------------------

- (void) textFieldDidBeginEditing:(UITextField *)textField
{
    if (textField.tag ==1 ) {
        Date_view.hidden=YES;
    }else if(textField.tag ==2 ){
       Date_view.hidden=YES;
    }else if(textField.tag ==3 ){
       Date_view.hidden=YES;
    }
    else if (textField.tag==4)
    {
        self.Date_picker.datePickerMode = UIDatePickerModeDate;
         Date_view.hidden=NO;
        
        [textField resignFirstResponder];
        [_name_textfield resignFirstResponder];
        
        [_pin_textfield resignFirstResponder];
        [_start_date_text resignFirstResponder];
        
        [pill_qua_text resignFirstResponder];
        
        
        CGPoint point;
       
        point = CGPointMake(0, getScrollPos21(textField.tag));
        [_main_scroll setContentOffset:point animated:YES] ;
        
      
    }else if (textField.tag==5)
    {
        self.Date_picker.datePickerMode = UIDatePickerModeTime;
        Date_view.hidden=NO;
        
        [textField resignFirstResponder];
        [_name_textfield resignFirstResponder];
        [_pin_textfield resignFirstResponder];
        [_start_date_text resignFirstResponder];
        [pill_qua_text resignFirstResponder];
       
        
        CGPoint point;
        
        point = CGPointMake(0, getScrollPos21(textField.tag));
        [_main_scroll setContentOffset:point animated:YES] ;
        
        
    }
    else
    {
    
    
    _main_scroll.scrollEnabled = YES;
    
    
    CGPoint point;
        
    if (IS_IPHONE5)
        point = CGPointMake(0, getScrollPos21(textField.tag));
    else
        point = CGPointMake(0, getScrollPos2(textField.tag));
    
    
    [_main_scroll setContentOffset:point animated:YES] ;
    
    }
    
    
}

//------------------------------------------------------------

-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if (textField.tag==4)
    {
        self.Date_picker.datePickerMode = UIDatePickerModeDate;
        Date_view.hidden=NO;
        self.isDate = YES;
        [textField resignFirstResponder];
        
        [_name_textfield resignFirstResponder];
        [_pin_textfield resignFirstResponder];
        [_start_date_text resignFirstResponder];
        [pill_qua_text resignFirstResponder];
      
        
        CGPoint point;
        
        point = CGPointMake(0, getScrollPos21(textField.tag));
        [_main_scroll setContentOffset:point animated:YES] ;
        
        return NO;
    }else if (textField.tag==5)
    {
        self.Date_picker.datePickerMode = UIDatePickerModeTime;
        Date_view.hidden=NO;
        self.isDate = NO;
        [textField resignFirstResponder];
        [_name_textfield resignFirstResponder];
        
        [_pin_textfield resignFirstResponder];
        [_start_date_text resignFirstResponder];
        
        [pill_qua_text resignFirstResponder];
        
        
        CGPoint point;
        
        point = CGPointMake(0, getScrollPos21(textField.tag));
        [_main_scroll setContentOffset:point animated:YES] ;
        
        return NO;
    }
    else
    {
    return YES;
    }
}

//------------------------------------------------------------

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    _main_scroll.scrollEnabled = YES;
    
    
    
    NSInteger nextTag = textField.tag + 1;
    UIResponder* nextResponder = [textField.superview viewWithTag:nextTag];
    
    if (nextResponder)
    {
        if (nextTag==4)
        {
        
            Date_view.hidden=NO;
            
            CGPoint point = CGPointMake(0, getScrollPos2(nextTag));
            [_main_scroll setContentOffset:point animated:YES];
            
            [_name_textfield resignFirstResponder];
            
            [_pin_textfield resignFirstResponder];
            [_start_date_text resignFirstResponder];
            
            [textField resignFirstResponder];
        }
        else{
        
        [nextResponder becomeFirstResponder];
        CGPoint point = CGPointMake(0, getScrollPos2(nextTag));
        [_main_scroll setContentOffset:point animated:YES];
        }
        
    }
    else
    {
        CGPoint point = CGPointMake(0,64);
        [_main_scroll setContentOffset:point animated:YES] ;
        [textField resignFirstResponder];
    }
    
    return YES;
}

//------------------------------------------------------------

-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    
    if (textField.tag == 2)
    {
     
        if (textField.text.length >= MAX_LENGTH && range.length == 0)
        {
            return NO; // return NO to not change text
        }
       
    /* for backspace */
    if([string length]==0)
    {
        return YES;
    }
    
    /*  limit to only numeric characters  */
    
    NSCharacterSet *myCharSet = [NSCharacterSet characterSetWithCharactersInString:@"0123456789"];
    for (int i = 0; i < [string length]; i++) {
        unichar c = [string characterAtIndex:i];
        if ([myCharSet characterIsMember:c]) {
            return YES;
        }
    }
    
    return NO;
    }
    else  if (textField.tag == 3)
    {
        if (textField.text.length >= MAX_LENGTH_Pi && range.length == 0)
        {
            return NO; // return NO to not change text
        }
        
        /* for backspace */
        if([string length]==0)
        {
            return YES;
        }
        
        /*  limit to only numeric characters  */
        
        NSCharacterSet *myCharSet = [NSCharacterSet characterSetWithCharactersInString:@"0123456789"];
        for (int i = 0; i < [string length]; i++) {
            unichar c = [string characterAtIndex:i];
            if ([myCharSet characterIsMember:c]) {
                return YES;
            }
        }
        
        return NO;
    }
    
    return YES;
    
}

//------------------------------------------------------------
#pragma mark - IBAction Methods
#pragma mark -
//------------------------------------------------------------

- (IBAction)save_button_action:(id)sender
{
    @try {
      [[UIApplication sharedApplication] cancelAllLocalNotifications];
    
    NSString *rawString = [_name_textfield text];
    NSCharacterSet *whitespace = [NSCharacterSet whitespaceAndNewlineCharacterSet];
    NSString *trimmed = [rawString stringByTrimmingCharactersInSet:whitespace];
    
    NSString *rawString1 = [_pin_textfield text];
    NSCharacterSet *whitespace1 = [NSCharacterSet whitespaceAndNewlineCharacterSet];
    NSString *trimmed1 = [rawString1 stringByTrimmingCharactersInSet:whitespace1];
    
    NSString *rawString2 = [_start_date_text text];
    NSCharacterSet *whitespace2 = [NSCharacterSet whitespaceAndNewlineCharacterSet];
    NSString *trimmed2 = [rawString2 stringByTrimmingCharactersInSet:whitespace2];
    
    NSString *rawString3 = [pill_qua_text text];
    NSCharacterSet *whitespace3 = [NSCharacterSet whitespaceAndNewlineCharacterSet];
    NSString *trimmed3 = [rawString3 stringByTrimmingCharactersInSet:whitespace3];
    
    
    
    if([trimmed length] == 0)
    {
        
        [appDelegate.window makeToast:@"Name Empty" duration:1.0 position:@"center"];
        
    }else if (trimmed1.length <= 3)
    {
        [appDelegate.window makeToast:@"Enter 4 digit Pin" duration:1.0 position:@"center"];
        
    }else if ([trimmed2 length]== 0)
    {
        
        [appDelegate.window makeToast:@"Start Date Empty" duration:1.0 position:@"center"];
        
    }else if ([trimmed3 length]== 0)
    {
        
        [appDelegate.window makeToast:@"Pill count Empty" duration:1.0 position:@"center"];
        
    }else
    {
        
        NSMutableDictionary *dic=[[NSMutableDictionary alloc ]init];
        
        
     //   NSString *TimeStr = self.txtMedicineTime.text;
        
        NSString *DateStr = _start_date_text.text;
        
        
        [dic setObject:_name_textfield.text forKey:@"NAME"];
        
        [dic setObject:_pin_textfield.text forKey:@"PIN"];
        
        [dic setObject:DateStr forKey:@"STARTDATE"];
        
        [dic setObject:pill_qua_text.text forKey:@"PILLCOUNT"];
        
        [dic setObject:_txtMedicineTime.text forKey:@"PILLTIME"];
        NSMutableArray  *Array=[[NSMutableArray alloc]init];
        
        [Array addObject:dic];
        
        
        
        
        
        
        if ([UserDateArray count]>0)
        {
            [dbh UserUpdate:Array];
            
            [self updateDate];
            
        }
        else
        {
            [dbh insertUser:Array];
            
            [self updateDate];
            
        }
        
        [self disableNotification:@"Please Take Your Medicine"];
        NSDateFormatter *dateFormat1=[[NSDateFormatter alloc]init];
        [dateFormat1 setDateFormat:@"dd-MM-yyyy"];
        NSDate *currentDate=[[NSDate alloc]init];
        NSString *strCurrentDate=[dateFormat1 stringFromDate:currentDate];
        strCurrentDate =[strCurrentDate stringByAppendingString:@" "];
        strCurrentDate =[strCurrentDate stringByAppendingString:_txtMedicineTime.text];
        dateFormat1=[[NSDateFormatter alloc]init];
        [dateFormat1 setDateFormat:@"dd-MM-yyyy hh:mm a"];
        NSDate *notificationDate=[dateFormat1 dateFromString:strCurrentDate];
        
        [self enableNotification:notificationDate alertBody:@"Please Take Your Medicine"];
//        UILocalNotification* localNotification = [[UILocalNotification alloc] init];
//        localNotification.fireDate = [_Date_picker date];
//        localNotification.alertBody = @"Please Take Your Medicine";
//        localNotification.timeZone = [NSTimeZone systemTimeZone];
//        [[UIApplication sharedApplication] scheduleLocalNotification:localNotification];
       
        
        UDSetObject(notificationDate, @"Fire_Date");
        NSString *initialPillCount=pill_qua_text.text;
        UDSetObject(initialPillCount, @"initialCount");
        UDSetObject(DateStr, @"lastPillTakenDate");
       
        
        
        
        
        DashBoardViewController *objDashBoardViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"DashBoardViewController"];
        
        [self.navigationController pushViewController:objDashBoardViewController animated:YES];
       
    
        //  [self.navigationController popViewControllerAnimated:YES];
        
    }
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }

}

//------------------------------------------------------------

- (IBAction)back_button_action:(id)sender
{
     [self.navigationController popViewControllerAnimated:YES];
}
//------------------------------------------------------------

- (IBAction)Done_Pick_button:(id)sender
{
    if (self.isDate == YES) {

     NSDate *date = [_Date_picker date];
     NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];

   
  [dateFormat setDateFormat:@"MM-dd-yy"];
     _start_date_text.text = [dateFormat stringFromDate:date];
    
    NSString *strDefault=[dateFormat stringFromDate:date];
    [[NSUserDefaults standardUserDefaults]setObject:strDefault forKey:@"DateTemp"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    Date_view.hidden=YES;
    
    CGPoint point = CGPointMake(0,0);
    [_main_scroll setContentOffset:point animated:YES] ;
    }
    else {

    NSDate *date = [_Date_picker date];
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    
    
    [dateFormat setDateFormat:@"hh:mm a"];
    self.txtMedicineTime.text = [dateFormat stringFromDate:date];
    
    Date_view.hidden=YES;
    
    CGPoint point = CGPointMake(0,0);
    [_main_scroll setContentOffset:point animated:YES] ;
    }
}

//------------------------------------------------------------

- (IBAction)cancel_Pick_button:(id)sender
{
    _start_date_text.text=@"";
    
    
    Date_view.hidden=YES;
    
    CGPoint point = CGPointMake(0,0);
    [_main_scroll setContentOffset:point animated:YES] ;
    

}

//------------------------------------------------------------


-(void)enableNotification:(NSDate *)date alertBody:(NSString *)title
{
    UILocalNotification* localNotification = [[UILocalNotification alloc] init];
    localNotification.fireDate = date;
    localNotification.alertBody = title;
    localNotification.soundName=UILocalNotificationDefaultSoundName;
    [[UIApplication sharedApplication] scheduleLocalNotification:localNotification];
    NSLog(@"%@",localNotification);

}



-(void)disableNotification:(NSString*)alertBodyTitle
{
    NSArray *arrayOfLocalNotifications = [[UIApplication sharedApplication] scheduledLocalNotifications] ;
    
    for (UILocalNotification *localNotification in arrayOfLocalNotifications)
    {
        if ([localNotification.alertBody isEqualToString:alertBodyTitle])
        {
            NSLog(@"the notification this is canceld is %@", localNotification.alertBody);
            
            [[UIApplication sharedApplication] cancelLocalNotification:localNotification] ;
            // delete the notification from the system
        }
    }
}

-(void)disableNotificationAppoint:(NSDate *)DateVisit
{
    NSArray *arrayOfLocalNotifications = [[UIApplication sharedApplication] scheduledLocalNotifications] ;
    
    for (UILocalNotification *localNotification in arrayOfLocalNotifications)
    {
        if ([localNotification.fireDate isEqualToDate:DateVisit])
        {
            NSLog(@"the notification this is canceld is %@", localNotification.alertBody);
            
            [[UIApplication sharedApplication] cancelLocalNotification:localNotification] ;
            // delete the notification from the system
        }
    }
}


@end
