//
//  AddAppointmentViewController.h
//  PrEP
//
//  Created by Bhushan on 5/13/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import "ViewController.h"

@interface AddAppointmentViewController : ViewController  <UITableViewDataSource,UITableViewDelegate>
{
    NSMutableArray  *addArray;
    NSMutableArray  *addApoinmentTitleArray;
   
    NSString *timeStr;
}
@property (strong, nonatomic) IBOutlet UIButton *btnSaveAddAppoint;
@property (weak, nonatomic) IBOutlet UITextField *addSetTitleTextFild;
@property (weak, nonatomic) IBOutlet UITableView *addApoinmentTableView;
@property (weak, nonatomic) IBOutlet UIView *addApoinmentTitleView;

@property (strong, nonatomic) IBOutlet UIScrollView *main_scroll_view;

@property (strong, nonatomic) IBOutlet UITextField *title_text;

@property (strong, nonatomic) IBOutlet UITextField *desc_text;
@property (weak, nonatomic) IBOutlet UIButton *add_appButton;

@property (strong, nonatomic) IBOutlet UITextField *date_text;

@property (strong, nonatomic) IBOutlet UIView *dateview;
@property (strong, nonatomic) UIDatePicker *date_picker;
@property (strong, nonatomic) IBOutlet UIView *save_view;

@property (strong, nonatomic) IBOutlet UITextField *txtTime;

@property (nonatomic) BOOL isdate;

- (IBAction)save_button_action:(id)sender;
- (IBAction)back_button_action:(id)sender;

- (IBAction)dash_Tabbutton_action:(id)sender;
- (IBAction)notification_Tabbutton_action:(id)sender;
- (IBAction)cal_Tab_button_action:(id)sender;

- (IBAction)setting_Tab_button_action:(id)sender;
- (IBAction)date_cancel_button_action:(id)sender;
- (IBAction)date_done_button_action:(id)sender;

- (IBAction)add_app_buttona_action:(id)sender;
-(void)addAppMethod;

- (IBAction)task_tab_button_action:(id)sender;



@end
