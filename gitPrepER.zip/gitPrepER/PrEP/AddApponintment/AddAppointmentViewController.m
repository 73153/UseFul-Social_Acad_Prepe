//
//  AddAppointmentViewController.m
//  PrEP
//
//  Created by Bhushan on 5/13/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import "AddAppointmentViewController.h"
#import "AddApoinmentCell.h"
#import <QuartzCore/QuartzCore.h>

@interface AddAppointmentViewController ()
{
    DataBase *dbh;
}

@end

@implementation AddAppointmentViewController
@synthesize addApoinmentTableView;
- (void)viewDidLoad
{
    @try {
       [super viewDidLoad];
        
self.date_picker = [[UIDatePicker alloc] initWithFrame:CGRectMake(0, 44, self.view.frame.size.width,198)];
    self.date_picker.datePickerMode = UIDatePickerModeDate;
    [self.dateview addSubview:self.date_picker];

   addArray=[[NSMutableArray alloc]init];
   dbh=[[DataBase alloc]init];
    addApoinmentTitleArray=[[NSMutableArray alloc] initWithObjects:@"1 Month Vist",@"3 Month Vist",@"6 Month Vist",@"other", nil];
    [_addApoinmentTitleView setHidden:YES];
    
    
#pragma textfield layout
    [_btnSaveAddAppoint initWithBorders];
    
    
    CALayer *border = [CALayer layer];
    CGFloat borderWidth = 2;
    border.borderColor = [UIColor darkGrayColor].CGColor;
    border.frame = CGRectMake(0, _addSetTitleTextFild.frame.size.height - borderWidth, _addSetTitleTextFild.frame.size.width, _addSetTitleTextFild.frame.size.height);
    border.borderWidth = borderWidth;
    [_addSetTitleTextFild.layer addSublayer:border];
    _addSetTitleTextFild.layer.masksToBounds = YES;
    
    [_title_text initTextFieldStyle];
    [_desc_text initTextFieldStyle];
    [_date_text initTextFieldStyle];
    [_txtTime initTextFieldStyle];
    _addSetTitleTextFild.text = @"1 Month Visit";
    
    }  @catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


- (IBAction)save_button_action:(id)sender
{
    @try{
    NSString *rawString = [_title_text text];
    NSCharacterSet *whitespace = [NSCharacterSet whitespaceAndNewlineCharacterSet];
    NSString *trimmed = [rawString stringByTrimmingCharactersInSet:whitespace];
    
    
    NSString *rawString4 = [_addSetTitleTextFild text];
    NSCharacterSet *whitespace4 = [NSCharacterSet whitespaceAndNewlineCharacterSet];
    NSString *trimmed4 = [rawString4 stringByTrimmingCharactersInSet:whitespace4];

    
    NSString *rawString1 = [_desc_text text];
    NSCharacterSet *whitespace1 = [NSCharacterSet whitespaceAndNewlineCharacterSet];
    NSString *trimmed1 = [rawString1 stringByTrimmingCharactersInSet:whitespace1];
    
    NSString *rawString2 = [_date_text text];
    NSCharacterSet *whitespace2 = [NSCharacterSet whitespaceAndNewlineCharacterSet];
    NSString *trimmed2 = [rawString2 stringByTrimmingCharactersInSet:whitespace2];
    
    NSString *rawString5 = [_txtTime text];
    NSCharacterSet *whitespace5 = [NSCharacterSet whitespaceAndNewlineCharacterSet];
    NSString *trimmed5 = [rawString5 stringByTrimmingCharactersInSet:whitespace5];
    
    
     if ([trimmed1 length] == 0)
    {
        [appDelegate.window makeToast:@"Description Empty" duration:1.0 position:@"center"];
        
    }else if ([trimmed2 length]== 0)
    {
        
        [appDelegate.window makeToast:@"Date Empty" duration:1.0 position:@"center"];
        
    } else if ([trimmed4 isEqualToString:@"other"])
    {
        if ([trimmed length] == 0)
        {
             [appDelegate.window makeToast:@"Title Empty" duration:1.0 position:@"center"];
            
        }else
        {
            [self addAppMethod];
            
        }
 
    } else if ([trimmed5 length]==0)
    {
        [appDelegate.window makeToast:@"Time Empty" duration:1.0 position:@"center"];
    }
    
    else
    {
         [self addAppMethod];

    }
    
    
    
    }  @catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}


- (IBAction)back_button_action:(id)sender
{
    
    [self.navigationController popViewControllerAnimated:YES];
    
}

- (IBAction)dash_Tabbutton_action:(id)sender
{
    @try{
    int index = 0;
    for (UIViewController *vc in self.navigationController.viewControllers) {
        if ([vc isKindOfClass:[DashBoardViewController class]]) {
            [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:index] animated:YES];
            return;
        }
        index++;
    }
    DashBoardViewController *objDashBoardViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"DashBoardViewController"];
    [self.navigationController pushViewController:objDashBoardViewController animated:NO];
    
    }  @catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}


- (IBAction)notification_Tabbutton_action:(id)sender
{
    @try{
    int index = 0;
    for (UIViewController *vc in self.navigationController.viewControllers) {
        if ([vc isKindOfClass:[NotificationViewController class]]) {
            [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:index] animated:YES];
            return;
        }
        index++;
    }
    NotificationViewController *objNotificationViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"NotificationViewController"];
    [self.navigationController pushViewController:objNotificationViewController animated:NO];
    }  @catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}




- (IBAction)cal_Tab_button_action:(id)sender
{
    @try{
    int index = 0;
    for (UIViewController *vc in self.navigationController.viewControllers) {
        if ([vc isKindOfClass:[CalViewController class]]) {
            [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:index] animated:YES];
            return;
        }
        index++;
    }
    CalViewController *objCalViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"CalViewController"];
    [self.navigationController pushViewController:objCalViewController animated:YES];
    
    }  @catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}


- (IBAction)setting_Tab_button_action:(id)sender
{
    @try{
//    int index = 0;
//    for (UIViewController *vc in self.navigationController.viewControllers) {
//        if ([vc isKindOfClass:[SettingViewController class]]) {
//            [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:index] animated:YES];
//            return;
//        }
//        index++;
//    }
    SettingViewController *objSettingViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"SettingViewController"];
    [self.navigationController pushViewController:objSettingViewController animated:NO];
    }  @catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}




- (IBAction)date_cancel_button_action:(id)sender
{
    _dateview.hidden=YES;
    
    CGPoint point = CGPointMake(0,0);
    [_main_scroll_view setContentOffset:point animated:YES] ;
}


- (IBAction)date_done_button_action:(id)sender
{@try{
    if(self.isdate==YES)
    {
       NSDate *date = [_date_picker date];
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
  //  NSTimeZone *gmt = [NSTimeZone systemTimeZone];
   // [dateFormat setTimeZone:[NSTimeZone systemTimeZone]];
    [dateFormat setDateFormat:@"MM-dd-yy"];
    _date_text.text = [dateFormat stringFromDate:date];

    _dateview.hidden=YES;
    
    CGPoint point = CGPointMake(0,0);
    [_main_scroll_view setContentOffset:point animated:YES] ;
    }
    else
    {
        NSDateFormatter *dateFormat1 = [[NSDateFormatter alloc] init];
        
        NSDate *date = [_date_picker date];

        [dateFormat1 setDateFormat:@"hh:mm a"];
        
        timeStr=[dateFormat1 stringFromDate:date];
        _txtTime.text=timeStr;
        _dateview.hidden=YES;
        
        CGPoint point = CGPointMake(0,0);
        [_main_scroll_view setContentOffset:point animated:YES] ;
    }
}  @catch(NSException *exception){
    NSLog(@"%@",exception.description);
}
    
}


- (IBAction)add_app_buttona_action:(id)sender
{
    
//    NSLog(@"myUIView origin=%@", NSStringFromCGPoint(_save_view.frame.origin));
//    
//     CGRect frame = _save_view.frame;
//  
//    int ypos=frame.origin.y;
//    
//    ypos= ypos+40;
    
    [_addApoinmentTitleView setHidden:NO];
    
}



#pragma mark textViewDidBeginEditing-----------------------------------------------------

static NSInteger stepRange1[] = {
    
    0,0,90,150,170
};



static NSInteger getScrollPos21(NSInteger i) {
    
    if (i < 1 || i > 4)
        return 0 ;
    return stepRange1[i] ;
}

static NSInteger stepRange[] = {
    
    0,0,90,150,170
};



static NSInteger getScrollPos2(NSInteger i) {
    
    if (i < 1 || i > 3)
        return 0 ;
    return stepRange[i] ;
}


- (void)textViewDidBeginEditing:(UITextView *)textView
{
    
    
    _main_scroll_view.scrollEnabled = YES;
    CGPoint point = CGPointMake(0,700);
    [_main_scroll_view setContentOffset:point animated:YES] ;
    
}

- (void) textFieldDidBeginEditing:(UITextField *)textField
{
    
    if (textField.tag==3)
    {
        _dateview.hidden=NO;
        
        
        [textField resignFirstResponder];
        [_title_text resignFirstResponder];
        
        [_desc_text resignFirstResponder];
        [_date_text resignFirstResponder];
        
        CGPoint point;
        
        point = CGPointMake(0, getScrollPos21(textField.tag));
        [_main_scroll_view setContentOffset:point animated:YES] ;
        
        
    }
    else
    {
         _dateview.hidden=YES;
        
        _main_scroll_view.scrollEnabled = YES;
        
        
        CGPoint point;
        
        if (IS_IPHONE5)
            point = CGPointMake(0, getScrollPos21(textField.tag));
        else
            point = CGPointMake(0, getScrollPos2(textField.tag));
        
        
        [_main_scroll_view setContentOffset:point animated:YES] ;
        
    }
    
    
}

-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if (textField.tag==3)
    {
        [self setDateLimit];
        _dateview.hidden=NO;
        self.isdate=YES;
         _date_picker.datePickerMode=UIDatePickerModeDate;
        [textField resignFirstResponder];
        [_title_text resignFirstResponder];
        
        [_desc_text resignFirstResponder];
        [_date_text resignFirstResponder];
        
        CGPoint point;
        
        point = CGPointMake(0, getScrollPos21(textField.tag));
        [_main_scroll_view setContentOffset:point animated:YES] ;
        
        return NO;
    }
    else if (textField.tag==4)
    {
        self.isdate=NO;
        self.date_picker.datePickerMode = UIDatePickerModeTime;
        _dateview.hidden=NO;
        
        [textField resignFirstResponder];
        [_title_text resignFirstResponder];
        
        [_desc_text resignFirstResponder];
        [_date_text resignFirstResponder];
        
        CGPoint point;
        
        point = CGPointMake(0, getScrollPos21(textField.tag));
        [_main_scroll_view setContentOffset:point animated:YES] ;
        
        return NO;
    }
    else
    {
        return YES;
    }
}


- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    _main_scroll_view.scrollEnabled = YES;
    
    
    
    NSInteger nextTag = textField.tag + 1;
    UIResponder* nextResponder = [textField.superview viewWithTag:nextTag];
    
    if (nextResponder)
    {
        if (nextTag==3)
        {
            
            _dateview.hidden=NO;
            
            CGPoint point = CGPointMake(0, getScrollPos2(nextTag));
            [_main_scroll_view setContentOffset:point animated:YES];
            
            [_title_text resignFirstResponder];
            
            [_desc_text resignFirstResponder];
            [_date_text resignFirstResponder];
            
            [textField resignFirstResponder];
        }
        else{
            
            [nextResponder becomeFirstResponder];
            CGPoint point = CGPointMake(0, getScrollPos2(nextTag));
            [_main_scroll_view setContentOffset:point animated:YES];
        }
        
    }
    else
    {
        CGPoint point = CGPointMake(0,64);
        [_main_scroll_view setContentOffset:point animated:YES] ;
        [textField resignFirstResponder];
        
        
        
        
    }
    
    return YES;
}

-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
     
    return YES;
}






#pragma mark -table view dat sources

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1 ;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    @try{
    return [addApoinmentTitleArray count];
        
    }  @catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}


- (UITableViewCell *)tableView:(UITableView *)tv cellForRowAtIndexPath:(NSIndexPath*)indexPath {
    @try{
    static NSString *CellIdentifier = @"celll";
    AddApoinmentCell *cell = [addApoinmentTableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    // NOTE: Add some code like this to create a new cell if there are none to reuse
    if(cell == nil)
    {
        cell = [[AddApoinmentCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        
    }
    
    NSString *string = [addApoinmentTitleArray objectAtIndex:indexPath.row];
    
    cell.textLabel.text = string;
    NSLog(@"%@",string);
    return cell;
    }  @catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    @try{
    NSString *str1 = [addApoinmentTitleArray objectAtIndex:indexPath.row];
    
    if (![str1 isEqualToString:@"other"]) {
        _addSetTitleTextFild.text=str1;
        _save_view.frame=CGRectMake(0, 80, 320, 294);
    }else
    {
       _addSetTitleTextFild.text=str1;
        _save_view.frame=CGRectMake(0, 115, 320, 294);
    }
    
    
    [_addApoinmentTitleView setHidden:YES];
    
    }  @catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}


-(void)addAppMethod
{
    NSMutableDictionary *dic=[[NSMutableDictionary alloc ]init];
    
    
    //("DATE" VARCHAR,"ISCOMPLETED" INTEGER DEFAULT (null) ,"USERID" INTEGER,"TITLE" VARCHAR,"DESC" VARCHAR, "ID" INTEGER, "TIME" VARCHAR, "ISCONFORM" INTEGER)
    
    
    [dic setObject:@"1" forKey:@"USERID"];
    
    [dic setObject:_desc_text.text forKey:@"DESC"];
    
    NSString *TitleStr=_addSetTitleTextFild.text;
    
    if ([TitleStr isEqualToString:@"other"])
    {
        [dic setObject:_title_text.text forKey:@"TITLE"];
        [dic setObject:@"1" forKey:@"ISCONFORM"];
    }else{
        [dic setObject:_addSetTitleTextFild.text forKey:@"TITLE"];
        [dic setObject:@"1" forKey:@"ISCONFORM"];
    }
    [dic setObject:_date_text.text forKey:@"DATE"];
    
    [dic setObject:@"1" forKey:@"ISCOMPLETED"];
    
    [dic setObject:appDelegate.Increment_Id_App_Str forKey:@"ID"];
    
    [dic setObject:timeStr forKey:@"TIME"];
    
    
    [addArray addObject:dic];
    
    
    if ([addArray count]>0)
    {
        
        NSString *strDate=_date_text.text;
        NSDateFormatter *formattr=[[NSDateFormatter alloc]init];
        [formattr setDateFormat:@"MM-dd-yy"];
        NSDate *notiDate=[formattr dateFromString:strDate];
        NSDate *threeDaysAgo = [notiDate dateByAddingTimeInterval:-3*24*60*60];
        [formattr setDateFormat:@"dd-MM-yyyy"];
        strDate =[formattr stringFromDate:threeDaysAgo];
        NSString *strTime=_txtTime.text;
        strDate =[strDate stringByAppendingString:@" "];
        strDate =[strDate stringByAppendingString:strTime];
        [formattr setDateFormat:@"dd-MM-yyyy hh:mm a"];
        NSDate *apointNotification=[formattr dateFromString:strDate];
        [self enableNotification:apointNotification alertBody:_addSetTitleTextFild.text];
        
        [dbh AddAppointment:addArray];
        
        int index = 0;
        for (UIViewController *vc in self.navigationController.viewControllers) {
            if ([vc isKindOfClass:[CalViewController class]])
            {
                [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:index] animated:YES];
                return;
            }
            index++;
        }
        CalViewController *objCalViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"CalViewController"];
        [self.navigationController pushViewController:objCalViewController animated:NO];
        
    }
    
    
    
    
}

- (IBAction)task_tab_button_action:(id)sender {
    int index = 0;
    for (UIViewController *vc in self.navigationController.viewControllers) {
        if ([vc isKindOfClass:[AppointmentViewController class]]) {
            [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:index] animated:NO];
            return;
        }
        index++;
    }
    AppointmentViewController *objAppointmentViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"AppointmentViewController"];    
    [self.navigationController pushViewController:objAppointmentViewController animated:NO];
}

-(void)enableNotification:(NSDate *)date alertBody:(NSString *)title
{
    UILocalNotification* localNotification = [[UILocalNotification alloc] init];
    localNotification.fireDate = date;
    localNotification.alertBody = title;
    localNotification.soundName=UILocalNotificationDefaultSoundName;
    [[UIApplication sharedApplication] scheduleLocalNotification:localNotification];
}


-(void)setDateLimit
{
    NSCalendar *calendar = [[NSCalendar alloc] initWithCalendarIdentifier:NSGregorianCalendar];
    NSDate *currentDate = [NSDate date];
    NSDateComponents *comps = [[NSDateComponents alloc] init];
    [comps setYear:30];
    NSDate *maxDate = [calendar dateByAddingComponents:comps toDate:currentDate options:0];
    NSDate *minDate = currentDate;
    
    [_date_picker setMaximumDate:maxDate];
    [_date_picker setMinimumDate:minDate];
}
@end
