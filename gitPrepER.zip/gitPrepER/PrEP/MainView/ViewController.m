
//
//  ViewController.m
//  PrEP
//
//  Created by Bhushan on 5/1/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import "ViewController.h"

#define MAX_LENGTH 4
#define NUMBERS_ONLY 12345667890

@interface ViewController ()
{
    NSMutableArray *UserDateArraya;
}

@end

@implementation ViewController

- (void)viewDidLoad
{
    @try{
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    
     dbh=[[DataBase alloc]init];
    
      PinviewFlage=NO;
    
      UserDateArraya=[[NSMutableArray alloc]init];
    
    
    
      UserDateArraya=[dbh selectAllUser];

    
    
    
    if ([UserDateArraya count]>0)
    {//PIN,STARTDATE
        
        _enter_pin_view.hidden=NO;
        
    }

    
    //About_button shadow set
    _about_button.layer.shadowColor = [UIColor blackColor].CGColor;
    _about_button.layer.shadowOpacity = 0.5;
    _about_button.layer.shadowRadius = 5;
    _about_button.layer.shadowOffset = CGSizeMake(3.0f,3.0f);
    _about_button.layer.cornerRadius = 5;
    
    //Point button shadow set
    _points_button.layer.shadowColor = [UIColor blackColor].CGColor;
    _points_button.layer.shadowOpacity = 0.5;
    _points_button.layer.shadowRadius = 5;
    _points_button.layer.shadowOffset = CGSizeMake(3.0f,3.0f);
    _points_button.layer.cornerRadius = 5;
    
    
    //Setup Button shadow ser
    _setup_button.layer.shadowColor = [UIColor blackColor].CGColor;
    _setup_button.layer.shadowOpacity = 0.5;
    _setup_button.layer.shadowRadius = 5;
    _setup_button.layer.shadowOffset = CGSizeMake(3.0f,3.0f);
    _setup_button.layer.cornerRadius = 5;

    
    [_enter_pin_view.layer setCornerRadius:5.0f];
    
    // border
    [_enter_pin_view.layer setBorderColor:[UIColor lightGrayColor].CGColor];
    [_enter_pin_view.layer setBorderWidth:1.5f];
    
    // drop shadow
    [_enter_pin_view.layer setShadowColor:[UIColor blackColor].CGColor];
    [_enter_pin_view.layer setShadowOpacity:0.8];
    [_enter_pin_view.layer setShadowRadius:3.0];
    [_enter_pin_view.layer setShadowOffset:CGSizeMake(2.0, 2.0)];
    
    //pin_text_field
    
    [_btnEdit initWithBorders];
    [_btnEnterPinHere initWithBorders];
    [_btnGo initWithBorders];
    [_btnProcess initWithBorders];
    
    [_pin_text_field.layer setCornerRadius:2.0f];
    
    // border
    [_pin_text_field.layer setBorderColor:[UIColor lightGrayColor].CGColor];
    [_pin_text_field.layer setBorderWidth:2.5f];
    
    // drop shadow
    [_pin_text_field.layer setShadowColor:[UIColor blackColor].CGColor];
    [_pin_text_field.layer setShadowOpacity:0.8];
    [_pin_text_field.layer setShadowRadius:3.0];
    [_pin_text_field.layer setShadowOffset:CGSizeMake(2.0, 2.0)];
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
 
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}




- (IBAction)go_button_action:(id)sender
{
    @try {
           UserDateArray=[dbh selectAllUser];
    
    if ([UserDateArray count]>0)
    {
        
        PinStr=[[UserDateArray objectAtIndex:0] objectForKey:@"PIN"];
        appDelegate.Pill_countStr=[[UserDateArray objectAtIndex:0] objectForKey:@"PILLCOUNT"];
        
        if ([PinStr isEqualToString:newStringPin])
            
        {
            //Navigation To Dash board----->
            
            
            DashBoardViewController *objDashBoardViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"DashBoardViewController"];
            
            [self.navigationController pushViewController:objDashBoardViewController animated:YES];
            
            
            
            
            _enter_pin_view.hidden=YES;
            
            _pin_text_field.text=@"";
           
        }
        else
        {
             [appDelegate.window makeToast:@"Please Enter currect pin number " duration:1.0 position:@"Center"];
            
        }
        
    }else
    {
        
        [appDelegate.window makeToast:@"Please set appointment date" duration:1.0 position:@"Center"];
        
    }
    
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
 
}

- (IBAction)Edit_button_action:(id)sender
{@try{
    int index = 0;
    for (UIViewController *vc in self.navigationController.viewControllers) {
        if ([vc isKindOfClass:[SteupViewController class]]) {
            [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:index] animated:NO];
            return;
        }
        index++;
    }
    SteupViewController *objSteupViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"SteupViewController"];
    [self.navigationController pushViewController:objSteupViewController animated:NO];
}@catch(NSException *exception){
    NSLog(@"%@",exception.description);
}

}



#pragma mark Aout button action


- (IBAction)about_button_Action:(id)sender
{
    NSString*myurl=@"http://www.cdc.gov/hiv/basics/prep.html.";
    NSURL *url = [NSURL URLWithString:myurl];
  [[UIApplication sharedApplication] openURL:url];
    
}
//-----------------------------------------------------------------------------------------------------------------------

#pragma mark Aout button action
- (IBAction)point_button_action:(id)sender
{
    
    NSString*myurl=@"http://www.cdc.gov";
    NSURL *url = [NSURL URLWithString:myurl];
    [[UIApplication sharedApplication] openURL:url];
}

//-----------------------------------------------------------------------------------------------------------------------


#pragma mark Aout button action
- (IBAction)Setup_button_Action:(id)sender
{
    @try {
       int index = 0;
    for (UIViewController *vc in self.navigationController.viewControllers) {
        if ([vc isKindOfClass:[SteupViewController class]]) {
            [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:index] animated:NO];
            return;
        }
        index++;
    }
    SteupViewController *objSteupViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"SteupViewController"];
    [self.navigationController pushViewController:objSteupViewController animated:NO];
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }

    }
    


//-----------------------------------------------------------------------------------------------------------------------

- (IBAction)process_button_Active:(id)sender
{
    @try{
    if(PinviewFlage==YES)
    {
       
        _enter_pin_view.hidden=YES;
        PinviewFlage=NO;
        
        
    }else
    {
        _enter_pin_view.hidden=NO;
        PinviewFlage=YES;
    }
    
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}


- (void) textFieldDidBeginEditing:(UITextField *)textField
{
    
    NSLog(@"Old Frame %@", NSStringFromCGRect(_enter_pin_view.frame));
    
    if (IS_IPHONE4)
    {
      
        
        _enter_pin_view.frame=CGRectMake(9, 60, 302, 230);
    }
    
   
    
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    
    [textField resignFirstResponder];
    
    if (IS_IPHONE4)
    {
        _enter_pin_view.frame=CGRectMake(9, 150, 302, 230);
    }
    
        
        
    return YES;
    
}
-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    
    newStringPin = [textField.text stringByReplacingCharactersInRange:range withString:string];
    
    if (newStringPin.length==4)
    {
        [self go_button_action:self];
    }
    
    
    NSUInteger newLength = [textField.text length] + [string length] - range.length;
    
    NSCharacterSet *cs = [[NSCharacterSet characterSetWithCharactersInString:@"0123456789"] invertedSet];
    
    NSString *filtered = [[string componentsSeparatedByCharactersInSet:cs] componentsJoinedByString:@""];
    
    while (newLength < MAX_LENGTH)
    {
        return [string isEqualToString:filtered];
    }
    
    /* Limits the no of characters to be enter in text field */
    
    return (newLength > MAX_LENGTH ) ? NO : YES;
    
}

@end
