//
//  DataBase.m
//  PrEP
//
//  Created by Bhushan on 5/5/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import "DataBase.h"

@implementation DataBase

#pragma mark Select user Details.....

-(NSMutableArray *)selectAllUser
{
    @try{
    
    NSMutableArray *data=[[NSMutableArray alloc]init];
    NSMutableDictionary *dict;
    if(sqlite3_open([appDelegate.dbpath UTF8String],&db) == SQLITE_OK)
    {
        
        
        query=@"select * from USER_INFO ";
        
        
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, nil)==SQLITE_OK)
        {
            
            while(sqlite3_step(stm)==SQLITE_ROW)
            {
                
                
                dict=[[NSMutableDictionary alloc]init];
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 0)] forKey:@"NAME"];
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 1)] forKey:@"PIN"];
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 3)] forKey:@"STARTDATE"];
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 2)] forKey:@"PILLCOUNT"];
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 4)] forKey:@"PILLTIME"];
                
                [data addObject:dict];
                NSLog(@"%@",data);
                      
            }
            sqlite3_finalize(stm);
        }
        // }
        sqlite3_close(db);
    }
    
    return data;
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}


#pragma mark Insert user Details.....

-(BOOL)insertUser:(NSArray *)dealArray
{
    @try{
    NSLog(@"%@",dealArray);
    
    BOOL isok=NO;
    
    sqlite3_stmt    *statement5;
    
    
    
    if(sqlite3_open([appDelegate.dbpath UTF8String],&db) == SQLITE_OK)
    {
        for (int i = 0; i<[dealArray count];i++)
        {
            
           query = [NSString stringWithFormat: @"INSERT INTO USER_INFO (NAME,PIN,PILLCOUNT,STARTDATE,PILLTIME) VALUES ('%@','%@','%@','%@','%@')",[[dealArray objectAtIndex:i]objectForKey:@"NAME"],[[dealArray objectAtIndex:i]objectForKey:@"PIN"],[[dealArray objectAtIndex:i]objectForKey:@"PILLCOUNT"],[[dealArray objectAtIndex:i]objectForKey:@"STARTDATE"],[[dealArray objectAtIndex:i]objectForKey:@"PILLTIME"]];
            
            const char *insert_stmt = [query UTF8String];
            
            sqlite3_prepare_v2(db, insert_stmt, -1, &statement5, NULL);
            if (sqlite3_step(statement5) == SQLITE_DONE)
            {
                NSLog(@"Data Deals---->");
                
            } else {
                
            }
            sqlite3_finalize(statement5);
        }
        sqlite3_close(db);
    }
    return isok;
    
    
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}

#pragma mark Update user

-(BOOL)UserUpdate:(NSArray*)Array
{@try{
    BOOL isok=NO;
    
    NSLog(@"%@",Array);
    
    
     NSString *NameStr=[[Array objectAtIndex:0] objectForKey:@"NAME"];
     NSString *PinStr=[[Array objectAtIndex:0] objectForKey:@"PIN"];
     NSString *StartDateStr=[[Array objectAtIndex:0] objectForKey:@"STARTDATE"];
     NSString *PILLCOUNTStr=[[Array objectAtIndex:0] objectForKey:@"PILLCOUNT"];
     NSString *PILLTIMEStr=[[Array objectAtIndex:0] objectForKey:@"PILLTIME"];
    
    
    query=[NSString stringWithFormat:@"UPDATE USER_INFO SET PIN='%@',STARTDATE='%@',PILLCOUNT='%@',PILLTIME='%@' WHERE NAME ='%@'",PinStr,StartDateStr,PILLCOUNTStr,PILLTIMEStr,NameStr];
    
    NSLog(@"%@",query);
    
    if(sqlite3_open([appDelegate.dbpath UTF8String], &db)==SQLITE_OK)
    {
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, NULL)==SQLITE_OK)
        {
            sqlite3_step(stm);
            isok=YES;
            
        }
        sqlite3_finalize(stm);
    }
    
    if (isok==YES)
    {
         [appDelegate.window makeToast:@"Successfully updated" duration:1.0 position:@"center"];
        
    }else
    {
        //Update user not in datebase then insert new user
        
        [self insertUser:Array];
    }
    
    sqlite3_close(db);
    
    return isok;

   
}@catch(NSException *exception){
    NSLog(@"%@",exception.description);
}
    
}

#pragma mark Slect All Appintment.....

//-(NSMutableArray*)AppointmentSelect_IsCompleted{
//    
//    
//    NSMutableArray *data=[[NSMutableArray alloc]init];
//    NSMutableDictionary *dict;
//    if(sqlite3_open([appDelegate.dbpath UTF8String],&db) == SQLITE_OK)
//    {
//        
//        query=@"select * from APPOITMENTS WHERE ISCOMPLETED='0' ORDER BY DATE DESC";
//        
//        
//        sqlite3_stmt *stm;
//        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, nil)==SQLITE_OK)
//        {
//            
//            while(sqlite3_step(stm)==SQLITE_ROW)
//            {
//                
//                
//                dict=[[NSMutableDictionary alloc]init];
//                
//                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 0)] forKey:@"DATE"];
//                
//                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 3)] forKey:@"TITLE"];
//                
//               
//                
//                
//                [data addObject:dict];
//                NSLog(@"%@",data);
//                
//                
//            }
//            sqlite3_finalize(stm);
//        }
//        // }
//        sqlite3_close(db);
//    }
//    
//    return data;
//    
//    
//    
//    
//    
//    
//}

#pragma mark Upconning Appointment...

-(NSMutableArray*)AppointmentSelect_upcomming
{
    @try{
    NSDateFormatter *DateFormatter=[[NSDateFormatter alloc] init];
    [DateFormatter setDateFormat:@"MM-dd-yy"];
   //  NSString *DateStr=[DateFormatter stringFromDate:[NSDate date]];
    
   
    
    NSMutableArray *data=[[NSMutableArray alloc]init];
    NSMutableDictionary *dict;
    if(sqlite3_open([appDelegate.dbpath UTF8String],&db) == SQLITE_OK)
    {
        
      //  query=[NSString stringWithFormat:@"select * from APPOITMENTS WHERE ISCOMPLETED='1' AND DATE > '%@' ORDER BY DATE DESC",DateStr];
        query=[NSString stringWithFormat:@"select * from APPOITMENTS WHERE ISCOMPLETED='1'"];
        
        
        NSLog(@"%@",query);
        
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, nil)==SQLITE_OK)
        {
            
            while(sqlite3_step(stm)==SQLITE_ROW)
            {
                
                
                dict=[[NSMutableDictionary alloc]init];
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 0)] forKey:@"ID"];
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 1)] forKey:@"DATE"];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 4)] forKey:@"TITLE"];
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 6)] forKey:@"TIME"];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 5)] forKey:@"DESC"];
               
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 7)] forKey:@"ISCONFORM"];
                
                [data addObject:dict];
                NSLog(@"%@",data);
                
                
            }
            sqlite3_finalize(stm);
        }
        // }
        sqlite3_close(db);
    }
    
    return data;
    
     
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}

#pragma mark Overdue Appointment...

-(NSMutableArray*)AppointmentSelect_overdue
{
    @try{
    NSDateFormatter *DateFormatter=[[NSDateFormatter alloc] init];
    [DateFormatter setDateFormat:@"MM-dd-yy"];
    NSDateFormatter *timeFormatter=[[NSDateFormatter alloc] init];
    [timeFormatter setDateFormat:@"hh:mm:ss"];
    
    NSString *DateStr=[DateFormatter stringFromDate:[NSDate date]];
  //  NSString *timeStr=[timeFormatter stringFromDate:[NSDate date]];
    
    NSMutableArray *data=[[NSMutableArray alloc]init];
    NSMutableDictionary *dict;
    if(sqlite3_open([appDelegate.dbpath UTF8String],&db) == SQLITE_OK)
    {
        
        query=[NSString stringWithFormat:@"select * from APPOITMENTS WHERE  DATE = '%@' AND ISCOMPLETED='1' ORDER BY DATE DESC",DateStr];
        
        
        NSLog(@"%@",query);
        
        
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, nil)==SQLITE_OK)
        {
            
            while(sqlite3_step(stm)==SQLITE_ROW)
            {
                
                
                dict=[[NSMutableDictionary alloc]init];
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 0)] forKey:@"ID"];
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 1)] forKey:@"DATE"];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 4)] forKey:@"TITLE"];
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 6)] forKey:@"TIME"];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 5)] forKey:@"DESC"];
                
                [data addObject:dict];
                NSLog(@"%@",data);
            }
            sqlite3_finalize(stm);
        }
        // }
        sqlite3_close(db);
    }
    
    return data;

    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}


#pragma mark Slect all Appointment......

-(NSMutableArray*)Select_All_Appointment
{
    @try{
    //ISCOMPLETED ISCONFORM
    
    NSMutableArray *data=[[NSMutableArray alloc]init];
    NSMutableDictionary *dict;
    if(sqlite3_open([appDelegate.dbpath UTF8String],&db) == SQLITE_OK)
    {
        
        query=[NSString stringWithFormat:@"select * from APPOITMENTS "];
        
        
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, nil)==SQLITE_OK)
        {
            
            while(sqlite3_step(stm)==SQLITE_ROW)
            {
                
                
                dict=[[NSMutableDictionary alloc]init];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 2)] forKey:@"ISCOMPLETED"];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 4)] forKey:@"TITLE"];
                
                
                
                 [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 0)] forKey:@"ID"];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 7)] forKey:@"ISCONFORM"];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 1)] forKey:@"DATE"];
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 6)] forKey:@"TIME"];
                
                
                
                [data addObject:dict];
                NSLog(@"%@",data);
                
                
            }
            sqlite3_finalize(stm);
        }
        // }
        sqlite3_close(db);
    }
    
    return data;
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}

#pragma mark Slect All Alets.......

-(NSMutableArray*)Select_All_Alerts:(NSString *)Str
{
    @try{
    //ISCOMPLETED ISCONFORM
    
    NSLog(@"%@",Str);
    
    NSMutableArray *data=[[NSMutableArray alloc]init];
    NSMutableDictionary *dict;
    if(sqlite3_open([appDelegate.dbpath UTF8String],&db) == SQLITE_OK)
    {
        
        query=[NSString stringWithFormat:@"select * from ALERT WHERE ALERTTYPE=%@",Str];
        
        
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, nil)==SQLITE_OK)
        {
            
            while(sqlite3_step(stm)==SQLITE_ROW)
            {
                
                
                dict=[[NSMutableDictionary alloc]init];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 2)] forKey:@"ALERTMSG"];
                
                
                
                [data addObject:dict];
                NSLog(@"%@",data);
                
                
            }
            sqlite3_finalize(stm);
        }
        // }
        sqlite3_close(db);
    }
    
    return data;
 
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}

#pragma mark.. Edit Appointment.........

-(NSMutableArray*)EditAppointment:(NSString *)Str;{
    @try{
    NSLog(@"%@",Str);
    NSMutableArray *data=[[NSMutableArray alloc]init];
    NSMutableDictionary *dict;
    if(sqlite3_open([appDelegate.dbpath UTF8String],&db) == SQLITE_OK)
    {
        
         query=[NSString stringWithFormat:@"select * from APPOITMENTS WHERE ID='%@'",Str];
        
        
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, nil)==SQLITE_OK)
        {
            
            while(sqlite3_step(stm)==SQLITE_ROW)
            {
                
                
                dict=[[NSMutableDictionary alloc]init];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 1)] forKey:@"DATE"];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 4)] forKey:@"TITLE"];
                
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 5)] forKey:@"DESC"];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 6)] forKey:@"TIME"];
                
                
                
                [data addObject:dict];
                NSLog(@"%@",data);
                
                
            }
            sqlite3_finalize(stm);
        }
        // }
        sqlite3_close(db);
    }
    
    return data;
    }@catch(NSException *exception){
        NSLog(@"%@",exception);
    }
    
}

-(BOOL)AppointmentUpdate:(NSArray*)Array
{
    @try{
    BOOL isok=NO;
    
    NSLog(@"%@",Array);
    NSString *strID = [[Array objectAtIndex:0]objectForKey:@"ID"];
    NSString *NameStr=[[Array objectAtIndex:0] objectForKey:@"TITLE"];
    NSString *PinStr=[[Array objectAtIndex:0] objectForKey:@"DESC"];
    NSString *StartDateStr=[[Array objectAtIndex:0] objectForKey:@"DATE"];
    NSString *strTime = [[Array objectAtIndex:0] objectForKey:@"TIME"];
    
    
    
    query=[NSString stringWithFormat:@"UPDATE APPOITMENTS SET DESC='%@',DATE='%@',TITLE='%@',TIME='%@' WHERE ID ='%@'",PinStr,StartDateStr,NameStr,strTime,strID];
    
    NSLog(@"%@",query);
    
    if(sqlite3_open([appDelegate.dbpath UTF8String], &db)==SQLITE_OK)
    {
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, NULL)==SQLITE_OK)
        {
            sqlite3_step(stm);
            isok=YES;
            
        }
        sqlite3_finalize(stm);
    }
    
    if (isok==YES)
    {
        [appDelegate.window makeToast:@"Successfully updated" duration:1.0 position:@"center"];
        
    }else
    {
        //Update user not in datebase then insert new user
        
       
    }
    
    sqlite3_close(db);
    
    return isok;
    
    
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}

-(BOOL)AddAppointment:(NSArray*)dealArray
{
    @try{
    NSLog(@"%@",dealArray);
    
    BOOL isok=NO;
    
    sqlite3_stmt    *statement5;
    
    
    
    if(sqlite3_open([appDelegate.dbpath UTF8String],&db) == SQLITE_OK)
    {
        for (int i = 0; i<[dealArray count];i++)
        {
            
            query = [NSString stringWithFormat: @"INSERT INTO APPOITMENTS (DATE,ISCOMPLETED,USERID,TITLE,DESC,TIME,ISCONFORM) VALUES ('%@','%@','%@','%@','%@','%@','%@')",[[dealArray objectAtIndex:i]objectForKey:@"DATE"],[[dealArray objectAtIndex:i]objectForKey:@"ISCOMPLETED"],[[dealArray objectAtIndex:i]objectForKey:@"USERID"],[[dealArray objectAtIndex:i]objectForKey:@"TITLE"],[[dealArray objectAtIndex:i]objectForKey:@"DESC"],[[dealArray objectAtIndex:i]objectForKey:@"TIME"],[[dealArray objectAtIndex:i]objectForKey:@"ISCONFORM"]];
            
            const char *insert_stmt = [query UTF8String];
            
            sqlite3_prepare_v2(db, insert_stmt, -1, &statement5, NULL);
            if (sqlite3_step(statement5) == SQLITE_DONE)
            {
               
                 [appDelegate.window makeToast:@"Successfully Add Appointment" duration:1.0 position:@"center"];
            }
            else
            {
                
            }
            sqlite3_finalize(statement5);
        }
        sqlite3_close(db);
    }
    return isok;
      }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}

-(NSMutableArray*)AllTask:(NSString *)Str
{
    @try{
        
    NSLog(@"%@",Str);
    NSMutableArray *data=[[NSMutableArray alloc]init];
    NSMutableDictionary *dict;
    if(sqlite3_open([appDelegate.dbpath UTF8String],&db) == SQLITE_OK)
    {
        
        query=[NSString stringWithFormat:@"select * from TASK_LIST WHERE APPOITMENT_ID='%@'",Str];
        
        
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, nil)==SQLITE_OK)
        {
            
            while(sqlite3_step(stm)==SQLITE_ROW)
            {
                
                
                dict=[[NSMutableDictionary alloc]init];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 0)] forKey:@"TASK_NAME"];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 6)] forKey:@"ISCOMPLETED"];
                
                [data addObject:dict];
                NSLog(@"%@",data);
                
                
            }
            sqlite3_finalize(stm);
        }
        // }
        sqlite3_close(db);
    }
    
    return data;
 
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}


-(BOOL)insertTask:(NSArray*)dealArray
{
    @try{
    NSLog(@"%@",dealArray);
    
    BOOL isok=NO;
    
    sqlite3_stmt    *statement5;
    
    
    
    
    if(sqlite3_open([appDelegate.dbpath UTF8String],&db) == SQLITE_OK)
    {
        for (int i = 0; i<[dealArray count];i++)
        {
            
            query = [NSString stringWithFormat: @"INSERT INTO TASK_LIST (TASK_NAME,TASK_DESCRIPTION,APPOITMENT_ID,USER_ID,TASK_DATE,TIME,ISCOMPLETED) VALUES ('%@','%@','%@','%@','%@','%@','%@')",[[dealArray objectAtIndex:i]objectForKey:@"TASK_NAME"],[[dealArray objectAtIndex:i]objectForKey:@"TASK_DESCRIPTION"],[[dealArray objectAtIndex:i]objectForKey:@"APPOITMENT_ID"],[[dealArray objectAtIndex:i]objectForKey:@"USER_ID"],[[dealArray objectAtIndex:i]objectForKey:@"TASK_DATE"],[[dealArray objectAtIndex:i]objectForKey:@"TIME"],[[dealArray objectAtIndex:i]objectForKey:@"ISCOMPLETED"]];
            
            const char *insert_stmt = [query UTF8String];
            
            sqlite3_prepare_v2(db, insert_stmt, -1, &statement5, NULL);
            if (sqlite3_step(statement5) == SQLITE_DONE)
            {
                
                [appDelegate.window makeToast:@"Successfully Add Task" duration:1.0 position:@"center"];
            }
            else
            {
                
            }
            sqlite3_finalize(statement5);
        }
        sqlite3_close(db);
    }
    return isok;
    
    
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}

-(BOOL)UpdateAppointDate:(NSString *)Str
{
    @try{
    BOOL isok=NO;
    
    query=[NSString stringWithFormat:@"UPDATE APPOITMENTS SET ISCONFORM='%@'WHERE ID ='%@'",Str,appDelegate.Sele_ID_viewApp_Str];
    
    NSLog(@"%@",query);
    
    if(sqlite3_open([appDelegate.dbpath UTF8String], &db)==SQLITE_OK)
    {
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, NULL)==SQLITE_OK)
        {
            sqlite3_step(stm);
            isok=YES;
            
        }
        sqlite3_finalize(stm);
    }
    
    if (isok==YES)
    {
        if ([Str isEqualToString:@"1"])
        {
              [appDelegate.window makeToast:@"Date Confirmed" duration:1.0 position:@"center"];
        }else
        {
             [appDelegate.window makeToast:@"Date Not Confirmed" duration:1.0 position:@"center"];
        }
      
        
    }
    
    sqlite3_close(db);
    
    return isok;
    
    
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}

-(BOOL)TaskUpdateCompleted:(NSString *)Str
{
    @try{
    BOOL isok=NO;
    
    query=[NSString stringWithFormat:@"UPDATE TASK_LIST SET ISCOMPLETED='1'WHERE APPOITMENT_ID ='%@' AND TASK_NAME='%@'",appDelegate.Sele_ID_viewApp_Str,Str];
    
    
    NSLog(@"%@",query);
    
    if(sqlite3_open([appDelegate.dbpath UTF8String], &db)==SQLITE_OK)
    {
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, NULL)==SQLITE_OK)
        {
            sqlite3_step(stm);
            isok=YES;
            
        }
        sqlite3_finalize(stm);
    }
    
    if (isok==YES)
    {
        
        
    }
    
    sqlite3_close(db);
    
   
     return isok;
    
    
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}

-(BOOL)UpdateDateAppo_startdate:(NSString *)Str;

{
    @try{
    BOOL isok=NO;
    
   query=[NSString stringWithFormat:@"UPDATE APPOITMENTS SET DATE='%@',ISCONFORM='0',ISCOMPLETED='1'WHERE TITLE ='%@'",Str,appDelegate.update_titleName];
    
        NSLog(@"%@",query);
    
    if(sqlite3_open([appDelegate.dbpath UTF8String], &db)==SQLITE_OK)
    {
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, NULL)==SQLITE_OK)
        {
            sqlite3_step(stm);
            isok=YES;
        }
        sqlite3_finalize(stm);
    }
    if (isok==YES)
    {
    }
    sqlite3_close(db);
    return isok;
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}

-(BOOL)UpdateSetting_startdate:(NSString *)Str;

{
    @try{
    BOOL isok=NO;
    
    query=[NSString stringWithFormat:@"UPDATE APPOITMENTS SET DATE='%@',ISCOMPLETED ='1' WHERE TITLE ='%@'",Str,appDelegate.update_titleName];
    
    
    NSLog(@"%@",query);
    
    if(sqlite3_open([appDelegate.dbpath UTF8String], &db)==SQLITE_OK)
    {
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, NULL)==SQLITE_OK)
        {
            sqlite3_step(stm);
            isok=YES;
            
        }
        sqlite3_finalize(stm);
    }
    
    if (isok==YES)
    {
        
        
    }
    
    sqlite3_close(db);
    
    
    return isok;
    
    
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}



-(NSMutableArray*)AppointmentSelect_Inconform
{
    @try{
    //BHUSHAN
    
    NSMutableArray *data=[[NSMutableArray alloc]init];
    NSMutableDictionary *dict;
    if(sqlite3_open([appDelegate.dbpath UTF8String],&db) == SQLITE_OK)
    {
        
        //query=[NSString stringWithFormat:@"select * from APPOITMENTS WHERE  ISCONFORM='1' ORDER BY DATE DESC"];
        
        query=[NSString stringWithFormat:@"select * from APPOITMENTS WHERE ISCOMPLETED ='1' ORDER BY DATE DESC"];
        

        NSLog(@"%@",query);
        
        
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, nil)==SQLITE_OK)
        {
            
            while(sqlite3_step(stm)==SQLITE_ROW)
            {
                
                
                dict=[[NSMutableDictionary alloc]init];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 1)] forKey:@"DATE"];
                
                               
                
                [data addObject:dict];
                NSLog(@"%@",data);
                
                
            }
            sqlite3_finalize(stm);
        }
        // }
        sqlite3_close(db);
    }
    
    return data;
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}
    
-(NSMutableArray*)Appointment_cal_info:(NSString *)Str
{
    @try{
    NSMutableArray *data=[[NSMutableArray alloc]init];
    NSMutableDictionary *dict;
    if(sqlite3_open([appDelegate.dbpath UTF8String],&db) == SQLITE_OK)
    {
        
        query=[NSString stringWithFormat:@"SELECT * FROM APPOITMENTS WHERE DATE='%@' AND ISCOMPLETED='1'",Str];
        
        
        NSLog(@"%@",query);
        
        
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, nil)==SQLITE_OK)
        {
            
            while(sqlite3_step(stm)==SQLITE_ROW)
            {
                
                
                 dict=[[NSMutableDictionary alloc]init];
              
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 0)] forKey:@"ID"];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 1)] forKey:@"DATE"];
                
                 [dict setValue:[NSString stringWithUTF8String:(char *)
                                 sqlite3_column_text(stm, 4)] forKey:@"TITLE"];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 5)] forKey:@"DESC"];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 6)] forKey:@"TIME"];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 7)] forKey:@"ISCONFORM"];
                
                [data addObject:dict];
                NSLog(@"%@",data);
                
                
            }
            sqlite3_finalize(stm);
        }
        // }
        sqlite3_close(db);
    }
    
    return data;
  
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}



-(NSMutableArray*)Selection_All_notification
{
    @try{
    //CREATE TABLE "NOTIFICATION" ("MSG" VARCHAR, "DATE" VARCHAR, "ID" VARCHAR, "READCHECK" INTEGER)
    
    
    NSMutableArray *data=[[NSMutableArray alloc]init];
    NSMutableDictionary *dict;
    if(sqlite3_open([appDelegate.dbpath UTF8String],&db) == SQLITE_OK)
    {
        
        query=[NSString stringWithFormat:@"SELECT * FROM NOTIFICATION"];
        
        
        NSLog(@"%@",query);
        
        
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, nil)==SQLITE_OK)
        {
            
            while(sqlite3_step(stm)==SQLITE_ROW)
            {
                
                
                dict=[[NSMutableDictionary alloc]init];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 0)] forKey:@"MSG"];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 1)] forKey:@"DATE"];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 2)] forKey:@"ID"];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 3)] forKey:@"READCHECK"];
                
                
                
                [data addObject:dict];
                NSLog(@"%@",data);
                
                
            }
            sqlite3_finalize(stm);
        }
        // }
        sqlite3_close(db);
    }
    
    return data;
    
    
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}

- (NSMutableArray *) getRecentlyCompoletedAppointment
{
        //CREATE TABLE "NOTIFICATION" ("MSG" VARCHAR, "DATE" VARCHAR, "ID" VARCHAR, "READCHECK" INTEGER)
    @try{
        
        NSMutableArray *data=[[NSMutableArray alloc]init];
        NSMutableDictionary *dict;
        if(sqlite3_open([appDelegate.dbpath UTF8String],&db) == SQLITE_OK)
        {
            
            query=[NSString stringWithFormat:@"SELECT * FROM APPOITMENTS WHERE ISCOMPLETED='0'"];
            
            NSLog(@"%@",query);
            
            
            sqlite3_stmt *stm;
            if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, nil)==SQLITE_OK)
            {
                
                while(sqlite3_step(stm)==SQLITE_ROW)
                {
                    
                    
                    dict=[[NSMutableDictionary alloc]init];
                    
                    [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 0)] forKey:@"ID"];
                    
                    [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 1)] forKey:@"DATE"];
                    
                    [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 4)] forKey:@"TITLE"];
                    
                  
                    [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 5)] forKey:@"DESC"];
                    
                    [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 6)] forKey:@"TIME"];
                    [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 9)] forKey:@"DATECOMPLETED"];
                  
                    [data addObject:dict];
                    NSLog(@"%@",data);
                    
                    
                }
                sqlite3_finalize(stm);
            }
            // }
            sqlite3_close(db);
        }
        
        return data;

    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}


-(BOOL)Update_pillCount:(NSString *)Str
{
    @try{
    BOOL isok=NO;
    query=[NSString stringWithFormat:@"UPDATE USER_INFO SET PILLCOUNT='%@'WHERE NAME ='%@'",appDelegate.Pill_countStr,Str];
        
    NSLog(@"%@",query);
    
    if(sqlite3_open([appDelegate.dbpath UTF8String], &db)==SQLITE_OK)
    {
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, NULL)==SQLITE_OK)
        {
            sqlite3_step(stm);
            isok=YES;
            
        }
        sqlite3_finalize(stm);
    }
    
    if (isok==YES)
    {
    }
    
    sqlite3_close(db);
    
    
    return isok;
    
    
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}


-(BOOL)insertMEDICAL_RECORD:(NSArray*)dealArray
{
    @try{
    NSLog(@"%@",dealArray);
    
    BOOL isok=NO;
    
    sqlite3_stmt    *statement5;
    
    
    
    if(sqlite3_open([appDelegate.dbpath UTF8String],&db) == SQLITE_OK)
    {
        for (int i = 0; i<[dealArray count];i++)
        {
            
            query = [NSString stringWithFormat: @"INSERT INTO MEDICAL_RECORD (USER_ID,MED_NAME,START_DATE,MED_TAKEN,MED_QUNTITY,MED_TIME) VALUES ('%@','%@','%@','%@','%@','%@')",[[dealArray objectAtIndex:i]objectForKey:@"USER_ID"],[[dealArray objectAtIndex:i]objectForKey:@"MED_NAME"],[[dealArray objectAtIndex:i]objectForKey:@"START_DATE"],[[dealArray objectAtIndex:i]objectForKey:@"MED_TAKEN"],[[dealArray objectAtIndex:i]objectForKey:@"MED_QUNTITY"],[[dealArray objectAtIndex:i]objectForKey:@"MED_TIME"]];
            
            const char *insert_stmt = [query UTF8String];
            
            sqlite3_prepare_v2(db, insert_stmt, -1, &statement5, NULL);
            if (sqlite3_step(statement5) == SQLITE_DONE)
            {
                NSLog(@"Data Deals---->");
                
            } else {
                
            }
            sqlite3_finalize(statement5);
        }
        sqlite3_close(db);
    }
    return isok;
    
    
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}



-(NSMutableArray *)selectMEDICAL_RECORD
{@try{
    
    NSMutableArray *data=[[NSMutableArray alloc]init];
    NSMutableDictionary *dict;
    if(sqlite3_open([appDelegate.dbpath UTF8String],&db) == SQLITE_OK)
    {
        
        query=[NSString stringWithFormat:@"select * from MEDICAL_RECORD"];
        
        
        NSLog(@"%@",query);
        
        
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, nil)==SQLITE_OK)
        {
            
            while(sqlite3_step(stm)==SQLITE_ROW)
            {
                
                
                dict=[[NSMutableDictionary alloc]init];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 3)] forKey:@"START_DATE"];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 6)] forKey:@"MED_TIME"];
                
                
                
                
                [data addObject:dict];
                NSLog(@"%@",data);
                
                
            }
            sqlite3_finalize(stm);
        }
        // }
        sqlite3_close(db);
    }
    
    return data;
}@catch(NSException *exception){
    NSLog(@"%@",exception.description);
}
    
}


-(BOOL)Comp_task:(NSString *)Str
{@try{
    BOOL isok=NO;
     query=[NSString stringWithFormat:@"UPDATE APPOITMENTS SET ISCOMPLETED='0' WHERE ID ='%@'",Str];
    
    NSLog(@"%@",query);
    
    if(sqlite3_open([appDelegate.dbpath UTF8String], &db)==SQLITE_OK)
    {
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, NULL)==SQLITE_OK)
        {
            sqlite3_step(stm);
            isok=YES;
            
        }
        sqlite3_finalize(stm);
    }
    
    if (isok==YES)
    {
        [appDelegate.window makeToast:@"Successfully updated" duration:1.0 position:@"center"];
        
    }else
    {
        //Update user not in datebase then insert new user
        
        
    }
    
    sqlite3_close(db);
    
    return isok;
    
    
}@catch(NSException *exception){
    NSLog(@"%@",exception.description);
}
    
}

-(BOOL)UpdateDateComplete:(NSString *)DateCompleted Id:(NSString *)strId
{
    BOOL isok=NO;
    query=[NSString stringWithFormat:@"UPDATE APPOITMENTS SET DATECOMPLETED='%@' WHERE ID ='%@'",DateCompleted,strId];
    
    NSLog(@"%@",query);
    
    if(sqlite3_open([appDelegate.dbpath UTF8String], &db)==SQLITE_OK)
    {
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, NULL)==SQLITE_OK)
        {
            sqlite3_step(stm);
            isok=YES;
            
        }
        sqlite3_finalize(stm);
    }
    
    
    sqlite3_close(db);
    
    return isok;
}






-(BOOL)resetAppointments {
    BOOL isok=NO;
    
    sqlite3_stmt    *statement5;
    
    if(sqlite3_open([appDelegate.dbpath UTF8String],&db) == SQLITE_OK)
    {
        query = [NSString stringWithFormat: @"DELETE from APPOITMENTS WHERE ID>'2'"];
        
        const char *insert_stmt = [query UTF8String];
        
        sqlite3_prepare_v2(db, insert_stmt, -1, &statement5, NULL);
        if (sqlite3_step(statement5) == SQLITE_DONE)
        {
            NSLog(@"Data Appointments---->");
            isok = TRUE;
            
        } else
        {
            
        }
        sqlite3_finalize(statement5);
    }
    sqlite3_close(db);
    return isok;
    
    
    return TRUE;

}



-(BOOL)deleteNotification:(NSString *)strID {
    BOOL isok=NO;
    
    sqlite3_stmt    *statement5;
    
    if(sqlite3_open([appDelegate.dbpath UTF8String],&db) == SQLITE_OK)
    {
        query = [NSString stringWithFormat: @"DELETE from NOTIFICATION where ID = '%@'",strID];
        
        const char *insert_stmt = [query UTF8String];
        
        sqlite3_prepare_v2(db, insert_stmt, -1, &statement5, NULL);
        if (sqlite3_step(statement5) == SQLITE_DONE)
        {
            NSLog(@"Data Notification---->");
            isok = TRUE;
            
        } else
        {
            
        }
        sqlite3_finalize(statement5);
    }
    sqlite3_close(db);
    return isok;
    
    
    return TRUE;
}

-(BOOL)insertnotifications:(NSArray*)dealArray
{
    
    //CREATE TABLE "NOTIFICATION" ("MSG" VARCHAR, "DATE" VARCHAR, "ID" VARCHAR, "READCHECK" INTEGER)
    
    
    BOOL isok=NO;
    
    sqlite3_stmt    *statement5;
    
    
    
    if(sqlite3_open([appDelegate.dbpath UTF8String],&db) == SQLITE_OK)
    {
        for (int i = 0; i<[dealArray count];i++)
        {
            
            NSString *uuid = [[NSUUID UUID] UUIDString];
            
            query = [NSString stringWithFormat: @"INSERT INTO NOTIFICATION (MSG,DATE,ID,READCHECK) VALUES ('%@','%@','%@','%@')",[[dealArray objectAtIndex:i]objectForKey:@"MSG"],[[dealArray objectAtIndex:i]objectForKey:@"DATE"],uuid,[[dealArray objectAtIndex:i]objectForKey:@"READCHECK"]];
            
            const char *insert_stmt = [query UTF8String];
            
            sqlite3_prepare_v2(db, insert_stmt, -1, &statement5, NULL);
            if (sqlite3_step(statement5) == SQLITE_DONE)
            {
                NSLog(@"Data Notification---->");
                
            } else
            {
                
            }
            sqlite3_finalize(statement5);
        }
        sqlite3_close(db);
    }
    return isok;
    
    
}

-(BOOL)insertRegularPillTaken:(NSArray *)arrPillTaken
{
    BOOL isok=NO;
    
    sqlite3_stmt    *statement5;
    
    
    
    if(sqlite3_open([appDelegate.dbpath UTF8String],&db) == SQLITE_OK)
    {
        for (int i = 0; i<[arrPillTaken count];i++)
        {
            
            //NSString *uuid = [[NSUUID UUID] UUIDString];
            
            query = [NSString stringWithFormat: @"INSERT INTO MED_TIME_BADGE (MED_ID,MED_TAKEN,MED_TAKEN_DATE,ISAFTER_OR_BEFORE) VALUES ('%@','%@','%@','%@')",[[arrPillTaken objectAtIndex:i]objectForKey:@"MED_ID"],[[arrPillTaken objectAtIndex:i]objectForKey:@"MED_TAKEN"],[[arrPillTaken objectAtIndex:i]objectForKey:@"MED_TAKEN_DATE"],[[arrPillTaken objectAtIndex:i]objectForKey:@"ISAFTER_OR_BEFORE"]];
            
            const char *insert_stmt = [query UTF8String];
            
            sqlite3_prepare_v2(db, insert_stmt, -1, &statement5, NULL);
            if (sqlite3_step(statement5) == SQLITE_DONE)
            {
                NSLog(@"Data Notification---->");
                
            } else
            {
                
            }
            sqlite3_finalize(statement5);
        }
        sqlite3_close(db);
    }
    
    return isok;
}


-(NSMutableArray *)selectRegularPillTaken
{
    
    NSMutableArray *data=[[NSMutableArray alloc]init];
    NSMutableDictionary *dict;
    if(sqlite3_open([appDelegate.dbpath UTF8String],&db) == SQLITE_OK)
    {
        
        query=[NSString stringWithFormat:@"select * from MED_TIME_BADGE"];
        
        
        NSLog(@"%@",query);
        
        
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, nil)==SQLITE_OK)
        {
            
            while(sqlite3_step(stm)==SQLITE_ROW)
            {
                
                
                dict=[[NSMutableDictionary alloc]init];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 0)] forKey:@"MED_ID"];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 1)] forKey:@"MED_TAKEN"];
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 2)] forKey:@"MED_TAKEN_DATE"];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 3)] forKey:@"ISAFTER_OR_BEFORE"];
                
                
                
                [data addObject:dict];
                NSLog(@"%@",data);
                
                
            }
            sqlite3_finalize(stm);
        }
        // }
        sqlite3_close(db);
    }
    
    return data;
}

-(BOOL)deleteRegularPillTaken {
    BOOL isok=NO;
    
    sqlite3_stmt    *statement5;
    
    if(sqlite3_open([appDelegate.dbpath UTF8String],&db) == SQLITE_OK)
    {
        query =@"DELETE from MED_TIME_BADGE";
        
        const char *insert_stmt = [query UTF8String];
        
        sqlite3_prepare_v2(db, insert_stmt, -1, &statement5, NULL);
        if (sqlite3_step(statement5) == SQLITE_DONE)
        {
            NSLog(@"Data Notification---->");
            isok = TRUE;
            
        } else
        {
            
        }
        sqlite3_finalize(statement5);
    }
    sqlite3_close(db);
    return isok;
    
    
    return TRUE;
}

-(BOOL)insertMedicationReport:(NSArray *)arrPillTaken
{
    BOOL isok=NO;
    
    sqlite3_stmt    *statement5;
    
    
    
    if(sqlite3_open([appDelegate.dbpath UTF8String],&db) == SQLITE_OK)
    {
        for (int i = 0; i<[arrPillTaken count];i++)
        {
            
        //    "MED_RECORD_TIME" ("MED_ID" INTEGER,"MED_TIME_DIFF" VARCHAR,"MED_TAKEN" INTEGER DEFAULT (null) ,"MED_TAKEN_DATE" VARCHAR, "MED_TAKEN_TIME" VARCHAR, "MED_SCHEDULE_TIME" VARCHAR, "ISAFTER_OR_BEFORE" INTEGER)
            //NSString *uuid = [[NSUUID UUID] UUIDString];
            
            query = [NSString stringWithFormat: @"INSERT INTO MED_RECORD_TIME (MED_TIME_DIFF,MED_TAKEN,MED_TAKEN_DATE,MED_TAKEN_TIME,MED_SCHEDULE_TIME,ISAFTER_OR_BEFORE) VALUES ('%@','%@','%@','%@','%@','%@')",[[arrPillTaken objectAtIndex:i]objectForKey:@"MED_TIME_DIFF"],[[arrPillTaken objectAtIndex:i]objectForKey:@"MED_TAKEN"],[[arrPillTaken objectAtIndex:i]objectForKey:@"MED_TAKEN_DATE"],[[arrPillTaken objectAtIndex:i]objectForKey:@"MED_TAKEN_TIME"],[[arrPillTaken objectAtIndex:i]objectForKey:@"MED_SCHEDULE_TIME"],[[arrPillTaken objectAtIndex:i]objectForKey:@"ISAFTER_OR_BEFORE"]];
            
            const char *insert_stmt = [query UTF8String];
            
            sqlite3_prepare_v2(db, insert_stmt, -1, &statement5, NULL);
            if (sqlite3_step(statement5) == SQLITE_DONE)
            {
                NSLog(@"Data Notification---->");
                
            } else
            {
                
            }
            sqlite3_finalize(statement5);
        }
        sqlite3_close(db);
    }
    
    return isok;
}

-(NSMutableArray *)selectMedicationReport
{
    
    NSMutableArray *data=[[NSMutableArray alloc]init];
    NSMutableDictionary *dict;
    if(sqlite3_open([appDelegate.dbpath UTF8String],&db) == SQLITE_OK)
    {
        
        query=[NSString stringWithFormat:@"select * from MED_RECORD_TIME"];
        
        
        NSLog(@"%@",query);
        
        
        sqlite3_stmt *stm;
        if(sqlite3_prepare_v2(db, [query UTF8String], -1, &stm, nil)==SQLITE_OK)
        {
            
            while(sqlite3_step(stm)==SQLITE_ROW)
            {
                
                dict=[[NSMutableDictionary alloc]init];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 0)] forKey:@"MED_ID"];
                
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 1)] forKey:@"MED_TIME_DIFF"];
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 2)]  forKey:@"MED_TAKEN"];
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 3)] forKey:@"MED_TAKEN_DATE"];
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 4)] forKey:@"MED_TAKEN_TIME"];
                [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 5)] forKey:@"MED_SCHEDULE_TIME"];
                 [dict setValue:[NSString stringWithUTF8String:(char *)sqlite3_column_text(stm, 6)] forKey:@"ISAFTER_OR_BEFORE"];
               
                
                [data addObject:dict];
                NSLog(@"%@",data);
                
                
            }
            sqlite3_finalize(stm);
        }
        // }
        sqlite3_close(db);
    }
    
    return data;
}

-(BOOL)deleteMedicationReport
{
    BOOL isok=NO;
    
    sqlite3_stmt    *statement5;
    
    if(sqlite3_open([appDelegate.dbpath UTF8String],&db) == SQLITE_OK)
    {
        query =@"DELETE from MED_RECORD_TIME";
        
        const char *insert_stmt = [query UTF8String];
        
        sqlite3_prepare_v2(db, insert_stmt, -1, &statement5, NULL);
        if (sqlite3_step(statement5) == SQLITE_DONE)
        {
            NSLog(@"Data Notification---->");
            isok = TRUE;
            
        } else
        {
            
        }
        sqlite3_finalize(statement5);
    }
    sqlite3_close(db);
    return isok;
    
    
    return TRUE;
}

@end
