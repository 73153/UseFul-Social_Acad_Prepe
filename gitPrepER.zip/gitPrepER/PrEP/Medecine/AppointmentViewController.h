//
//  AppointmentViewController.h
//  PrEP
//
//  Created by Bhushan on 5/7/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@protocol UpdateRegularPill
@optional
-(void)updateRegularPillTaken:(int)pillCount;

@end

@interface AppointmentViewController : UIViewController

{
     AppDelegate *AppDel;
     BOOL Rota;
     int MedInt;
    int intialCount;
    
    NSMutableArray *App_Date,*App_Title,*App_Comp,*App_Completed,*AppID;
    NSString *nameStr,*pinStr,*DateStr,*PillTimeStr;
    
      NSMutableArray *TimeRecArray,*DateRecArray,*allRecArray;
    
}

@property (nonatomic,strong)id<UpdateRegularPill> delegate;
@property (strong, nonatomic) IBOutlet UIButton *btnSaveChangeDateNdTime;
@property (strong, nonatomic) IBOutlet UIButton *btnSaveInvCount;
@property (strong, nonatomic) IBOutlet UIButton *dash_button;
@property (strong, nonatomic) IBOutlet UIButton *btnChngDateNdTime;
@property (strong, nonatomic) IBOutlet UIButton *btnInvCount;

@property (strong, nonatomic) IBOutlet UIButton *task_button;
@property (strong, nonatomic) IBOutlet UIView *viewTimePicker;
@property (strong, nonatomic) IBOutlet UIView *view1;
@property (strong, nonatomic) IBOutlet UIView *view2;

@property (strong, nonatomic) IBOutlet UITableView *appointment_tableview;
@property (strong, nonatomic) IBOutlet UIButton *count_button_label;
@property (strong, nonatomic) IBOutlet UILabel *time_of_change_label;
@property (strong, nonatomic) IBOutlet UIButton *med_label_cont;

@property (strong, nonatomic) IBOutlet UIButton *pill_button;

@property (strong, nonatomic) IBOutlet UIScrollView *main_scroll_view;

@property (strong, nonatomic) IBOutlet UITextField *pill_quan_text;

@property (strong, nonatomic) IBOutlet UIView *pill_view;

@property (strong, nonatomic) IBOutlet UITextField *select_time;
@property (strong, nonatomic) IBOutlet UIView *time_view;
@property (strong, nonatomic) IBOutlet UIDatePicker *time_picker;

@property (nonatomic,retain) NSMutableArray *arrTopFiveAppoint;
@property (nonatomic,retain) NSMutableArray *arrTopFiveAppointTime;


- (IBAction)time_save_button_action:(id)sender;

- (IBAction)back_button_action:(id)sender;
- (IBAction)dash_button_action:(id)sender;
- (IBAction)add_appointments_button_action:(id)sender;
- (IBAction)noti_tab_button_action:(id)sender;
- (IBAction)cal_tab_button_action:(id)sender;
- (IBAction)setting_tab_button_action:(id)sender;
- (IBAction)pill_count_button_action:(id)sender;
- (IBAction)Inventory_count_button_action:(id)sender;
- (IBAction)change_date_time_action:(id)sender;
- (IBAction)pill_save_button_action:(id)sender;
- (IBAction)pill_back_button_action:(id)sender;
- (IBAction)inventory_button_action:(id)sender;
-(void)MainUserData;
- (IBAction)chageTime_back:(id)sender;
- (IBAction)time_Done_button_action:(id)sender;
- (IBAction)time_cancel_button_action:(id)sender;
-(void)selectTimeReq;

-(void)PillInsertReq;
@end
