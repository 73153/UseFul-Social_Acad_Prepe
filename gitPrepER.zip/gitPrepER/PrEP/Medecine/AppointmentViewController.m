//
//  AppointmentViewController.m
//  PrEP
//
//  Created by Bhushan on 5/7/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import "AppointmentViewController.h"

#import "DashBoardViewController.h"
#import "AppointmentTableViewCell.h"
#import "AddAppointmentViewController.h"
#import "DataBase.h"
#import "AppDelegate.h"
#import "viewTaskViewController.h"
#import "SettingViewController.h"
#import "NotificationViewController.h"
#import "CalViewController.h"
#import "TimeTableViewCell.h"
#import "Constant.h"

#define DEGREES_TO_RADIANS(d) (d * M_PI / 180)
#define MAX_LENGTH_Pi 2

#define IS_IPHONE4 (([[UIScreen mainScreen] bounds].size.height-480)?NO:YES)

@interface AppointmentViewController ()<UIScrollViewDelegate,UITextFieldDelegate>
{
    DataBase *dbh;
  
    
}
@end

@implementation AppointmentViewController

- (void)viewDidLoad
{@try{
    DashBoardViewController *dash=[[DashBoardViewController alloc]init];
    _delegate=dash.self;
    
    AppDel=[[UIApplication sharedApplication] delegate];
    
    [super viewDidLoad];
    
        [self.appointment_tableview setBackgroundColor:[UIColor clearColor]];

    dbh=[[DataBase alloc]init];
    
    App_Date=[[NSMutableArray alloc]init];
    App_Title=[[NSMutableArray alloc]init];
    App_Comp=[[NSMutableArray alloc]init];
    App_Completed=[[NSMutableArray alloc]init];
    AppID=[[NSMutableArray alloc]init];
    
    TimeRecArray=[[NSMutableArray alloc]init];
    DateRecArray=[[NSMutableArray alloc]init];
    allRecArray=[[NSMutableArray alloc]init];
    

      Rota=NO;
    
    [_task_button setBackgroundImage:[UIImage imageNamed:@"task_selected"] forState:UIControlStateNormal];
    
    
     //ISCOMPLETED ISCONFORM
    
    NSArray *SlectAll=[dbh Select_All_Appointment];
    
    for (int i=0; i<[SlectAll count]; i++)
    {
       
        [App_Title addObject:[[SlectAll objectAtIndex:i]objectForKey:@"TITLE"]];
        [App_Completed addObject:[[SlectAll objectAtIndex:i]objectForKey:@"ISCOMPLETED"]];
        [App_Comp addObject:[[SlectAll objectAtIndex:i]objectForKey:@"ISCONFORM"]];
        [AppID addObject:[[SlectAll objectAtIndex:i]objectForKey:@"ID"]];
        
      //  [App_Date addObject:[[SlectAll objectAtIndex:i]objectForKey:@"DATE"]];
    }
    

    AppDel.Increment_Id_App_Str=[NSString stringWithFormat:@"%lu",(unsigned long)[App_Title count]+2];
    
    NSLog(@"%@",AppDel.Increment_Id_App_Str);
    
    
    
    [_view1.layer setCornerRadius:5.0f];
    
    // border
    [_view1.layer setBorderColor:[UIColor lightGrayColor].CGColor];
    [_view1.layer setBorderWidth:1.5f];
    
    // drop shadow
//     [_view1.layer setShadowColor:[UIColor blackColor].CGColor];
//     [_view1.layer setShadowOpacity:0.8];
//     [_view1.layer setShadowRadius:3.0];
//     [_view1.layer setShadowOffset:CGSizeMake(2.0, 2.0)];
    
    
    
    
    [_view2.layer setCornerRadius:5.0f];
    
    // border
    [_view2.layer setBorderColor:[UIColor lightGrayColor].CGColor];
    [_view2.layer setBorderWidth:1.5f];
    
    // drop shadow
//     [_view2.layer setShadowColor:[UIColor blackColor].CGColor];
//     [_view2.layer setShadowOpacity:0.8];
//     [_view2.layer setShadowRadius:3.0];
//     [_view2.layer setShadowOffset:CGSizeMake(2.0, 2.0)];
    
   
    
   
    // Do any additional setup after loading the view.
}  @catch(NSException *exception){
    NSLog(@"%@",exception.description);
}
    
}


- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


-(void)viewWillAppear:(BOOL)animated
{
    @try{
    [self MainUserData];
    _main_scroll_view.delegate = self;
    _main_scroll_view.clipsToBounds = NO;
    
    if (IS_IPHONE4)
    {
        [_main_scroll_view setContentSize:CGSizeMake(320,400)];
    }else
    {
        // [_main_scroll_view setContentSize:CGSizeMake(320,500)];
    }
    
    [self selectTimeReq];
    self.arrTopFiveAppoint = [[NSMutableArray alloc ]init];
    self.arrTopFiveAppointTime = [[NSMutableArray alloc]init];
    // edited by pradip....pill quntity
    
    _pill_quan_text.delegate=self;
    _pill_quan_text.layer.cornerRadius=2.0f;
    _pill_quan_text.layer.masksToBounds=YES;
    _pill_quan_text.layer.borderColor=[[UIColor grayColor]CGColor];
    _pill_quan_text.layer.borderWidth= 2.5f;
    _pill_quan_text.backgroundColor=[UIColor clearColor];
    
    UIToolbar* numberToolbar = [[UIToolbar alloc]initWithFrame:CGRectMake(0, 0, 320, 50)];
    numberToolbar.items = [NSArray arrayWithObjects:
                           [[UIBarButtonItem alloc]initWithTitle:@"Cancel" style:UIBarButtonItemStyleBordered target:self action:@selector(cancelNumberPad)],
                           [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemFlexibleSpace target:nil action:nil],
                           [[UIBarButtonItem alloc]initWithTitle:@"Apply" style:UIBarButtonItemStyleDone target:self action:@selector(doneWithNumberPad)],
                           nil];
    [numberToolbar sizeToFit];
    _pill_quan_text.inputAccessoryView = numberToolbar;
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]
                                   initWithTarget:self
                                   action:@selector(dismissKeyboard)];
    
    [self.pill_view addGestureRecognizer:tap];
    
    [self setPillTakenDetails];
    
    self.viewTimePicker.frame = CGRectMake(0, self.view.frame.size.height, self.view.frame.size.width, 242) ;
    
    self.select_time.delegate = self;
    
    [_btnChngDateNdTime initWithBorders];
    [_btnInvCount initWithBorders];
    [_btnSaveChangeDateNdTime initWithBorders];
    [_btnSaveInvCount initWithBorders];
    
   

    [self pillColor];
    }  @catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    self.viewTimePicker.frame = CGRectMake(0, self.view.frame.size.height - 242, self.view.frame.size.width, 242) ;

}

- (IBAction)time_save_button_action:(id)sender
{
    @try{
    
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    NSDate *dateOnly=UDGetObject(@"Fire_Date");
    [self disableNotificationAppoint:dateOnly];
    [dateFormat setDateFormat:@"dd-MM-yyyy"];
        
    NSString *dateonly=[dateFormat stringFromDate:dateOnly];
        NSDate *currentDate=[[NSDate alloc]init];
        NSString *strCurrentDate=[dateFormat stringFromDate:currentDate];
    strCurrentDate =[strCurrentDate stringByAppendingString:@" "];
    NSString *time=_select_time.text;
    strCurrentDate =[strCurrentDate stringByAppendingString:time];
    [dateFormat setDateFormat:@"dd-MM-yyyy hh:mm a"];
        NSDate *dailyreminder=[[NSDate alloc]init];
        dailyreminder=[dateFormat dateFromString:strCurrentDate];
    
   // [[UIApplication sharedApplication]cancelAllLocalNotifications];
    UILocalNotification* localNotification = [[UILocalNotification alloc] init];
    localNotification.fireDate = dailyreminder;
    localNotification.alertBody = @"Please Take Your Medicine";
    localNotification.timeZone = [NSTimeZone systemTimeZone];
    [[UIApplication sharedApplication] scheduleLocalNotification:localNotification];
    
    UDSetObject(dailyreminder, @"Fire_Date");
    
    _time_view.hidden=YES;
    
    NSMutableDictionary *dic=[[NSMutableDictionary alloc ]init];
    
    [dic setObject:nameStr forKey:@"NAME"];
    
    [dic setObject:pinStr forKey:@"PIN"];
    
    [dic setObject:AppDel.Pill_countStr forKey:@"PILLCOUNT"];
    
    [dic setObject:DateStr forKey:@"STARTDATE"];
    
    
    [dic setObject:_select_time.text forKey:@"PILLTIME"];
    
    NSMutableArray  *Array=[[NSMutableArray alloc]init];
    
    [Array addObject:dic];
    
    
    
    [dbh UserUpdate:Array];    
    
    
    [self MainUserData];
    
    }  @catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}


- (IBAction)back_button_action:(id)sender
{
    [self resignFirstResponder];
    [self.navigationController popViewControllerAnimated:NO];
}

- (IBAction)dash_button_action:(id)sender
{
    @try{
    int index = 0;
    for (UIViewController *vc in self.navigationController.viewControllers) {
        if ([vc isKindOfClass:[DashBoardViewController class]]) {
            [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:index] animated:NO];
        }
        index++;
    }
    DashBoardViewController *objDashBoardViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"DashBoardViewController"];
    [self.navigationController pushViewController:objDashBoardViewController animated:NO];
    }  @catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}


- (IBAction)add_appointments_button_action:(id)sender
{
    int index = 0;
    for (UIViewController *vc in self.navigationController.viewControllers) {
        if ([vc isKindOfClass:[AppointmentViewController class]]) {
            [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:index] animated:NO];
        }
        index++;
    }
     AddAppointmentViewController*objAddAppointmentViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"AddAppointmentViewController"];
    [self.navigationController pushViewController:objAddAppointmentViewController animated:NO];
}

- (IBAction)noti_tab_button_action:(id)sender
{
    @try{
    int index = 0;
    for (UIViewController *vc in self.navigationController.viewControllers) {
        if ([vc isKindOfClass:[NotificationViewController class]]) {
            [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:index] animated:NO];
        }
        index++;
    }
    NotificationViewController *objNotificationViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"NotificationViewController"];
    [self.navigationController pushViewController:objNotificationViewController animated:NO];
    }  @catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}


- (IBAction)cal_tab_button_action:(id)sender
{
    @try{
    int index = 0;
    for (UIViewController *vc in self.navigationController.viewControllers) {
        if ([vc isKindOfClass:[CalViewController class]]) {
            [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:index] animated:NO];
        }
        index++;
    }
    CalViewController *objCalViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"CalViewController"];
    [self.navigationController pushViewController:objCalViewController animated:NO];
    }  @catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}


- (IBAction)setting_tab_button_action:(id)sender
{
    @try{
//    int index = 0;
//    for (UIViewController *vc in self.navigationController.viewControllers) {
//        if ([vc isKindOfClass:[SettingViewController class]]) {
//            [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:index] animated:NO];
//        }
//        index++;
//    }
    SettingViewController *objSettingViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"SettingViewController"];
        objSettingViewController.date4=[_time_picker date];
    [self.navigationController pushViewController:objSettingViewController animated:NO];
    
    }  @catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}


- (IBAction)pill_count_button_action:(id)sender
{
    
    @try{
        
        
        NSDate *currentDateInLocal = [NSDate date];
        NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
        NSDate *lastPillTakenDate=UDGetObject(@"dtlastPillTakenDate");
        [dateFormat setDateFormat:@"MM-dd-yy"];
        NSString *strCurrentDate=[dateFormat stringFromDate:currentDateInLocal];
        //  NSString *strLastPillTakenDate=[dateFormat stringFromDate:lastPillTakenDate];
        currentDateInLocal =[dateFormat dateFromString:strCurrentDate];
        //   lastPillTakenDate =[dateFormat dateFromString:strCurrentDate];
         NSDate *startDate=[dateFormat dateFromString:DateStr];
        if ([currentDateInLocal compare:startDate] == NSOrderedAscending) {
            [self Alert:@"You can not take Pill before Start Date"];
        }else{
        
        if (lastPillTakenDate == nil || [currentDateInLocal compare:lastPillTakenDate] == NSOrderedDescending) {
        
        
    [self PillInsertReq];
    [_delegate updateRegularPillTaken:MedInt];
    if (Rota==YES)
    {
        
        if (MedInt<1)
        {
            
        }else{
            
            MedInt--;
            
            
            NSString *MeStr=[NSString stringWithFormat:@"%d",MedInt];
            
            AppDel.Pill_countStr=[NSString stringWithFormat:@"%@",MeStr];
            
            [dbh Update_pillCount:nameStr];
            
            
            
            [_med_label_cont setTitle:MeStr forState: UIControlStateNormal];
            
            [_med_label_cont setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
            
            [UIView animateWithDuration:0.80 animations:^{
                _pill_button.transform = CGAffineTransformMakeRotation(DEGREES_TO_RADIANS(180));
                
            }];
            [UIView animateWithDuration:0.80 animations:^{
                _pill_button.transform = CGAffineTransformMakeRotation(DEGREES_TO_RADIANS(360));
                
            }];
            Rota=NO;
        }
    }
    else
    {
        if (MedInt<1)
        {
            
        }else{
            
            MedInt--;
            
            NSString *MeStr=[NSString stringWithFormat:@"%d",MedInt];
            
            AppDel.Pill_countStr=[NSString stringWithFormat:@"%@",MeStr];
            
            [dbh Update_pillCount:nameStr];
            
            [_med_label_cont setTitle:MeStr forState: UIControlStateNormal];
            
            [_med_label_cont setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
            
            
            
            
            [UIView animateWithDuration:0.80 animations:^{
                _pill_button.transform = CGAffineTransformMakeRotation(DEGREES_TO_RADIANS(180));
                
            }];
            [UIView animateWithDuration:0.80 animations:^{
                _pill_button.transform = CGAffineTransformMakeRotation(DEGREES_TO_RADIANS(360));
                
            }];
            
            
            Rota=YES;
        }
    }
    
    [self setPillTakenDetails];
    
        }else if ([currentDateInLocal compare:lastPillTakenDate] == NSOrderedSame) {
            [self Alert:@"You have already taken today's pill"];
        }

    
    }
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}


-(void)setPillTakenDetails
{
    if (![AppDel.Pill_countStr isEqualToString:@"0"]) {
        
        int j = 0;
        [self.arrTopFiveAppoint removeAllObjects];
        [self.arrTopFiveAppointTime removeAllObjects];
        for (int i= (int)DateRecArray.count-1; i>0 ;i--) {
            j +=1;
            if (j<= 5){
                [self.arrTopFiveAppoint addObject:[DateRecArray objectAtIndex:i]];
                [self.arrTopFiveAppointTime addObject:[TimeRecArray objectAtIndex:i]];
            }
            else {
                return;
            }
            [self.appointment_tableview reloadData];
            
        }
        
    }

}

- (IBAction)Inventory_count_button_action:(id)sender
{
    
}

- (IBAction)change_date_time_action:(id)sender
{
    _time_view.hidden=NO;
        self.viewTimePicker.frame = CGRectMake(0, self.view.frame.size.height, self.view.frame.size.width, 242) ;

}

- (IBAction)pill_save_button_action:(id)sender
{
    
    
    @try{
    [_pill_quan_text resignFirstResponder];
    NSMutableDictionary *dic=[[NSMutableDictionary alloc ]init];
    [dic setObject:nameStr forKey:@"NAME"];
    [dic setObject:pinStr forKey:@"PIN"];
    [dic setObject:DateStr forKey:@"STARTDATE"];
    [dic setObject:_pill_quan_text.text forKey:@"PILLCOUNT"];
    [dic setObject:_select_time.text forKey:@"PILLTIME"];
    NSMutableArray  *Array=[[NSMutableArray alloc]init];
    [Array addObject:dic];
    
    
    
    [dbh UserUpdate:Array];

    [self MainUserData];
   
    
    [[NSUserDefaults standardUserDefaults] setObject:_pill_quan_text.text forKey:@"initialCount"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    NSString *initialPillCount=[[NSUserDefaults standardUserDefaults] objectForKey:@"initialCount"];
    intialCount=[initialPillCount intValue];
        
    NSString *firstPill=UDGetValue(@"firstPillTaken");
    if (!firstPill) {
        [_med_label_cont setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    }else
    {
        [_med_label_cont setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
    }
   
    
    _pill_view.hidden=YES;
    
    _pill_quan_text.text=@"";
    }  @catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}


- (IBAction)pill_back_button_action:(id)sender
{
    _pill_view.hidden=YES;
}

- (IBAction)inventory_button_action:(id)sender
{
    @try{
    _pill_view.hidden=NO;
        _pill_quan_text.text = [NSString stringWithFormat:@"%d",MedInt];
    [_pill_view bringSubviewToFront:_pill_quan_text];

    }  @catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}



#pragma mark UITableViewDelegate Protocol Methods-----------------------------------



- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    @try{
    NSLog(@"%lu",(unsigned long)[self.arrTopFiveAppoint count]);
    
    
    return [self.arrTopFiveAppoint count];
    } @catch(NSException *exception){
            NSLog(@"%@",exception.description);
        }
        
    }



- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath

{
    
    return 40;
    
    
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath

{
    @try{
    
    static NSString *simpleTableIdentifier = @"TimeTableViewCell";
    
    TimeTableViewCell *cell = (TimeTableViewCell *)[_appointment_tableview dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"TimeTableViewCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
                cell.selectionStyle = UITableViewCellSelectionStyleNone;
    }

    
    int Inder=(int)indexPath.row+1;
    cell.date_label.text=[self.arrTopFiveAppoint objectAtIndex:indexPath.row];
        
    cell.index_label.text=[NSString stringWithFormat:@"%d",Inder];
        
    cell.time_label.text=[self.arrTopFiveAppointTime objectAtIndex:indexPath.row];;

    
    return cell;
    }  @catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}


// - (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
// {
//          AppDel.Sele_ID_viewApp_Str=[AppID objectAtIndex:indexPath.row];
//          AppDel.ViewTask_Date=[App_Comp objectAtIndex:indexPath.row];
//     
//            NSLog(@"%@", AppDel.ViewTask_Date);
//           AppDel.ViewTask_tital=[App_Title objectAtIndex:indexPath.row];
//     
//     
// //         viewTaskViewController *objviewTaskViewController = [self.storyboard instantiateViewControllerWithIdentifier:@"viewTaskViewController"];
// //        
// //        
// //        [self.navigationController pushViewController:objviewTaskViewController animated:NO];
// }
-(void)MainUserData
{
    NSMutableArray *UserDateArray=[[NSMutableArray alloc]init];
    
    UserDateArray=[dbh selectAllUser];
    
    
    if ([UserDateArray count]>0)
    {//PIN,STARTDATE
        
        nameStr=[[UserDateArray objectAtIndex:0] objectForKey:@"NAME"];
        AppDel.Pill_countStr=[[UserDateArray objectAtIndex:0] objectForKey:@"PILLCOUNT"];
        pinStr=[[UserDateArray objectAtIndex:0] objectForKey:@"PIN"];
        DateStr=[[UserDateArray objectAtIndex:0] objectForKey:@"STARTDATE"];
        PillTimeStr=[[UserDateArray objectAtIndex:0] objectForKey:@"PILLTIME"];
        
    }
    
  //  [[NSUserDefaults standardUserDefaults] setObject:DateStr forKey:@"lastPillTakenDate"];
 //   [[NSUserDefaults standardUserDefaults]synchronize];
    
    
    [_med_label_cont setTitle: AppDel.Pill_countStr forState: UIControlStateNormal];
    
    NSString *MedStr=[NSString stringWithFormat:@"%@",_med_label_cont.titleLabel.text];
    
    
    MedInt=[MedStr intValue];
    
    
    
    // Arpit - change for null.....
    
    if([PillTimeStr isEqual:nil])
    {
        _time_of_change_label.text = @"";
        _select_time.text = @"";
    }
    else{
    _time_of_change_label.text=[NSString stringWithFormat:@"Time of Day to Take : %@",PillTimeStr];
    
    _select_time.text=[NSString stringWithFormat:@"%@",PillTimeStr];
    }
    
}

- (IBAction)chageTime_back:(id)sender
{
    _time_view.hidden=YES;
}

- (IBAction)time_Done_button_action:(id)sender
{
    @try{
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];

     NSDate *date = [_time_picker date];
      //NSTimeZone *gmt = [NSTimeZone systemTimeZone];
  //  [dateFormat setTimeZone:[NSTimeZone systemTimeZone]];
    [dateFormat setDateFormat:@"hh:mm a"];
    _select_time.text = [dateFormat stringFromDate:date];
    
    
    NSLog(@"%@",_select_time.text);
    
   
    // _time_view.hidden=YES;
    // _time_view.hidden=YES;
    
    [UIView animateWithDuration:0.50 animations:^{
        self.viewTimePicker.frame = CGRectMake(0, self.view.frame.size.height, self.view.frame.size.width, 242) ;
    }];
    }  @catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}


- (IBAction)time_cancel_button_action:(id)sender
{
    [UIView animateWithDuration:0.50 animations:^{
        self.viewTimePicker.frame = CGRectMake(0, self.view.frame.size.height, self.view.frame.size.width, 242) ;
    }];
}
- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField {
    
    if (textField.tag == 5)
    {
        
    }
    else
    {
    [UIView animateWithDuration:0.50 animations:^{
        self.viewTimePicker.frame = CGRectMake(0, self.view.frame.size.height - 242, self.view.frame.size.width, 242) ;
    }];
    return NO;
    }
    return YES;
}
-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string
{
    
   
    
    if (textField.tag == 5)
    {
        if (textField.text.length >= MAX_LENGTH_Pi && range.length == 0)
        {
            return NO; // return NO to not change text
        }
        
        /* for backspace */
        if([string length]==0)
        {
            return YES;
        }
        
        /*  limit to only numeric characters  */
        
        NSCharacterSet *myCharSet = [NSCharacterSet characterSetWithCharactersInString:@"0123456789"];
        for (int i = 0; i < [string length]; i++) {
            unichar c = [string characterAtIndex:i];
            if ([myCharSet characterIsMember:c]) {
                return YES;
            }
        }
        
        return NO;
  }else if(textField.tag == 5)
    {
        if (textField.text.length >=1000 && range.length == 0)
        {
            return NO; // return NO to not change text
        }
        
        /* for backspace */
        if([string length]==0)
        {
            return YES;
        }
        
        /*  limit to only numeric characters  */
        
        NSCharacterSet *myCharSet = [NSCharacterSet characterSetWithCharactersInString:@"0123456789"];
        for (int i = 0; i < [string length]; i++) {
            unichar c = [string characterAtIndex:i];
            if ([myCharSet characterIsMember:c]) {
                return YES;
            }
        }
        
        return NO;
}
     return YES;
    
}


-(void)selectTimeReq
{
    TimeRecArray=[[NSMutableArray alloc]init];
    DateRecArray=[[NSMutableArray alloc]init];
    allRecArray=[[NSMutableArray alloc]init];
    
    allRecArray=[dbh selectMEDICAL_RECORD];
    
    if ([allRecArray count]>0)
    {
        for (int i=0; i<[allRecArray count]; i++)
        {
            [DateRecArray addObject:[[allRecArray objectAtIndex:i] objectForKey:@"START_DATE"]];
            
            [TimeRecArray addObject:[[allRecArray objectAtIndex:i] objectForKey:@"MED_TIME"]];
        }
        
    }else
    {
        
        
        
        
        
        
    }
    
   // [_appointment_tableview reloadData];
    
}


-(void)PillInsertReq
{
    UDSetValue(@"firstPillTaken", @"firstPillTaken");
    NSDate *currentDateInLocal = [NSDate date];
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    NSDateFormatter *dateFormat1 = [[NSDateFormatter alloc] init];
    
    [dateFormat setDateFormat:@"MM-dd-yy"];
    NSString *DateStr1 = [dateFormat stringFromDate:currentDateInLocal];
    NSDate *lastPillTakenDate=[dateFormat dateFromString:DateStr1];
    
    [[NSUserDefaults standardUserDefaults] setObject:lastPillTakenDate forKey:@"dtlastPillTakenDate"];
    
    
    [dateFormat1 setDateFormat:@"hh:mm a"];
    
    NSString* timeStr=[dateFormat1 stringFromDate:currentDateInLocal];
    
    NSMutableDictionary *dic=[[NSMutableDictionary alloc ]init];
    
    
    [dic setObject:@"1" forKey:@"USER_ID"];
    [dic setObject:@"Medicine 1" forKey:@"MED_NAME"];
    [dic setObject:DateStr1 forKey:@"START_DATE"];
    [dic setObject:@"0" forKey:@"MED_TAKEN"];
    [dic setObject:@"1" forKey:@"MED_QUNTITY"];
    [dic setObject:timeStr forKey:@"MED_TIME"];
    
    
    
    NSMutableArray *dealArray=[[NSMutableArray alloc]init];
    
    [dealArray addObject:dic];
    
    [dbh insertMEDICAL_RECORD:dealArray];
    
    [self selectTimeReq];
    
    [[NSUserDefaults standardUserDefaults] setObject:DateStr1 forKey:@"lastPillTakenDate"];
    [[NSUserDefaults standardUserDefaults]synchronize];
    
    
}

// adding number pad ...pradip
-(void)cancelNumberPad{
   
    [_pill_quan_text resignFirstResponder];
    _pill_quan_text.text = @"";
}

-(void)doneWithNumberPad
{
               [_pill_quan_text resignFirstResponder];
 }


-(void)dismissKeyboard {
    [_pill_quan_text resignFirstResponder];
}
- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    [self.view endEditing:YES];
}



-(void)pillColor
{
    
    NSString *MedStr=[NSString stringWithFormat:@"%@",_med_label_cont.titleLabel.text];
    MedInt=[MedStr intValue];
      UDSetValue(MedStr,@"med");
    NSString *initialPillCount=[[NSUserDefaults standardUserDefaults] objectForKey:@"initialCount"];
    intialCount=[initialPillCount intValue];
    NSDateFormatter *formatter=[[NSDateFormatter alloc]init];
    //   NSTimeZone *timeZone = [NSTimeZone timeZoneWithName:@"UTC"];
    [formatter setDateFormat:@"MM-dd-yy"];
    // [formatter setTimeZone:timeZone];
    NSString *strlastPillTakenDate=[[NSUserDefaults standardUserDefaults]objectForKey:@"lastPillTakenDate"];
    
    NSDate *lastPillTakenDate=[[NSDate alloc]init];
    lastPillTakenDate= [formatter dateFromString:strlastPillTakenDate];
    NSDate *currentDate=[[NSDate alloc]init];
    NSString *time=[formatter stringFromDate:currentDate];
    currentDate=[formatter dateFromString:time];
    
    if ([lastPillTakenDate compare:currentDate]== NSOrderedAscending)
    {
        [_med_label_cont setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
    }else{
        NSString *firstPill=UDGetValue(@"firstPillTaken");
        
        if (!firstPill) {
            [_med_label_cont setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
        }else
        {
            [_med_label_cont setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
     
        }
    }
    
    
}

-(void)disableNotificationAppoint:(NSDate *)DateVisit
{
    NSArray *arrayOfLocalNotifications = [[UIApplication sharedApplication] scheduledLocalNotifications] ;
    
    for (UILocalNotification *localNotification in arrayOfLocalNotifications)
    {
        if ([localNotification.fireDate isEqualToDate:DateVisit])
        {
            NSLog(@"the notification this is canceld is %@", localNotification.alertBody);
            
            [[UIApplication sharedApplication] cancelLocalNotification:localNotification] ;
            // delete the notification from the system
        }
    }
}


-(void)Alert:(NSString *)alertBody
{
    UIAlertView *myAlert = [[UIAlertView alloc]               initWithTitle:@"Alert"
                                                                    message:alertBody
                                                                   delegate:self
                                                          cancelButtonTitle:@"Ok"
                                                          otherButtonTitles:nil];
    
    [myAlert show];
}



@end
