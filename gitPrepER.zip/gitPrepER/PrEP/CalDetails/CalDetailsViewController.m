//
//  CalDetailsViewController.m
//  PrEP
//
//  Created by Bhushan on 5/23/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import "CalDetailsViewController.h"
#import "AppointmentDetailTableViewCell.h"
#import "DataBase.h"
@interface CalDetailsViewController ()
{
    DataBase *dbh;
    NSString *trimmedStringDay,*weekdayName;
}

@end

@implementation CalDetailsViewController

- (void)viewDidLoad
{
    @try{
    [super viewDidLoad];
    
    NSString *myDateString = appDelegate.Cal_dateStr;
    trimmedStringDay=[myDateString substringFromIndex:MAX((int)[myDateString length]-2, 0)];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"MM-dd-yy"];
    
    NSDate *date = [dateFormatter dateFromString:myDateString];
    
    NSDateComponents *components = [[NSCalendar currentCalendar] components:NSWeekdayCalendarUnit fromDate:date];
    
    NSInteger weekday = [components weekday];
    weekdayName = [dateFormatter weekdaySymbols][weekday - 1];
    
    NSLog(@"///////////////");
    NSLog(@"%@ is a %@", myDateString, weekdayName);
    NSLog(@"///////////////");

    
  // Do any additional setup after loading the view.
}
    @catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}

- (void)viewWillAppear:(BOOL)animated {
    @try{
    [super viewWillAppear:animated];
    dbh=[[DataBase alloc]init];
    
    SelMutableArray=[dbh Appointment_cal_info:appDelegate.Cal_dateStr];
    
    
    
    
    for (int i=0; i<[SelMutableArray count]; i++)
    {
        appDelegate.strID = [[SelMutableArray objectAtIndex:0]objectForKey:@"ID"];
        appDelegate.Title_App_Str=[[SelMutableArray objectAtIndex:0]objectForKey:@"TITLE"];
        appDelegate.Cal_dateStr=[[SelMutableArray objectAtIndex:0]objectForKey:@"DATE"];
        appDelegate.Cal_DescStr=[[SelMutableArray objectAtIndex:0]objectForKey:@"DESC"];
        appDelegate.isConform=[[SelMutableArray objectAtIndex:0]objectForKey:@"ISCONFORM"];
        
    }
    
    NSLog(@"%@",SelMutableArray);
//Arpit edit - day selection from the date....
    
//    if ([SelMutableArray count] <1)
//    {
//        _date_label.hidden=YES;
//        _day_label.hidden=YES;
//        _tilte_name_button.hidden=YES;
//        
//    }else
//    {
//        _date_label.text=trimmedStringDay;
//        _day_label.text = weekdayName;
//        [_tilte_name_button setTitle:appDelegate.Title_App_Str forState:UIControlStateNormal];
//    }
        self.tableView.tableFooterView = [[UIView alloc] initWithFrame:CGRectZero];
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)back_button_action:(id)sender
{
    
    [self.navigationController popViewControllerAnimated:YES];
}
//- (IBAction)edit_to_appointment_button_action:(id)sender
//{
//    EditAppointmentViewViewController *objEditAppointmentViewViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"EditAppointmentViewViewController"];
//    
//    [self.navigationController pushViewController:objEditAppointmentViewViewController animated:YES];
//    
//    
//}


//Table view starts here....
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [SelMutableArray count];
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    @try{
    
    static NSString *simpleTableIdentifier = @"appointmentDetailsCell";
    
    AppointmentDetailTableViewCell *cell = (AppointmentDetailTableViewCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"appointmentDetailsCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
        cell.selectionStyle= UITableViewCellSelectionStyleNone;
    }
    
    cell.date_label.text=trimmedStringDay;
    cell.day_label.text=weekdayName;
    
    NSDictionary *dicTemp=[SelMutableArray objectAtIndex:indexPath.row];
    cell.title_label.text=[dicTemp objectForKey:@"TITLE"];

    if ([[dicTemp objectForKey:@"ISCONFORM"] isEqualToString:@"1"]) {
        cell.title_label.backgroundColor=[UIColor grayColor];
    }
    
    
    return cell;
    
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    @try{
    appDelegate.ID_App_Str =[[SelMutableArray objectAtIndex:indexPath.row] objectForKey:@"ID"];
    
    NSDictionary *dicTemp=[SelMutableArray objectAtIndex:indexPath.row];
    if ([[dicTemp objectForKey:@"ISCONFORM"] isEqualToString:@"1"]) {
        appDelegate.isFromOther=YES;
    }else{
        appDelegate.isFromOther=NO;
    }

    EditAppointmentViewViewController *objEditAppointmentViewViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"EditAppointmentViewViewController"];
  
    objEditAppointmentViewViewController.strTitle = [[SelMutableArray objectAtIndex:indexPath.row] objectForKey:@"TITLE"];
    
    objEditAppointmentViewViewController.strDate = [NSString stringWithFormat:@"%@",[[SelMutableArray objectAtIndex:indexPath.row] objectForKey:@"DATE"]];
    
    objEditAppointmentViewViewController.strDesc = [[SelMutableArray objectAtIndex:indexPath.row] objectForKey:@"DESC"];
    
     objEditAppointmentViewViewController.strTime = [[SelMutableArray objectAtIndex:indexPath.row] objectForKey:@"TIME"];
    
    [self.navigationController pushViewController:objEditAppointmentViewViewController animated:YES];
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}

- (IBAction)dash1_tab_button_action:(id)sender
{
    @try{
    int index = 0;
    for (UIViewController *vc in self.navigationController.viewControllers) {
        if ([vc isKindOfClass:[DashBoardViewController class]]) {
            [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:index] animated:NO];
        }
        index++;
    }
    DashBoardViewController *objDashBoardViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"DashBoardViewController"];
    [self.navigationController pushViewController:objDashBoardViewController animated:NO];
    
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}

- (IBAction)noti1_tab_button_action:(id)sender
{
    @try{
    int index = 0;
    for (UIViewController *vc in self.navigationController.viewControllers) {
        if ([vc isKindOfClass:[NotificationViewController class]]) {
            [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:index] animated:NO];
        }
        index++;
    }
    NotificationViewController *objNotificationViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"NotificationViewController"];
    [self.navigationController pushViewController:objNotificationViewController animated:NO];
    
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}

- (IBAction)task1_tab_button_action:(id)sender
{
    @try{
    int index = 0;
    for (UIViewController *vc in self.navigationController.viewControllers) {
        if ([vc isKindOfClass:[AppointmentViewController class]]) {
            [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:index] animated:NO];
        }
        index++;
    }
    AppointmentViewController *objAppointmentViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"AppointmentViewController"];
    [self.navigationController pushViewController:objAppointmentViewController animated:NO];
    
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}



-(IBAction)setting1_tab_button_action:(id)sender
{
    @try{
//    int index = 0;
//    for (UIViewController *vc in self.navigationController.viewControllers) {
//        if ([vc isKindOfClass:[SettingViewController class]]) {
//            [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:index] animated:NO];
//        }
//        index++;
//    }
    SettingViewController *objSettingViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"SettingViewController"];
    [self.navigationController pushViewController:objSettingViewController animated:NO];
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}
@end
