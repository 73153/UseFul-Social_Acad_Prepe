//
//  UITextField+StyleTextField.m
//  PrEP
//
//  Created by tusharpatel on 28/07/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import "UITextField+StyleTextField.h"

@implementation UITextField (StyleTextField)

-(void) initTextFieldStyle{
    self.layer.cornerRadius=2.0f;
    self.layer.masksToBounds=YES;
    self.layer.borderColor=[[UIColor grayColor]CGColor];
    self.layer.borderWidth= 2.5f;
    self.backgroundColor=[UIColor clearColor];
}
@end
