//
//  UIButton+StyledButton.m
//  PrEP
//
//  Created by Bhushan on 6/2/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import "UIButton+StyledButton.h"
@implementation UIButton (StyledButton)

- (void) initWithBorders {
    //style your button properties here

        self.layer.shadowOpacity = 0.5;
        self.layer.shadowRadius = 5;
        self.layer.shadowOffset = CGSizeMake(3.0f,3.0f);
        self.layer.cornerRadius = 5;
  
}
@end

