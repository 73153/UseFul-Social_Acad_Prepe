//
//  EditAppointmentViewViewController.h
//  PrEP
//
//  Created by Bhushan on 5/12/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import "ViewController.h"

//@protocol UpdateRegularPill
//@optional
//-(void)updateRegularPillTaken;
//@end

@interface EditAppointmentViewViewController : ViewController

{
    NSMutableArray  *AddArray;
    NSMutableArray  *addApoinmentTitleArray;
    NSArray *SelectionArray;
    
    NSString *timeStr;

}


@property NSString *strID;
@property NSString *strTitle;
@property NSString *strDate;
@property NSString *strDesc;
@property NSString *strTime;
@property (nonatomic,retain) IBOutlet UIButton *btnCalTab;
@property (nonatomic,retain) IBOutlet UIButton *btnDashTab;

@property (strong, nonatomic) IBOutlet UIButton *btnCompletedAppoint;
@property (strong, nonatomic) IBOutlet UIButton *btnSaveAppoint;

@property (strong, nonatomic) IBOutlet UITextField *title_label;
@property (strong, nonatomic) IBOutlet UITextField *desc_label;
@property (strong, nonatomic) IBOutlet UITextField *date_label;

@property (strong, nonatomic) UIDatePicker *date_picker;

@property (strong, nonatomic) IBOutlet UITextField *title_text_field;

@property (strong, nonatomic) IBOutlet UITextField *desc_text_field;

@property (strong, nonatomic) IBOutlet UITextField *date_text_field;

@property (strong, nonatomic) IBOutlet UIScrollView *main_scroll_view;
@property (strong, nonatomic) IBOutlet UIButton *save_button;

@property (strong, nonatomic) IBOutlet UIButton *edit_button;

@property (strong, nonatomic) IBOutlet UIView *dateview;


@property (strong, nonatomic) IBOutlet UITextField *txtTime;

@property (nonatomic) BOOL isdate;



- (IBAction)save_button_action:(id)sender;
- (IBAction)date_cancel_button_action:(id)sender;
- (IBAction)date_done_button_action:(id)sender;
- (IBAction)edit:(id)sender;
- (IBAction)back_button_action:(id)sender;

@property (weak, nonatomic) IBOutlet UIView *viewAponitmentTableCell;
@property (weak, nonatomic) IBOutlet UITableView *tblView;
@property (weak, nonatomic) IBOutlet UITextField *txtOtherAppoint;

- (IBAction)completed_button_action:(id)sender;

- (IBAction)noti_tab_button_action:(id)sender;

- (IBAction)task_tab_button_action:(id)sender;

- (IBAction)cal_tab_button_action:(id)sender;

- (IBAction)setting_tab_button_action:(id)sender;
@property (weak, nonatomic) IBOutlet UITextField *txtEditOtherapponitName;

@property (weak, nonatomic) IBOutlet UIView *viewEditAponit;

@end
