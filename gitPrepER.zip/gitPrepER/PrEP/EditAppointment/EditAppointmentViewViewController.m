   //
//  EditAppointmentViewViewController.m
//  PrEP
//
//  Created by Bhushan on 5/12/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import "EditAppointmentViewViewController.h"
#import "DataBase.h"
#import "CalViewController.h"
#import "AddApoinmentCell.h"
#import "Constant.h"


@interface EditAppointmentViewViewController ()
{
    DataBase *dbh;
   
}

@end

@implementation EditAppointmentViewViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
}

-(void)viewWillAppear:(BOOL)animated {
    @try{
    _edit_button.hidden=YES;
    [_btnCompletedAppoint initWithBorders];
    [_save_button initWithBorders];
    // Do any additional setup after loading the view.
    
    self.date_picker = [[UIDatePicker alloc] initWithFrame:CGRectMake(0, 44, self.view.frame.size.width,198)];
    [self.dateview addSubview:self.date_picker];
  
    dbh=[[DataBase alloc]init];
    AddArray=[[NSMutableArray alloc]init];
    addApoinmentTitleArray=[[NSMutableArray alloc] initWithObjects:@"1 Month Vist",@"3 Month Vist",@"6 Month Vist",@"other", nil];
    [_viewAponitmentTableCell setHidden:YES];
    NSLog(@"%@",appDelegate.ID_App_Str);
   
    //SelectionArray=[dbh EditAppointment:appDelegate.ID_App_Str];
    
  
        
        _title_text_field.text=self.strTitle;
        _date_text_field.text=self.strDate;
        _desc_text_field.text=self.strDesc;
        _txtTime.text=self.strTime;
        _title_text_field.userInteractionEnabled=NO;
        _date_text_field.userInteractionEnabled=NO;
        _desc_text_field.userInteractionEnabled=NO;
        _txtTime.userInteractionEnabled=NO;
    
    if (appDelegate.isFromOther) {
         _edit_button.hidden=NO;
    }
   else if ([appDelegate.CompSel_App_Str isEqualToString:@"1"] || appDelegate.isFromDashboard )
    {
        _edit_button.hidden=YES;
    }
    else {
        [_btnCalTab setBackgroundImage:[UIImage imageNamed:@"cal_selected"] forState:UIControlStateNormal];
        [_btnDashTab setBackgroundImage:[UIImage imageNamed:@"dashboard"] forState:UIControlStateNormal];
    }
    _save_button.hidden=YES;
    
    
#pragma textfield layout
    
//    _title_text_field.layer.cornerRadius=2.0f;
//    _title_text_field.layer.masksToBounds=YES;
//    _title_text_field.layer.borderColor=[[UIColor grayColor]CGColor];
//    _title_text_field.layer.borderWidth= 2.5f;
//    _title_text_field.backgroundColor=[UIColor clearColor];
//    
//    _txtEditOtherapponitName.layer.cornerRadius=2.0f;
//    _txtEditOtherapponitName.layer.masksToBounds=YES;
//    _txtEditOtherapponitName.layer.borderColor=[[UIColor grayColor]CGColor];
//    _txtEditOtherapponitName.layer.borderWidth= 2.5f;
//    _txtEditOtherapponitName.backgroundColor=[UIColor clearColor];
//    
//    _desc_text_field.layer.cornerRadius=2.0f;
//    _desc_text_field.layer.masksToBounds=YES;
//    _desc_text_field.layer.borderColor=[[UIColor grayColor]CGColor];
//    _desc_text_field.layer.borderWidth= 2.5f;
//    _desc_text_field.backgroundColor=[UIColor clearColor];
//    
//    
//    _date_text_field.layer.cornerRadius=2.0f;
//    _date_text_field.layer.masksToBounds=YES;
//    _date_text_field.layer.borderColor=[[UIColor grayColor]CGColor];
//    _date_text_field.layer.borderWidth= 2.5f;
//    _date_text_field.backgroundColor=[UIColor clearColor];
    
    [_title_text_field initTextFieldStyle];
    [_txtEditOtherapponitName initTextFieldStyle];
    [_desc_text_field initTextFieldStyle];
    [_date_text_field initTextFieldStyle];
    [_txtTime initTextFieldStyle];
    
}
    @catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}

-(void)viewWillDisappear:(BOOL)animated {
    appDelegate.isFromDashboard = FALSE;
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

- (IBAction)save_button_action:(id)sender
{
    @try{
      appDelegate.CompSel_App_Str=@"";
    NSString *rawString = [_title_text_field text];
    NSCharacterSet *whitespace = [NSCharacterSet whitespaceAndNewlineCharacterSet];
    NSString *trimmed = [rawString stringByTrimmingCharactersInSet:whitespace];
    
    NSString *rawString1 = [_desc_text_field text];
    NSCharacterSet *whitespace1 = [NSCharacterSet whitespaceAndNewlineCharacterSet];
    NSString *trimmed1 = [rawString1 stringByTrimmingCharactersInSet:whitespace1];
    
    NSString *rawString2 = [_date_text_field text];
    NSCharacterSet *whitespace2 = [NSCharacterSet whitespaceAndNewlineCharacterSet];
    NSString *trimmed2 = [rawString2 stringByTrimmingCharactersInSet:whitespace2];
    
    NSString *rawString3 = [_txtTime text];
    NSCharacterSet *whitespace3 = [NSCharacterSet whitespaceAndNewlineCharacterSet];
    NSString *trimmed3 = [rawString3 stringByTrimmingCharactersInSet:whitespace3];
    
    
    if([trimmed length] == 0)
    {
        
        [appDelegate.window makeToast:@"Title Empty" duration:1.0 position:@"center"];
        
    }else if ([trimmed1 length] == 0)
    {
        [appDelegate.window makeToast:@"Descrptions Empty" duration:1.0 position:@"center"];
        
    }else if ([trimmed2 length]== 0)
    {
        
        [appDelegate.window makeToast:@" Date Empty" duration:1.0 position:@"center"];
        
    }else if ([trimmed3 length]== 0)
    {
        
        [appDelegate.window makeToast:@" Time Empty" duration:1.0 position:@"center"];
        
    }else
    {
        NSMutableDictionary *dic=[[NSMutableDictionary alloc ]init];
        [dic setObject:appDelegate.strID forKey:@"ID"];
        [dic setObject:_title_text_field.text forKey:@"TITLE"];
        
        [dic setObject:_desc_text_field.text forKey:@"DESC"];
        
        [dic setObject:rawString2 forKey:@"DATE"];
        [dic setObject:rawString3 forKey:@"TIME"];
        
       
        
        [AddArray addObject:dic];
        
        
        if ([AddArray count]>0)
        {
            [dbh AppointmentUpdate:AddArray];
            
        }
        int index = 0;
        for (UIViewController *vc in self.navigationController.viewControllers) {
            if ([vc isKindOfClass:[CalViewController class]]) {
                  [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:index] animated:YES];
                
            }
            index++;
        }
    }

    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}

- (IBAction)date_cancel_button_action:(id)sender
{
    
    _dateview.hidden=YES;
    
    CGPoint point = CGPointMake(0,0);
    [_main_scroll_view setContentOffset:point animated:YES] ;
    
}



- (IBAction)date_done_button_action:(id)sender
{
    @try{
    if(self.isdate==YES)
    {

    NSDate *date = [_date_picker date];
    NSDateFormatter *dateFormat = [[NSDateFormatter alloc] init];
    [dateFormat setDateFormat:@"MM-dd-yy"];
    _date_text_field.text = [dateFormat stringFromDate:date];

    
    _dateview.hidden=YES;
    
    CGPoint point = CGPointMake(0,0);
    [_main_scroll_view setContentOffset:point animated:YES] ;
    }
    else
    {
        NSDateFormatter *dateFormat1 = [[NSDateFormatter alloc] init];
        
        NSDate *date = [_date_picker date];
        
        [dateFormat1 setDateFormat:@"hh:mm a"];
        
        timeStr=[dateFormat1 stringFromDate:date];
        _txtTime.text=timeStr;
        _dateview.hidden=YES;
        
        CGPoint point = CGPointMake(0,0);
        [_main_scroll_view setContentOffset:point animated:YES] ;

    }
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}

- (IBAction)edit:(id)sender
{
    @try{
     _save_button.hidden=NO;
    _title_text_field.userInteractionEnabled=YES;
    _date_text_field.userInteractionEnabled=YES;
    _desc_text_field.userInteractionEnabled=YES;
    _txtTime.userInteractionEnabled=YES;
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}

- (IBAction)back_button_action:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
    
    appDelegate.CompSel_App_Str=@"";
    
}

- (IBAction)completed_button_action:(id)sender
{
    @try{
    if (!appDelegate.isFromOther) {
        NSDateFormatter *formatter=[[NSDateFormatter alloc]init];
        [formatter setDateFormat:@"MM-dd-yy"];
        NSDate *appointDate=[[NSDate alloc]init];
       appointDate= [formatter dateFromString:_strDate];
        [formatter setDateFormat:@"dd-MM-yyyy"];
        NSString *str1=[formatter stringFromDate:appointDate];

        appointDate= [formatter dateFromString:str1];
        
        //NSString *strOneMonth = UDGetObject(@"1monthVisit");
        NSDate *oneMonthVisitDate=UDGetObject(@"1monthVisit");
        NSDate *oneMonthVisitDate7 = [oneMonthVisitDate dateByAddingTimeInterval:60*60*24*7];
        NSDate *twoMonthVisitDate=UDGetObject(@"3monthVisit");
        NSDate *twoMonthVisitDate7 = [twoMonthVisitDate dateByAddingTimeInterval:60*60*24*7];
        NSDate *threeMonthVisitDate=UDGetObject(@"6monthVisit");
        NSDate *threeMonthVisitDate7 = [threeMonthVisitDate dateByAddingTimeInterval:60*60*24*7];
        NSDate *cDate=[[NSDate alloc]init];
        [formatter setDateFormat:@"dd-MM-yyyy"];
        NSString *ctDate =[formatter stringFromDate:cDate];
        NSDate *currentDate=[formatter dateFromString:ctDate];
        
        if (([currentDate compare:appointDate] == NSOrderedSame) || ([currentDate compare:appointDate] == NSOrderedDescending))
        {
            
            if ((([currentDate compare:oneMonthVisitDate7]== NSOrderedSame) || (([currentDate compare:oneMonthVisitDate7]== NSOrderedAscending)))&& [_strTitle isEqualToString:@"1 Month Visit"])
            {
                NSInteger iscompeleted=UDGetInt(@"isCompleted");
                if (iscompeleted == 0)
                {
                    [self Alert:@"You will not be able to edit Appointment details once you mark it as completed do you want to proceed ?"];
                }else
                {
                    [self Alert:@"The task Can Not be Completed before the Appointment Date"];
                }
            }
            if ((([currentDate compare:twoMonthVisitDate7]== NSOrderedSame) || (([currentDate compare:twoMonthVisitDate7] == NSOrderedAscending)))&& [_strTitle isEqualToString:@"3 Month Visit"])
            {
                int iscompeleted=UDGetInt(@"isCompleted");
                if (iscompeleted == 1)
                {
                   [self Alert:@"You will not be able to edit appointment details once you mark it as completed do you want to proceed ?"];
                }
                else
                {
                    [self Alert:@"The task Can Not be Completed before the Appointment Date"];
                }
            }

        if ((([currentDate compare:threeMonthVisitDate7]== NSOrderedSame) ||(([currentDate compare:threeMonthVisitDate7]== NSOrderedAscending)))&& [_strTitle isEqualToString:@"6 Month Visit"])
        {
            int iscompeleted=UDGetInt(@"isCompleted");
            if (iscompeleted == 2)
            {
               [self Alert:@"You will not be able to edit appointment details once you mark it as completed do you want to proceed?"];
            }
            else
            {
                [self Alert:@"The task Can Not be Completed before the Appointment Date"];
            }
        }
        }else
        {
            [self Alert:@"The task Can Not be Completed before the Appointment Date"];
        }
    }else
    {
       [self Alert:@"you will not be able to edit Appointment details once you mark it as completed do you want to proceed?"];
    }
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}


#pragma mark textViewDidBeginEditing-----------------------------------------------------

static NSInteger stepRange1[] = {
    
    0,0,90,110,130
};



static NSInteger getScrollPos21(NSInteger i) {
    
    if (i < 1 || i > 4)
        return 0 ;
    return stepRange1[i] ;
}

static NSInteger stepRange[] = {
    
    0,0,90,110,130
};



static NSInteger getScrollPos2(NSInteger i) {
    
    if (i < 1 || i > 3)
        return 0 ;
    return stepRange[i] ;
}


- (void)textViewDidBeginEditing:(UITextView *)textView
{
    
    
    _main_scroll_view.scrollEnabled = YES;
    CGPoint point = CGPointMake(0,700);
    [_main_scroll_view setContentOffset:point animated:YES] ;
    
}
- (BOOL)textField:(UITextField *)textField
shouldChangeCharactersInRange:(NSRange)range
replacementString:(NSString *)string
{
    return YES;
}

- (void) textFieldDidBeginEditing:(UITextField *)textField
{
    
    if (textField.tag==3)
    {
        self.isdate=NO;
         _dateview.hidden=NO;
        
        [textField resignFirstResponder];
        [_title_label resignFirstResponder];
        
        [_date_label resignFirstResponder];
        [_desc_label resignFirstResponder];
        
        CGPoint point;
        
        point = CGPointMake(0, getScrollPos21(textField.tag));
        [_main_scroll_view setContentOffset:point animated:YES] ;
        
        
    }
    else
    {
        _main_scroll_view.scrollEnabled = YES;
        CGPoint point;
        
        if (IS_IPHONE5)
            point = CGPointMake(0, getScrollPos21(textField.tag));
        else
            point = CGPointMake(0, getScrollPos2(textField.tag));
        
        
        [_main_scroll_view setContentOffset:point animated:YES] ;
        
    }
    
    
}

-(BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if (textField.tag==3)
    {
        self.isdate=YES;

        self.date_picker.datePickerMode = UIDatePickerModeDate;
        
        _dateview.hidden=NO;
        
        [textField resignFirstResponder];
        [_title_label resignFirstResponder];
        
        [_dateview resignFirstResponder];
        [_desc_text_field resignFirstResponder];
        
        CGPoint point;
        
        point = CGPointMake(0, getScrollPos21(textField.tag));
        [_main_scroll_view setContentOffset:point animated:YES] ;
        
        return NO;
    }
    else if (textField.tag==4)
    {
        self.isdate=NO;
        self.date_picker.datePickerMode = UIDatePickerModeTime;
        _dateview.hidden=NO;
        
        [textField resignFirstResponder];
        [_title_label resignFirstResponder];
        
        [_date_label resignFirstResponder];
        [_desc_label resignFirstResponder];
        
        CGPoint point;
        
        point = CGPointMake(0, getScrollPos21(textField.tag));
        [_main_scroll_view setContentOffset:point animated:YES] ;
        return NO;
    }

    else if (textField.tag == 101)
    {
        _viewAponitmentTableCell.hidden=NO;
        return NO;
    }else if (textField.tag == 102)
    {
        [textField resignFirstResponder];
    return NO;
    }
    else if (textField.tag==4)
    {
        self.isdate=NO;
        self.date_picker.datePickerMode = UIDatePickerModeTime;
        _dateview.hidden=NO;
        
        [textField resignFirstResponder];
        [_title_label resignFirstResponder];
        
        [_date_label resignFirstResponder];
        [_desc_label resignFirstResponder];
        
        CGPoint point;
        
        point = CGPointMake(0, getScrollPos21(textField.tag));
        [_main_scroll_view setContentOffset:point animated:YES] ;
        return NO;
    }

    else
    {
        return YES;
    }
}


- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    _main_scroll_view.scrollEnabled = YES;

    NSInteger nextTag = textField.tag + 1;
    UIResponder* nextResponder = [textField.superview viewWithTag:nextTag];
    
    if (nextResponder)
    {
        if (nextTag==3)
        {
            
            _dateview.hidden=NO;
            
            CGPoint point = CGPointMake(0, getScrollPos2(nextTag));
            [_main_scroll_view setContentOffset:point animated:YES];
            
            [_title_label resignFirstResponder];
            
            [_date_text_field resignFirstResponder];
            [_date_text_field resignFirstResponder];
            
            [textField resignFirstResponder];
        }
        else{
            
            [nextResponder becomeFirstResponder];
            CGPoint point = CGPointMake(0, getScrollPos2(nextTag));
            [_main_scroll_view setContentOffset:point animated:YES];
        }
        
    }
    else
    {
        CGPoint point = CGPointMake(0,64);
        [_main_scroll_view setContentOffset:point animated:YES] ;
        [textField resignFirstResponder];
        
        
        
        
    }
    
    return YES;
}



- (IBAction)noti_tab_button_action:(id)sender
{
    @try{
    int index = 0;
    for (UIViewController *vc in self.navigationController.viewControllers) {
        if ([vc isKindOfClass:[NotificationViewController class]]) {
            [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:index] animated:NO];
        }
        index++;
    }
    NotificationViewController *objNotificationViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"NotificationViewController"];
    
    
    [self.navigationController pushViewController:objNotificationViewController animated:NO];
    
    }@catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}

- (IBAction)task_tab_button_action:(id)sender

{@try{
    int index = 0;
    for (UIViewController *vc in self.navigationController.viewControllers) {
        if ([vc isKindOfClass:[AppointmentViewController class]]) {
            [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:index] animated:NO];
        }
        index++;
    }
    AppointmentViewController *objAppointmentViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"AppointmentViewController"];
    [self.navigationController pushViewController:objAppointmentViewController animated:NO];
}  @catch(NSException *exception){
    NSLog(@"%@",exception.description);
}
    
}


- (IBAction)cal_tab_button_action:(id)sender
{@try{
    int index = 0;
    for (UIViewController *vc in self.navigationController.viewControllers) {
        if ([vc isKindOfClass:[CalViewController class]]) {
            [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:index] animated:NO];
        }
        index++;
    }
    CalViewController *objCalViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"CalViewController"];
    [self.navigationController pushViewController:objCalViewController animated:NO];
}  @catch(NSException *exception){
    NSLog(@"%@",exception.description);
}
    
}

- (IBAction)setting_tab_button_action:(id)sender
{@try{
//    int index = 0;
//    for (UIViewController *vc in self.navigationController.viewControllers) {
//        if ([vc isKindOfClass:[SettingViewController class]]) {
//            [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:index] animated:NO];
//        }
//        index++;
//    }
    SettingViewController *objSettingViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"SettingViewController"];
    [self.navigationController pushViewController:objSettingViewController animated:NO];
}  @catch(NSException *exception){
    NSLog(@"%@",exception.description);
}
    
}



- (void)alertView:(UIAlertView *)alertView didDismissWithButtonIndex:(NSInteger)buttonIndex {
    // the user clicked OK
    
    
    if (!appDelegate.isFromOther) {
    if (buttonIndex == 0 || [alertView.message isEqualToString:@"The task Can Not be Completed before the Appointment Date"])
    {
        // do something here...
    }
    else if([_strTitle isEqualToString:@"1 Month Visit"])
    {
        UDSetInt(1,@"isCompleted");
        [self PushToView];
    }
    else if([_strTitle isEqualToString:@"3 Month Visit"])
    {
        UDSetInt(2,@"isCompleted");
        [self PushToView];
    }
    else if([_strTitle isEqualToString:@"6 Month Visit"])
    {
        UDSetInt(3,@"isCompleted");
        [self PushToView];
    }
    else if([alertView.message isEqualToString:@"you will not be able to edit Appointment details once you mark it as completed do you want to proceed?"])
    {
       [self PushToView];
    }
    else{
          [self PushToView];
    }
    }else
    {
         [self PushToView];
    }
//        DashBoardViewController *objCalViewController=[self.storyboard instantiateViewControllerWithIdentifier:@"CalViewController"];
//        [self.navigationController pushViewController:objCalViewController animated:YES];
    
}

#pragma mark -table view dat sources

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    @try{
    return 1 ;
    }  @catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}


- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    @try{
    return [addApoinmentTitleArray count];
    }  @catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}


- (UITableViewCell *)tableView:(UITableView *)tv cellForRowAtIndexPath:(NSIndexPath*)indexPath {
    @try{
    static NSString *CellIdentifier = @"celll";
    AddApoinmentCell *cell1 = [_tblView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    // NOTE: Add some code like this to create a new cell if there are none to reuse
    if(cell1 == nil)
    {
        cell1 = [[AddApoinmentCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
        
    }
    
    NSString *string = [addApoinmentTitleArray objectAtIndex:indexPath.row];
    
    cell1.textLabel.text = string;
    NSLog(@"%@",string);
    return cell1;
    }  @catch(NSException *exception){
        NSLog(@"%@",exception.description);
    }
    
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{@try{
    NSString *str1 = [addApoinmentTitleArray objectAtIndex:indexPath.row];
    
    if (![str1 isEqualToString:@"other"]) {
        _title_text_field.text=str1;
        _viewEditAponit.frame=CGRectMake(0, 118, 324, 254);
    }else
    {
        _title_text_field.text=str1;
        _viewEditAponit.frame=CGRectMake(0, 160, 320, 294);
    }
    
    [_viewAponitmentTableCell setHidden:YES];
    [_viewEditAponit bringSubviewToFront:_save_button];
    
}  @catch(NSException *exception){
    NSLog(@"%@",exception.description);
}
    
}


-(void)Alert:(NSString *)alertBody
{
    UIAlertView *myAlert = [[UIAlertView alloc]               initWithTitle:@"Alert"
                                                                    message:alertBody
                                                                   delegate:self
                                                          cancelButtonTitle:@"Cancel"
                                                          otherButtonTitles:@"Ok",nil];

    [myAlert show];
}

-(void)PushToView
{
    NSDate *currentDate=[[NSDate alloc] init];
    NSDateFormatter *formater=[[NSDateFormatter alloc]init];
    [formater setDateFormat:@"MM-dd-yy"];
    NSString *strCurrentDate=[formater stringFromDate:currentDate];
    [dbh UpdateDateComplete:strCurrentDate Id:appDelegate.ID_App_Str];
    [dbh Comp_task:appDelegate.ID_App_Str];
    
    int index = 0;
    for (UIViewController *vc in self.navigationController.viewControllers) {
        if ([vc isKindOfClass:[DashBoardViewController class]]) {
            [self.navigationController popToViewController:[self.navigationController.viewControllers objectAtIndex:index] animated:YES];
        }
        index++;
    
}
}
@end
