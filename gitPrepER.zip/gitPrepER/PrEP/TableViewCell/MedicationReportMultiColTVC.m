//
//  MedicationReportMultiColTVC.m
//  PrEP
//
//  Created by pradip.r on 10/27/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import "MedicationReportMultiColTVC.h"

@implementation MedicationReportMultiColTVC

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
