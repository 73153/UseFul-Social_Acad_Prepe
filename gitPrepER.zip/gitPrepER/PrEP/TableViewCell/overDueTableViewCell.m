//
//  overDueTableViewCell.m
//  PrEP
//
//  Created by tusharpatel on 27/07/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import "overDueTableViewCell.h"

@implementation overDueTableViewCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
