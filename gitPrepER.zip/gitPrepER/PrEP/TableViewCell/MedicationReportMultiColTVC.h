//
//  MedicationReportMultiColTVC.h
//  PrEP
//
//  Created by pradip.r on 10/27/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MedicationReportMultiColTVC : UITableViewCell
@property (weak, nonatomic) IBOutlet UITextField *txtDate;
@property (weak, nonatomic) IBOutlet UITextField *txtScheduledTime;
@property (weak, nonatomic) IBOutlet UITextField *txtActualTime;
@property (weak, nonatomic) IBOutlet UITextField *txtTimeDifference;
@property (weak, nonatomic) IBOutlet UILabel *lblEndTitle;
@property (weak, nonatomic) IBOutlet UILabel *lblCenterTitle;
@property (weak, nonatomic) IBOutlet UILabel *lblFrontTitle;

@end
