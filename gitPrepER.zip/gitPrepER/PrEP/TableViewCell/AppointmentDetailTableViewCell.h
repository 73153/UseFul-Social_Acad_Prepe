//
//  AppointmentDetailTableViewCell.h
//  PrEP
//
//  Created by arpit on 7/27/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppointmentDetailTableViewCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UIButton *tilte_name_button;

@property (strong, nonatomic) IBOutlet UILabel *title_label;

@property (strong, nonatomic) IBOutlet UILabel *date_label;
@property (strong, nonatomic) IBOutlet UILabel *day_label;

//- (IBAction)edit_to_appointment_button_action:(id)sender;


@end
