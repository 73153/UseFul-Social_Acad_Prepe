//
//  overDueTableViewCell.h
//  PrEP
//
//  Created by tusharpatel on 27/07/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface overDueTableViewCell : UITableViewCell
@property (nonatomic,retain) IBOutlet UILabel *lblTitle;
@property (nonatomic,retain) IBOutlet UILabel *lblDateTime;

@end
