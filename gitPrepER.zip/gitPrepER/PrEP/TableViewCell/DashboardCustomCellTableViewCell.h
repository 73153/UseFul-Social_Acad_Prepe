//
//  DashboardCustomCellTableViewCell.h
//  PrEP
//
//  Created by Bhushan on 5/7/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface DashboardCustomCellTableViewCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UILabel *tital_label;

@property (strong, nonatomic) IBOutlet UILabel *date_label;

@property (strong, nonatomic) IBOutlet UILabel *index_label;

@end
