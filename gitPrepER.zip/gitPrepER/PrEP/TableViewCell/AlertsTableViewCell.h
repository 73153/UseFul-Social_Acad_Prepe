//
//  AlertsTableViewCell.h
//  PrEP
//
//  Created by Bhushan on 5/11/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AlertsTableViewCell : UITableViewCell

@property (strong, nonatomic) IBOutlet UILabel *alerts_label;




@end
