//
//  TimeTableViewCell.h
//  PrEP
//
//  Created by Bhushan on 7/15/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TimeTableViewCell : UITableViewCell
@property (strong, nonatomic) IBOutlet UILabel *date_label;
@property (strong, nonatomic) IBOutlet UILabel *time_label;
@property (strong, nonatomic) IBOutlet UILabel *index_label;

@end
