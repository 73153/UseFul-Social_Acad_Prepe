//
//  AppointmentReportTVC.m
//  PrEP
//
//  Created by pradip.r on 10/29/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import "AppointmentReportTVC.h"

@implementation AppointmentReportTVC

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
