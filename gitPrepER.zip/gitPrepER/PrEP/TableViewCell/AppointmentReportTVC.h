//
//  AppointmentReportTVC.h
//  PrEP
//
//  Created by pradip.r on 10/29/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppointmentReportTVC : UITableViewCell
@property (weak, nonatomic) IBOutlet UITextField *txtDate;
@property (weak, nonatomic) IBOutlet UITextField *txtAppointTitle;

@property (weak, nonatomic) IBOutlet UITextField *txtDateCompleted;
@end
