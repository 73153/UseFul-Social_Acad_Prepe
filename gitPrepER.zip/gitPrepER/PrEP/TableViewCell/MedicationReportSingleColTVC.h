//
//  MedicationReportSingleColTVC.h
//  PrEP
//
//  Created by pradip.r on 10/27/15.
//  Copyright (c) 2015 com.zaptechsolution. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MedicationReportSingleColTVC : UITableViewCell
@property (weak, nonatomic) IBOutlet UIView *borderView;
@property (weak, nonatomic) IBOutlet UILabel *lblTitle;
@end
