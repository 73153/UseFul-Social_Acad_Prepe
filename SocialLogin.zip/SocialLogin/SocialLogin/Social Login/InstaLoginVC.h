//
//  InstaLoginVC.h
//  SocialLogin
//
//  Created by aadil on 27/10/15.
//  Copyright © 2015 zaptechsolutions. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface InstaLoginVC : UIViewController
@property UIWebView *web;
@end
