//
//  ViewController.h
//  SocialLogin
//
//  Created by aadil on 19/08/15.
//  Copyright (c) 2015 zaptechsolutions. All rights reserved.
//
#import "AppDelegate.h"
#import <UIKit/UIKit.h>
@class GPPSignInButton;
@interface ViewController : UIViewController

@property (strong,nonatomic) AppDelegate *app;
@property (retain, nonatomic) IBOutlet GPPSignInButton *signInButton;
@end

